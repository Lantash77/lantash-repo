# -*- coding: UTF-8 -*-
import sys, re
from urllib.parse import quote_plus, urlencode, urlparse, parse_qs
from functools import reduce
from ast import literal_eval

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import time

from resources.libs.helper import flat_title

# from common import PlayFromHost
from resources.libs import cache
from resources.libs.worker import *
from resources.libs import getstream
from resources.libs.log_utils import log, plog
my_addon = xbmcaddon.Addon()
Getsetting = my_addon.getSetting
execute = xbmc.executebuiltin
sysaddon = sys.argv[0]

def is_host_valid(url, domains):
    try:
        elements = urlparse(url)
        domain = elements.netloc or elements.path
        domain = domain.split("@")[-1].split(":")[0]
        pattern = re.compile("(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$")
        res = pattern.search(domain)
        if res:
            domain = res.group(1)
        host = domain.lower()
        hosts = [domain.lower() for domain in domains if host and host in domain.lower()]

        if hosts and "." not in host:
            host = hosts[0]
        if hosts and any([h for h in ["google", "picasa", "blogspot"] if h in host]):
            host = "gvideo"
        if hosts and any([h for h in ["akamaized", "ocloud"] if h in host]):
            host = "CDN"
        return any(hosts), host
    except:
        #log_exception()
        return False, ""



def get_hostList():

    from resolveurl import relevant_resolvers
    hostDict = relevant_resolvers(order_matters=True)
    hostDict = [i.domains for i in hostDict if not "*" in i.domains]
    hostDict = [i.lower() for i in reduce(lambda x, y: x + y, hostDict)]
    hostDict = [x for y, x in enumerate(hostDict) if x not in hostDict[:y]]
    return hostDict


def set_art_dict(f_args):

    art_keys = ['icon', 'thumb', 'fanart',
                'poster', 'banner', 'landscape',
                'clearart', 'clearlogo']
    get_art = f_args.get
    get_from_data = get_art('data', {}).get
    get_from_art = get_from_data('art', {}).get
    art_dict = {key: get_from_data(key) or
                get_from_art(key) or
                get_art(key)
                for key in art_keys}
    return art_dict


def addDir(name, url, mode='', icon='', thumb='', fanart='', poster='',
           banner='', clearart='', clearlogo='',
           genre='', year='', rating='', dateadded='', plot='',
           section='', code='', studio='', subdir='', data={},
           isFolder=True, total=1):

    urlparams = {'url': url, 'name': name, 'mode': mode, 'data': repr(data)}

    u = f'{sysaddon}?{urlencode(urlparams)}'

    liz = xbmcgui.ListItem(name)
    contextmenu = []
    contextmenu.append(('Informacja', 'Action(Info)'))
    info = {
        'title': name,
        'genre': genre or data.get('genre'),
        'year': year or data.get('year'),
        'rating': rating or data.get('rating'),
        'dateadded': dateadded or data.get('dateadded'),
        'plot': plot or data.get('plot'),
        'code': code or data.get('code'),
        'studio': studio or data.get('studio')
    }
    if data.get('nextpage'):
        liz.setProperty('SpecialSort', 'bottom')
    liz.setInfo(type='video', infoLabels=info)
    liz.setArt({
        'thumb': thumb or data.get('poster'),
        'icon': icon or data.get('poster'),
        'fanart': fanart or data.get('fanart'),
        'poster': poster or data.get('poster'),
        'banner': banner or data.get('banner'),
        'clearart': clearart or data.get('clearart'),
        'clearlogo': clearlogo or data.get('clearlogo'),
    })
    liz.addContextMenuItems(contextmenu)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,
                                isFolder=isFolder, totalItems=total)


def addLink(name, url, mode='', icon='', thumb='', fanart='', poster='',
            banner='', clearart='', clearlogo='', genre='', year='', data={},
            rating='', dateadded='', plot='', code='', studio='', pic='',
            isFolder=False, total=1, type='video', section='', page='', subdir=''):

    urlparams = {'url': url, 'name': name, 'mode': mode, 'img': thumb,
                 'fanart': fanart, 'poster': poster,
                 'section': section, 'subdir': subdir, 'page': page,
                 'data': repr(data)
                 }
    u = f'{sysaddon}?{urlencode(urlparams)}'

    liz = xbmcgui.ListItem(name)
    contextmenu = []
    if Getsetting('download.opt') == 'true':
        urlparams['download'] = True
        udl = f'{sysaddon}?{urlencode(urlparams)}'
        contextmenu.append(('Pobierz', f'RunPlugin({udl})'), )

    contextmenu.append(('Informacja', 'Action(Info)'))
    info = {
        'title': name,
        'episode': data.get('episode'),
        'season': data.get('season'),
        'genre': genre or data.get('genre'),
        'year': year or data.get('year'),
        'rating': rating or data.get('rating'),
        'dateadded': dateadded or data.get('dateadded'),
        'plot': plot or data.get('plot'),
        'code': code or data.get('code'),
        'studio': studio or data.get('studio'),
        'tvshowtitle': data.get('tvshowtitle')
    }
    liz.setProperty('IsPlayable', 'true')
    liz.setInfo(type, infoLabels=info)
    liz.setArt({
        'thumb': thumb,
        'icon': icon,
        'fanart': fanart or data.get('fanart'),
        'poster': poster or data.get('poster'),
        'banner': banner or data.get('banner'),
        'clearart': clearart or data.get('clearart'),
        'clearlogo': clearlogo or data.get('clearlogo'),
    })

    liz.addContextMenuItems(contextmenu)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,
                                isFolder=isFolder, totalItems=total)

def addItem(name, url, mode='',
            icon='', thumb='', fanart='', poster='',
            banner='', clearart='', clearlogo='',
            data={}, isFolder=False,
            ):
    '''
    mediatype: tvshow, movie
    '''

    art_dict = set_art_dict(locals())
    urlparams = {'url': url, 'name': name, 'mode': mode,
                 'data': repr(data)
                 }
    u = f'{sysaddon}?{urlencode(urlparams)}'
    contextmenu = []

    liz = xbmcgui.ListItem(name)
    v_tag = liz.getVideoInfoTag()
    v_tag.setTitle(name)
    if data.get('year'):
        v_tag.setYear(data.get('year', 0))
    v_tag.setPlot(data.get('plot'))
    v_tag.setGenres(data.get('genre', []))  # lista
    if data.get('premiered'): #date object
        v_tag.setPremiered(data.get('premiered'))
    if data.get('rating'):
        v_tag.setRating(data.get('rating'))

    v_tag.setProductionCode(data.get('code'))
    v_tag.setWriters(data.get('writer', []))
    v_tag.setDirectors(data.get('director', []))
    if data.get('castandart'):
        v_tag.setCast([xbmc.Actor(name=item['name'],
                                  role=item['role'],
                                  thumbnail=item['thumbnail'])
                       for item in data.get('castandart', [])])
    if isFolder:

        if data.get('mediatype') == 'tvshow':
            v_tag.setMediaType('tvshow')
            v_tag.setTvShowTitle(name)
            v_tag.setSeason(int(data.get('season', 1)))
        if data.get('nextpage'):
            liz.setProperty('SpecialSort', 'bottom')
        if data.get('previouspage'):
            liz.setProperty('SpecialSort', 'top')
        # v_tag.setUniqueID(data.get('title_ID'))

    else:
        if data.get('mediatype') == 'tvshow':
            v_tag.setMediaType('episode')
            v_tag.setTvShowTitle(name)
            v_tag.setSeason(int(data.get('season', 1)))
            v_tag.setEpisode(int(data.get('episode')))
            # v_tag.setUniqueID(data.get('episode_ID'))
        else:
            v_tag.setMediaType('movie')
        liz.setProperty('IsPlayable', 'true')
    liz.setArt(art_dict)
    liz.addContextMenuItems(contextmenu)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,
                                isFolder=isFolder)  # , totalItems=total)




def get_params():
    paramstring = sys.argv[2]
    if paramstring.startswith('?'):
        paramstring = paramstring[1:]
    params = dict((k, vv[0]) for k, vv in parse_qs(paramstring).items())
    if params.get('data'):
        params['data'] = literal_eval(params['data'])
    return params


def endOfDir():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def PlayFromHost(url, title, subdir, mode='play', data={}):
    meta = data
    d = xbmcgui.Dialog()
    download = get_params().get('download')
    # context
    if download == 'True':
        mode = 'download'
    else:
        if Getsetting('download.dialog') == 'true' and Getsetting('download.opt') == 'true':
            ret = d.yesno('Pobierz lub oglądaj', 'Wybierz opcję', 'Oglądaj', 'Pobierz')
            if ret:
                mode = 'download'
            #else:
            #    mode = 'play'
        #else:
        #    mode = 'play'

    if 'google' in url:
        url = url.replace('preview', 'view')

    stream_providers = {'vk.com': 'get_vk_stream',
                        'ok.ru': 'get_ok_stream'
                        }
    if '//mega.nz' in url:
        port = cache.cache_get('proxyport')['value']

        stream = getstream.get_mega_stream(url)
        proxy_url = f"http://localhost:{port}/?url={stream.url}&type=mega&mega_data={stream.data}"

        #encoded_url = quote_plus(url)
        #proxy_url = f"http://localhost:{port}/?url={encoded_url}&type=mega"

        if mode == 'play':
            li = xbmcgui.ListItem(title, path=proxy_url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

    try:
        if any(provider in url for provider in stream_providers.keys()):

            for ul in stream_providers.keys():
                if ul in url:
                    stream = getattr(getstream, stream_providers[ul])(url)
                    break
                else: continue


            log(f'MPD sending to ISA : {stream.url}', 0)
            PROTOCOL = 'mpd'
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                li = xbmcgui.ListItem(title, path=stream.url)
                li.setMimeType('application/xml+dash')
                li.setContentLookup(False)
                li.setProperty('inputstream', is_helper.inputstream_addon)
                li.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                #li.setProperty('inputstream.adaptive.license_type', DRM)
                #li.setProperty('inputstream.adaptive.license_key', '|' + stream_header)
                li.setProperty('inputstream.adaptive.stream_headers', stream.header)
                #li.setProperty('IsPlayable', 'true')
                xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
        else:
            try:
                import resolveurl
                stream_url = resolveurl.resolve(url)
                log(f'wynik z resolve  :{str(stream_url)}', 0)

                if mode == 'play':
                    li = xbmcgui.ListItem(title, path=str(stream_url))
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

                elif mode == 'download':
                    from resources.libs import downloader
                    dest = Getsetting("download.path")
                    downloader.download(title, 'image', stream_url, dest, subdir)
            except Exception as e:
                d.notification('Drama-Online ',
                               f'[COLOR red]{repr(e)}[/COLOR]',
                               xbmcgui.NOTIFICATION_INFO, 5000)
                log(f'wynik resolve: {repr(e)}', 0)
                return
    except Exception as e:
        print(f"❌ Błąd: {repr(e)}")
        d.notification('Drama-Online ',
                       '[COLOR red]Problem  -  Nie można wyciągnąć linku[/COLOR]',
                       xbmcgui.NOTIFICATION_INFO, 5000, False)
        return


def SourceSelect(players, links, title, data={}):


    subdir = data.get('tvshowtitle', flat_title(title))

    log(f'wynik subdir: {title}', 0)
    hostDict = cache.get(get_hostList, 720)

    if len(players) == 1:
        link = links[0]
        PlayFromHost(link, title=title, subdir=subdir, data=data)

    elif len(players) > 1:
        valid_list = []
        for i in zip(players, links):
            if '//mega.nz'in i[1].lower():
                valid_list.append(['MEGA', i[1]])
            #valid_list.append(i)
            valid, host = is_host_valid(i[1], hostDict)
            if valid:
                valid_list.append([host, i[1]])
        if len(valid_list) == 1:
            print('wait')
            link = valid_list[0][1]
            PlayFromHost(link, title=title, subdir=subdir, data=data)
        else:
            d = xbmcgui.Dialog()
            select = d.select('Wybór playera', [i[0] for i in valid_list])
            if select > -1:
                link = [i[1] for i in valid_list][select]
                PlayFromHost(link, title=title, subdir=subdir, data=data)
            else:
                pass
    else:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Brak linków')

def idle():
    return execute('Dialog.Close(busydialog)')

def openSettings(query=None, id=my_addon.getAddonInfo('id')):
    try:
        idle()
        execute(f'Addon.OpenSettings({id})')
        if query == None: query = '0.0'
        c, f = query.split('.')
        execute(f'SetFocus({int(c) - 100})')
        execute(f'SetFocus({int(f) - 80})')

    except:
        return
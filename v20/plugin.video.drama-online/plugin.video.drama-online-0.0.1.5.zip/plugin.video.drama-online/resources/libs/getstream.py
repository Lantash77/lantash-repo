import requests
import re
import json
from urllib.parse import quote_plus, urlencode
from resources.libs.helper import *
from dataclasses import dataclass
from typing import Optional, Dict

@dataclass
class Stream():
    url: str
    header: Optional[str] = ''
    data: Optional[str] = ''

sess = requests.session()

UA = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'


def get_vk_stream(videolink):

    headers = {'user-agent': UA,
               'Referer': 'https://vk.com/',
               }

    r = sess.get(videolink, headers=headers)
    manifest_dash = re.findall('dash_sep":"(.+?)"', r.text)[0].replace('\\', '')

    return Stream(manifest_dash, header=urlencode(headers))

def get_ok_stream(videolink):

    headers = {'user-agent': UA,
               'Referer': 'https://vk.com/',
               }

    r = sess.get(videolink, headers=headers)
    r = unescape(r.text)
    if match := re.search(r'"metadata":"({.+?})"', r, re.DOTALL):
        metadata_raw = match.group(1)
        # Dekodujemy escape sequence jak \u0026 i podwójne slashe
        metadata_unescaped = bytes(metadata_raw, "utf-8").decode("unicode_escape")
        metadata_json = json.loads(metadata_unescaped)
        manifest_dash = metadata_json['metadataUrl']
    else:
        r = r.replace('\\u0026', '&').replace('\&', '&').replace('\\"', '\"')
        #r = r.replace('&quot;', '"').replace('\\"', '\"')
        manifest_dash = re.findall('metadataUrl":"(.+?)"', r)[0]

    return Stream(manifest_dash, header=urlencode(headers))

def get_mega_stream(videolink):
    from resources.megamine import Mega
    from resources.megamine.crypto import base64_to_a32, a32_to_str, decrypt_attr, base64_url_decode
    mega = Mega()
    file_id, file_key = mega._parse_url(videolink).split('!')
    key = base64_to_a32(file_key)
    # Dekodowanie klucza
    k = (
        key[0] ^ key[4],
        key[1] ^ key[5],
        key[2] ^ key[6],
        key[3] ^ key[7]
    )
    k_str = a32_to_str(k)
    iv = key[4:6] + (0, 0)

    file_data = mega._api_request({'a': 'g', 'g': 1, 'p': file_id})
    file_url = file_data['g']
    file_size = file_data['s']
    #file_name = decrypt_attr(base64_url_decode(file_data['at']), k)['n']
    mega_data = {'k_str': k_str,
                 'iv': iv,
                 'file_size': file_size
                 }
    meg_str = repr(mega_data)
    meg_str = quote_plus(meg_str)
    return  Stream(file_url, data=meg_str)
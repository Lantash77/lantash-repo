import requests
import re
import json
from resources.libs.helper import *

sess = requests.session()

UA = 'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0'


def getstream(videolink):  # TEST Function - not for addon


    headers = {'user-agent': UA,
               'Referer': 'https://vk.com/',
               'Origin': 'https://vk.com',
               }

    r = sess.get(url, headers=headers)


    manifest_dash = re.findall('dash_uni":"(.+?)"', r.text)[0].replace('\\', '')
    hls_list_url = re.findall('hls":"(.+?)"', r.text)[0].replace('\\', '')
    hls_stream_list = sess.get(hls_list_url, headers=headers).text
    hls_stream_urls = sorted(re.findall('RESOLUTION=(.+?)\s(https.+)', hls_stream_list))

    max_ = hls_stream_urls[-1][1]
    #SD = hls_stream_urls[0][1]
    #ask = [i[0] for i in hls_stream_urls]



    #st = sess.get(max, headers=headers)
    return manifest_dash, headers

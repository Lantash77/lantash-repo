# -*- coding: UTF-8 -*-
#####Python3.8

import re
import sys
import os
import threading
import requests
import json
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus
from html import unescape
from resources import libs
from resources.libs.helper import *
from resources.libs.dohelper import fetch_page
from resources.libs.addon_tools import *
from resources.libs import cache
from resources.libs.log_utils import plog, log




DATA_PATH = libs.DATA_PATH
GetSetting = libs.GetSetting
MEDIA = libs.MEDIA
LETTERS = libs.LETTERS
searchFile = os.path.join(DATA_PATH, "search.db")

BASE_LINK = f'https://drama-online.pl/{{}}'
SEARCH_URL = f'https://drama-online.pl/?s={{}}'

############################################################################################################
############################################################################################################
#                                                   MEDIA                                                  #
############################################################################################################
default_background = MEDIA + 'fajnadramabkg.jpg'
default_icon = MEDIA + 'ikonadrama.png'
search_icon = MEDIA + 'search.png'
nexticon = MEDIA + 'next.png'
iconsettings = MEDIA + 'settings.png'
Letter = {c: f"{LETTERS}{c}.png" for c in '1' + string.ascii_uppercase}
############################################################################################################
############################################################################################################
#                                                   MENU                                                   #
############################################################################################################

def MainMenu():

    addItem('Dramy Koreańskie', BASE_LINK.format('dramy-koreanskie/'), 'Alphalist',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Dramy Japońskie', BASE_LINK.format('dramy-japonskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Dramy Chińskie', BASE_LINK.format('dramy-chinskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Dramy Tajwańskie', BASE_LINK.format('dramy-tajwanskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Dramy Tajlandia', BASE_LINK.format('dramy-tajlandzkie-lakorny/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Filmy Koreańskie', BASE_LINK.format('filmy-koreanskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Japońskie', BASE_LINK.format('filmy-japonskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Chińskie', BASE_LINK.format('filmy-chinskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Tajwańskie', BASE_LINK.format('filmy-tajwanskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Tajlandia', BASE_LINK.format('filmy-tajlandzkie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Pozostałe pozycje', '', 'OtherMenu',
			data={'fanart': default_background, 'thumb': default_icon},
            isFolder=True)
#    addDir("Wyszukiwanie", '', 'search',
#           fanart=default_background, thumb=search_icon)
    ###Ustawienia###
    addItem('Ustawienia', '', 'settings',
			data={'fanart': default_background, 'thumb': iconsettings},
            isFolder=True)

def OtherMenu():

    addItem('Dramy Hong Kong', BASE_LINK.format('dramy-hong-kong/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
			isFolder=True)
    addItem('Dramy Filipińskie', BASE_LINK.format('dramy-filipinskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Dramy Indyjskie', BASE_LINK.format('dramy-indyjskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'tvshow'},
            isFolder=True)
    addItem('Filmy Hong Kong', BASE_LINK.format('filmy-hong-kong/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Singapur', BASE_LINK.format('filmy-singapurskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Filipińskie', BASE_LINK.format('filmy-filipinskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)
    addItem('Filmy Indyjskie', BASE_LINK.format('filmy-indyjskie/'), 'ListTitles',
			data={'fanart': default_background, 'thumb': default_icon, 'mediatype': 'movie'},
            isFolder=True)

############################################################################################################
# =##########################################################################################################
#                                                 FUNCTIONS                                                #
# =##########################################################################################################

def Alphalist():

	url = params['url']
	res = cache.get(fetch_page, 48, url)

	sections = parseDOM(res, 'div',
						{'class': 'elementor-widget-container'})[1:-1]
	for section in sections:
		link = parseDOM(section, 'a', ret='ref')[0]
		desc = parseDOM(section, 'a')[0].replace('\n', '').replace('\t', '')
		desc = clear_HTML_tags(desc)
		data = {'fanart': default_background,
				'thumb': Letter[desc],
				'poster': Letter[desc],
				'mediatype': 'tvshow'}

		addItem(desc, link, 'ListTitles',
				        data=data, isFolder = True)



def ListTitles(url=''):

    #plog(f'{url} ################## Test', 1)
    if not url:
        url = params['url']
    data = params['data']

    if data['mediatype'] == 'tvshow':
        type = 'tvshow'
        isFolder = True
    else:
        type = 'movie'
        isFolder = False
    res = cache.get(fetch_page, 48, url)

    #sections = parseDOM(res, 'figure',
    #                    {'class': 'wp-caption'})

    try:
        #titlebox = parseDOM(res, 'div', {'data-elementor-type': 'wp-page'})
        #titlebox = CleanHTML(titlebox)
        sections = parseDOM(res, 'figure',
                            {'class': 'wp-caption'})
    except IndexError:
        plog(f'unable to parse {url} ', 1)

    title_list = []
    for section in sections:

        if 'PORZUCONE' in section:
            break
        else:
            try:
                meta = {'title': parseDOM(section, 'figcaption')[0],
                        'link': parseDOM(section, 'a', ret='href')[0],
                        'poster': parseDOM(section, 'img', ret='src')[0],
                        # 'plot': parseDOM(section, 'p', )[-1],
                        'mediatype': type
                        }
            except IndexError:
                # pomijanie śmieciowych nagłówków
                plog(f'Błąd parsowania sekcji {repr(section)}', 1)

                continue

            title_list.append(meta)

    #plog(repr(title_list), 1)
    #print('wait')
    for title in title_list:
        try:
            if title['link'][-1] != '/':
                title['link'] = f"{title['link']}/"
        except IndexError:
            continue
        # print('dupa')
        #plog(f'{title["title"]} --- {title["link"]} ---  {title["poster"]}', 1)
        addItem(title['title'], title['link'], 'ListEpisodes',
                data=title, isFolder = isFolder)


def ListEpisodes():

    url = params['url']
    data_t = params['data']

    res = cache.get(fetch_page, 48, url)
    res = unescape(res)

    episodes = parseDOM(res, 'div', attrs={'class': 'su-spoiler .+?'})

    try:
        databox = parseDOM(res, 'div', attrs={'data-elementor-type': 'wp-post'})[0]
        reduce_list = ['obsada:', 'tłumaczenie:']
        plotscan = parseDOM(databox, 'p')
        plotscan = [i for i in plotscan if not any(r in i.lower() for r in reduce_list)]
        year = re.search(r'Rok.+?(\d{4})', databox)
        if year:
            year = year.group(1)

    except IndexError:

        print(f'Failed url: {url}')
        """
        databox = parseDOM(res, 'div', attrs={'class': 'entry-content clr'})[0]
        databox = CleanHTML(databox).replace("\r", "").replace("\n", "").replace('<br />', ' ')
        year = re.search(r'Rok.+?(\d{4})', databox)
        if year:
            year = year.group(1)
        plotscan = re.findall('<p.+?>(.+?)</p>', databox)

        exclude = ['<span>', '</span>', '<img', 'obsada:', 'tłumaczenie:', 'korekta:']
        plotscan = [i for i in plotscan if not any(r in i.lower() for r in exclude)]
        """
    plotscan = CleanHTML('\n'.join(plotscan))
    plot = re.sub(r'<span .*?>|</span>', '', plotscan)
    plot = plot.replace('<strong>', '').replace('</strong>', '\n')
    poster = parseDOM(databox, 'img', ret='src')[0]

    # Przygotowanie regex wyodrebniający odcinki
    # Obsługa filmów podzielonych na części
    multipart = False
    if data_t['mediatype'] == 'movie':
        if len(episodes) > 1:
            multipart = True
            parts = []
        pattern = re.compile(r'Pokaż (.+?)</')

    else:
        pattern = re.compile(r'Pokaż ([Oo]dcinek \d+(?:-\d+)?)')

    for episode in episodes:
        try:
            title = re.findall(pattern, episode)[0].capitalize()
            # title = re.sub('<span(.+?)</span>', '', parseDOM(episode, 'div', {'class': 'su-spoiler-title'})[0])
        except IndexError:
            plog(f'Failed parse episode: {url}', 1)
            continue

        data = {
            'title': title,
            'poster': poster,
            'plot': plot,
            'mediatype': data_t['mediatype'],
            'data_block': episode.replace('src="//', 'src="https://')
        }
        # obsługa seriali
        if data_t['mediatype'] == 'tvshow':
            tvshow_data = {'tvshowtitle': data_t.get('title'),
                           'season': '01',
                           'episode': re.findall(r'\d+', title)[0]}
            data.update(tvshow_data)
            #print(data['title'], data['data_block'])
            addItem(data['title'], data_t['link'], 'ListLinks',
                    fanart=poster, thumb=data['poster'], data=data,
                    isFolder=False)
        # Obsługa filmów
        else:
            if multipart:
                parts.append(data)
            else:
                ListLinks(data)
    if multipart:
        dialog = xbmcgui.Dialog()
        select = dialog.select('Odtwórz część', [i['title'] for i in parts])
        if select > -1:
            ListLinks(parts[select])
        else:
            pass

    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')

def ListLinks(data=''):

    if not data:
        data = params['data']

    name = params['name']
    if data['data_block'].startswith('<div class'):
        links = parseDOM(data['data_block'], 'iframe', ret='src')
    if data['data_block'].startswith('<div class'):
        links += re.findall(r'https?://[^\s"<>\']+', data['data_block'])
    if 'skopiuj link' in data['data_block']:
        links += re.findall(r'https?://[^\s"<>\']+', data['data_block'])

    links = list(set(links))
    for link in links:
        if not link.startswith('http'):
            links[links.index(link)] = f'https:{link}'
    players = [f'Player {i + 1}' for i in range(len(links))]

    SourceSelect(players, links, title=name, data=data)


def Szukaj():

    addDir("[B]Nowe wyszukiwanie...[/B]", '', 'SearchNew',
           fanart=default_background, thumb=search_icon)

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass

    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            url = SEARCH_URL.format(quote_plus(term))
            addDir(term, url, 'ListTitles', fanart=default_background, thumb=search_icon)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
               fanart=default_background, thumb=search_icon)

def Szukaj_Nowy():

    keyb = xbmc.Keyboard('', "Wyszukiwarka")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        term = keyb.getText()
    else: Szukaj()
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, term))
    dbcon.commit()
    dbcur.close()

    url = SEARCH_URL.format(quote_plus(term))
    ListTitles(url)

def clear_search():

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DROP TABLE IF EXISTS movies")
    dbcur.execute("VACUUM")
    dbcon.commit()
    dbcur.close()
    Szukaj()


def PathCheck():
    if GetSetting('download.path') == '':
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Ustawień Pobierania',
                           'Włączono pobieranie, ale nie ustawiono ścieżki pobierania \nWprowadź scieżkę pobierania w ustawieniach',
                           'Wyjdź', 'Ustawienia')
        if ret:
            libs.my_addon.openSettings()
            xbmc.executebuiltin('Container.Refresh')
        else:
            exit()
    else:
        return


def ScrapInfo(threads):
    while True:
        if xbmc.Player().isPlaying():

            for thread in threads:
                while True:
                    if xbmc.Player().isPlaying() and threading.active_count() < 20:
                        time.sleep(2)
                        thread.start()
                        break
                    else:
                        time.sleep(2)
        else:
            time.sleep(2)


############################################################################################################
# =#########################################################################################################
#                                               GET PARAMS                                                 #
# =#########################################################################################################
t = sys.argv
params = get_params()

url = params.get('url')
name = params.get('name')
img = params.get('img')
section = params.get('section')

try:
    mode = params.get('mode')
except:
    mode = None

############################################################################################################
############################################################################################################
#                                                   MODES                                                  #
############################################################################################################

if GetSetting('download.opt') == 'true':
    PathCheck()
if mode == None:
    MainMenu()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode == 'Alphalist':
	Alphalist()
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode == 'OtherMenu':
    OtherMenu()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 'ListTitles':
    ListTitles()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 'ListEpisodes':
    ListEpisodes()
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

elif mode == 'ListLinks':
    ListLinks()
    xbmcplugin.setContent(int(sys.argv[1]), 'files')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


elif mode == 'search':
    Szukaj()
    #    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Scrapper cleaning
elif mode == 7:
    #from resources.libs.dqscraper import delete_table
    #delete_table()
    pass

# Brak linku - monit
elif mode == 8:
    dialog = xbmcgui.Dialog()
    dialog.notification('Drama-Online ', '[COLOR=red]Brak odcinka.[/COLOR]', xbmcgui.NOTIFICATION_INFO, 5000)

elif mode == 'ClearCache':
    # clear cache but leave port value cached
    proxyport = cache.cache_get('proxyport')['value']
    t = cache.cache_clear()
    if t:
        dialog = xbmcgui.Dialog()
        dialog.notification('Drama-Online ', '[COLOR=gold]Wyczyszczono cache.[/COLOR]',
                            xbmcgui.NOTIFICATION_INFO, 5000)
    cache.cache_insert('proxyport', proxyport)
    #    execute('Container.Refresh')
    endOfDir()


elif mode == 'clear_search':
    clear_search()
    execute('Container.Refresh')

elif mode == 'SearchNew':
    Szukaj_Nowy()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode == 'settings':
    libs.my_addon.openSettings()
    xbmc.executebuiltin('XBMC.Container.Refresh()')

############################################################################################################


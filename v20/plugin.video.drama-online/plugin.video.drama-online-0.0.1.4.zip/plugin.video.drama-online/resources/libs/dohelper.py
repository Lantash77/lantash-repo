import json
import requests
import xbmc
import xbmcgui
import time
from . import cache
from .. import libs


sess = requests.session()
COOKIE = 'dramaonline_cookie'
headersget = {'user-agent': libs.UA}
settings = libs.settings

def Logowanie(popup=False):

    data = {
        'log': settings.getString('user'),
        'pwd': settings.getString('pass'),
        'rememberme': 'forever',
        'wp-submit:': 'Zaloguj się',
        'redirect_to': 'https://drama-online.pl/wp-admin/',
        'testcookie': '1'
    }

    GetLogin = sess.post('https://drama-online.pl/wp-login.php', headers=headersget, data=data)
    response = GetLogin.status_code
    #GetLogin = GetLogin.text
    kuki = sess.cookies.get_dict()
    #cookie = "; ".join([f'{k}={v}' for k, v in kuki.items()])
    cache.cache_insert(COOKIE, json.dumps(kuki))

    ###LoginCheck - server error handling

    if response == 200:

        if logged_in(kuki):
            if popup == True:

                dialog = xbmcgui.Dialog()
                dialog.notification('drama-online.pl ', 'Zalogowano pomyślnie.',
                                    xbmcgui.NOTIFICATION_INFO, 5000, sound=False)
            else:
                pass
        else:
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno('Nie jesteś zalogowany',
                               'Zarejestruj się na drama-online.pl. \nWprowadź dane logowania w ustawieniach wtyczki' ,
                               'Wyjdź', 'Ustawienia')
            if ret:
                libs.my_addon.openSettings()
                xbmc.executebuiltin('Container.Refresh')
    else:
        d = xbmcgui.Dialog()
        d.notification('drama-online.pl ',
                       f'[COLOR red]Problem  -  Błąd serwera - {str(response)}[/COLOR]',
                       xbmcgui.NOTIFICATION_INFO, 5000)
        exit()

def logged_in(cookies):
    ok = 'wordpress_logged_in'
    for key in cookies.keys():
        if ok in key:
            return True
    return False

def get_cookie():

    now = int(time.time())
    exp = 1209600  # 14 days cookie valid
    cached_cookie = cache.cache_get(COOKIE)
    if cached_cookie:
        if now - cached_cookie['date'] > exp:
            Logowanie()
            return json.loads(cache.cache_get(COOKIE)['value'])
        return json.loads(cached_cookie['value'])
    else:
        Logowanie(True)
        return json.loads(cache.cache_get(COOKIE)['value'])


def fetch_page(url, res=True):

    if '/?p=' in url:
        url = requests.get(url, headers=headersget, cookies=get_cookie()).history[-1].url
    resp = requests.get(url, headers=headersget, cookies=get_cookie(), timeout=10)
    if res:
        return resp.text
    return resp
# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Wbijam.pl
# Some part of code from Huball
###############################################################################
###############################################################################
### Imports ###
#import re
#import sys
import re

import requests
from copy import deepcopy
#import time
#from urllib.parse import unquote_plus

#from resources import libs
from resources.libs.addon_tools import *
from resources.libs.helper import *
from resources.libs.worker import *
from resources.libs import scraper
from resources.libs import cache

MEDIA = libs.MEDIA
params = get_params()
BASE_URL = 'https://inne.wbijam.pl/'
#media#
default_background = MEDIA + "fanart.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
fanartWb = MEDIA + 'wbijam.jpg'
host = 'Wbijam'


def Pagewbijam():

    result = requests.get(BASE_URL, timeout=15).text
    drop_list = ['>Menu główne', '>Reklama', '>Kąciki tematyczne']
    for d in drop_list:
        result = re.sub(d, '', result)
    data = [item for item in parseDOM(result, 'div', {'class': 'pmenu_naglowek_' + r'.'})
            if len(item) > 0]
    if len(data) > 0:
        for item in data:
            name = item
            addDir(name, BASE_URL, 'Browse_Titles',
                   data={'thumb': fanartWb, 'fanart': default_background}
                   )


def Browse_Titles():

    url = params['url']
    name = params['name']
    html = requests.get(url, timeout=15).text.replace("\r", "").replace("\n", "")
    data_block = re.findall(rf'>{name}</div>(.+?)</ul', html)[0]
    if name == 'Dostępne serie anime':
        ongoing = 'menu_polecane_header_ongoing'
        all = 'menu_polecane_header_all'
        reduce_block = re.sub(f'''{ongoing}.+?{all}''', '', data_block, re.DOTALL)
        data_block = reduce_block
    title_list = [[parseDOM(i, 'a')[0], parseDOM(i, 'a', ret='href')[0]]
                  for i in parseDOM(data_block, 'li')]
    reduce_dupes = {i[0]: i for i in title_list}
    title_list = [i for i in reduce_dupes.values()]
    title_list.sort()
    ## removing unused item form list
    title_list = [i for i in title_list if not 'Anime online' in i[0]]
    title_list = [i for i in title_list if not 'inne.wbijam' in i[1].lower()]
    title_lst = [i[0] for i in title_list]

    def scrap_meta(titles):
        fix_titles = []
        for tytul in titles:
            # wyjątki skrapera

            if tytul == 'Decadence': tytul = 'Deca-dence'
            if tytul == 'HunterxHunter': tytul = 'Hunter x Hunter'
            if tytul == 'Kanon(2006)': tytul = 'Kanon'
            fix_titles.append(tytul)

        #Nowy scraper -
        ids = thread_it_multi(scraper.find_tmdb_ID, 0, fix_titles, 'tv', '', 'ja')
        tmdb = thread_it_multi(scraper.Get_meta, 0, ids, fix_titles, 'tv')
        meta = [x + [y] for x, y in zip(title_list, tmdb)]
        return meta

    items = cache.get(scrap_meta, 24, title_lst)
    #items = scrap_meta(title_lst)

    for item in items:
        data = {}
        tytul = item[0]
        link = item[1]
        data = item[2]
        section = 'polecane'
        if not re.search('^https://.+?', link):
            link = f'{BASE_URL}{link}'
            section = 'other'
        data.update({'section': section,
                     'subdir': tytul,
                'anime_page': url})
        #data['section'] = section
        #data['subdir'] = tytul
        #data['anime_page'] = url

        addDir(tytul, link, 'Browse_Seasons', data=data)


def Browse_Seasons():

    url = params['url']
    data = params['data']
    name = params['name']
    #####
    subdir = data['subdir']
    section = data['section']
    
    if section == 'polecane':
        html = requests.get(url, timeout=15).text
        result = parseDOM(html, 'ul', attrs={'class': 'pmenu'})[1]
        result = parseDOM(result, 'li')
        results = [[parseDOM(item, 'a')[0] for item in result],
                   [parseDOM(item, 'a', ret='href')[0] for item in result]]
        exclude = ['Openingi', 'Endingi', 'openingi.html', 'endingi.html']
        for r in results:
            [r.remove(ex) for ex in exclude if ex in r]
        def find_season(val):
            sezony_dict = {
                '0': ['ova', 'odcinki specjalne', 'specjale'],
                '1': ['pierwsza'],
                '2': ['druga'],
                '3': ['trzecia'],
                '4': ['czwarta'],
                '5': ['piata'],
                '6': ['szósta']}
            for key, values in sezony_dict.items():
                for v in values:
                    if val.lower().__contains__(v.lower()):
                        return key
            return None

        seasons = len(results[0])
        if seasons <= 1:
            ####
            link = results[1][0]
            link = f'{url}{link}'
            data['anime_page'] = url
            List_Episodes(link)
        else:
            # season handle
            exemptions = ['Naruto', 'HunterxHunter']
            for title, link in zip(*results):
                meta = deepcopy(data)
                link = f'{url}{link}'
                if name in exemptions:
                    # Naruto i HunterxHunter
                    regex = re.compile('(\d+){4}')
                    rok = re.search(regex, title)
                    if rok:
                        rok = rok.group(0)
                        tit = title.split(rok)[0].strip()
                        if tit == 'HunterxHunter': tit = 'Hunter x Hunter'
                    else:
                        tit = re.sub(r'\(.+?\)', '', title).strip()
                    tmdb_id = scraper.find_tmdb_ID(tit, 'tv', rok, 'ja')
                    if isinstance(tmdb_id, int):
                        meta = scraper.Get_meta(tmdb_id, tit, 'tv')
                    else: meta = data
                else:
                    # rozpoznawanie sezonów
                    season = find_season(title)
                    if season:
                        meta['season'] = season
                        try:
                            season_poster = [i.get('poster_path')
                                             for i in meta.get('seasons', [])
                                             if i.get('season_number') == int(season)][0]
                            if season_poster:
                                meta['poster'] = season_poster
                                meta['thumb'] = season_poster
                        except IndexError:
                            pass
                meta['anime_page'] = url
                meta['section'] = section
                meta['subdir'] = f'{subdir} {title}'
                addDir(title, link, 'List_Episodes', data=meta)

    elif section == 'other':
            html = requests.get(url, timeout=15).text
            result = parseDOM(html, 'h1', {'class': 'pod_naglowek'})

            if len(result) > 1:
                for item in result:
                    meta = deepcopy(data)
                    meta['section'] = 'multi'
                    meta['anime_page'] = item
                    meta['subdir'] = f'{subdir} {item}'
                    addDir(item, url, 'List_Episodes',
                                #thumb=str(img), fanart=default_background, page=item,
                                #section='multi',
                                #subdir=subdir + ' ' + item,
                                data=meta)
            elif len(result) <= 1:
                List_Episodes()
    

def List_Episodes(url=None):

    if not url:
        url = params['url']
    name = params['name']
    data = params['data']
    section = data['section']
    page = data.get('anime_page')
    #img = params.get('img')
    subdir = data['subdir']
   
    ###   Listowanie Polecanych
    if section == 'polecane':
        result = requests.get(url).text
        result = parseDOM(result, 'table', {'class': 'lista'})[0]
        result = parseDOM(result, 'tr', {'class': 'lista_hover'})
        link = [page + parseDOM(item, 'a', ret='href')[0] for item in result]
        tytul = [str(parseDOM(item, 'img')[0]).split("</a>")[0] for item in result]

        data_emisji = [parseDOM(item, 'td', {'class': 'center'})[1] for item in result]
        for item in zip(link, tytul, data_emisji):
            meta = deepcopy(data)
            meta['subdir'] = subdir
            meta['code'] = f'[B][COLOR=blue]{item[2]}[/COLOR][/B]'
            addItem(item[1], item[0], 'List_Links',
                         #thumb=img, fanart=pic, page=name,
                         #section='polecane', subdir=subdir,
                         data=meta, isFolder=False)

    ####  Listowanie pozostalych z wieloma sezonami
    elif section == 'multi':
        result = requests.get(url).text
        slice = GetDataBeetwenMarkers(result, '<h1 class="pod_naglowek">' + name, '</table>', False)[1]

        results = parseDOM(slice, 'tr', {'class': 'lista_hover'})
        tytul = [parseDOM(item, 'img')[0].split('</td>')[0] for item in results]
        #link = BASE_URL

        for item in tytul:
            data['section'] = 'multi'
            addItem(item, url, 'List_Links',
                    #thumb=str(img),
                    #     fanart=pic, page=name,
                    #section='multi',
                    #     subdir=subdir,
                    data=data, isFolder=False)
    ####  Listowanie pozostalych pojedynczych
    else:
        result = requests.get(url).text
        result = parseDOM(result, 'tr', {'class': 'lista_hover'})
        tytul = [parseDOM(item, 'img')[0].split('</td>')[0] for item in result]
        for item in tytul:
            data['section'] = 'other'
            addItem(item, url, 'List_Links',
                #    thumb=str(img),
                #         fanart=pic, page=name,
                #    section='other',
                #         subdir=subdir,
                    data=data, isFolder=False)

    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')

def List_Links():

    url = params['url']
    data = params['data']
    name = params['name']
    subdir = data['subdir']
    section = data['section']
    page = data['anime_page']
    title = params['name']
    
    if section == 'polecane':
        result = requests.get(url).text
        result = parseDOM(result, 'table', {'class': 'lista'})
        result = parseDOM(result, 'tr', {'class': 'lista_hover'})
        status = [parseDOM(item, 'td', {'class': 'center'})[1] for item in result]
        player = [parseDOM(item, 'td', {'class': 'center'})[2] for item in result]
        tlumacz = [parseDOM(item, 'td', {'class': 'center'})[3] for item in result]
        Player = []
        for item in zip(player, tlumacz):
            player_decription = f'{item[0]}  [COLOR {{c}}]{item[1]}[/COLOR]'
            player_decription = player_decription.format(c='green')
            Player.append(player_decription)
        kodlinku = [f"{page}odtwarzacz-{parseDOM(item, 'span', {'class': 'odtwarzacz_link'}, ret='rel')[0]}.html"
                    for item in result]
        link = []
        for item in kodlinku:
            try:
                temp = requests.get(item).text
                if 'vk.com' in temp:
                    l1 = parseDOM(temp, 'span', {'class': 'odtwarzaj_vk'}, ret='rel')[0]
                    l2 = parseDOM(temp, 'span', {'class': 'odtwarzaj_vk'}, ret='id')[0]
                    temp = 'https://vk.com/video' + l1 + '_' + l2
                else:
                    temp = parseDOM(temp, 'iframe', ret='src')[0]
                link.append(temp)
            except:
                continue
        SourceSelect(Player, link, title, subdir)
        
    elif section == 'multi':
        result = requests.get(url).text
        slice = GetDataBeetwenMarkers(result, '<h1 class="pod_naglowek">' + page, '</table>', False)[1]
        results = [item for item in parseDOM(slice, 'tr', {'class': 'lista_hover'}) if title in item]
        kodlinku = parseDOM(results, 'span', {'class': 'odtwarzacz_link'}, ret='rel')

        link = []
        player = []
        for item in kodlinku:
            try:
                item = f'{BASE_URL}odtwarzacz-{item}.html'
                temp = requests.get(item).text
                if 'vk.com' in temp:
                    l1 = parseDOM(temp, 'span', {'class': 'odtwarzaj_vk'}, ret='rel')[0]
                    l2 = parseDOM(temp, 'span', {'class': 'odtwarzaj_vk'}, ret='id')[0]
                    temp = 'https://vk.com/video' + l1 + '_' + l2
                    plr = 'vk'
                else:
                    temp = parseDOM(temp, 'iframe', ret='src')[0]
                    _, plr = is_host_valid(temp, get_hostDict())
                player.append(plr)
                link.append(temp)
            except:
                continue
        SourceSelect(players=player, links=link, title=title, subdir=subdir)
        
    elif section == 'other':
        result = requests.get(url).text
        results = [item for item in parseDOM(result, 'tr', {'class': 'lista_hover'}) if title in item]
        kodlinku = parseDOM(results, 'span', {'class': 'odtwarzacz_link'}, ret='rel')

        link = []
        player = []
        for item in kodlinku:
            try:
                item = f'{BASE_URL}odtwarzacz-{item}.html'
                temp = requests.get(item).text
                if 'vk.com' in temp:
                    l1 = parseDOM(temp, 'span',{'class': 'odtwarzaj_vk'}, ret='rel')[0]
                    l2 = parseDOM(temp, 'span',{'class': 'odtwarzaj_vk'}, ret='id')[0]
                    temp = 'https://vk.com/video' + l1 + '_' + l2
                    plr = 'vk'
                else:
                    temp = parseDOM(temp, 'iframe', ret='src')[0]
                    _, plr = is_host_valid(temp, get_hostDict())
                player.append(plr)
                link.append(temp)
            except:
                continue
        SourceSelect(players=player, links=link, title=title, subdir=subdir)


def GetDataBeetwenMarkers(data, marker1, marker2, withMarkers=True, caseSensitive=True):

    if caseSensitive:
        idx1 = data.find(marker1)
    else:
        idx1 = data.lower().find(marker1.lower())
    if -1 == idx1:
        return False, ''
    if caseSensitive:
        idx2 = data.find(marker2, idx1 + len(marker1))
    else:
        idx2 = data.lower().find(marker2.lower(), idx1 + len(marker1))
    if -1 == idx2:
        return False, ''
    if withMarkers:
        idx2 = idx2 + len(marker2)
    else:
        idx1 = idx1 + len(marker1)
    return True, data[idx1:idx2]


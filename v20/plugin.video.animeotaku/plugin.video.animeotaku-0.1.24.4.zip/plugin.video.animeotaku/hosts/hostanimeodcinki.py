# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Anime-Odcinki
# Some part of code comes from Anonek
# Link decryption fixed for Python 3
###############################################################################
###############################################################################
### Imports ###
#import re, os
#import sys
#import xbmc
#import xbmcgui
#import xbmcplugin

import requests
import json
from resources.libs.addon_tools import *
from resources.libs.helper import *
from resources.libs import cache

from crypto.keyedHash.evp import EVP_BytesToKey
from crypto.cipher.aes_cbc import AES_CBC
from binascii import a2b_hex, a2b_base64
from hashlib import md5


MEDIA = libs.MEDIA
LETTERS = libs.LETTERS
BASE_URL = 'https://anime-odcinki.pl/'
search_url = 'https://anime-odcinki.pl/szukaj/'
searchFile = libs.searchFile
Getsetting = libs.Getsetting
params = get_params()

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
fanartAodc = MEDIA + 'animeodcinki.jpg'
searchicon = MEDIA + 'search.png'

Alfabet = libs.Alfabet
Alfabet.insert(0, '#')
Letters = [(LETTERS + item + '.png') for item in Alfabet]
Letter = dict(zip(Alfabet, Letters))

### ##########################################################################
### ##########################################################################



def PageAnimeOdcinki():

    addDir("[Anime] Alfabetycznie", BASE_URL + 'anime',
                 'AOAlfabetycznie', fanart=default_background)
    addDir("[Anime] Emitowane", BASE_URL + 'anime',
                 'AOListTitles', fanart=default_background, section='Aired')
    addDir("[Anime] Wszystkie", BASE_URL + 'anime',
                 'AOListTitles', fanart=default_background, section='All')
    addDir("[Filmy] Alfabetycznie", BASE_URL + 'filmy',
                 'AOAlfabetycznie', fanart=default_background)
    addDir("[Filmy] Wszystkie", BASE_URL + 'filmy',
                 'AOListTitles', fanart=default_background, section='All')
    addDir("Gatunki", BASE_URL + 'gatunki', 'AOGatunki',
                 fanart=default_background, section='gatunki',
                 thumb=searchicon)
    addDir("Wyszukiwarka", search_url, 'AOSearch',
                 fanart=default_background, section='search',
                 thumb=searchicon)

def Alfabetyczna():

    name = params['name']
    url = params['url']
    result = requests.get(url, timeout=15).text
    result = parseDOM(result, 'div', {'id': 'letter-index'})[0]
    lista = re.findall('data-index.*?">\s(.+?)</a>\s\((.+?)\)\s', result)
    for litera in lista:

        if 'Anime' in name:
            addDir(str(litera[0]), url, 'AOListTitles', section=str(litera[0])[0:1],
                         thumb=str(Letter[str(litera[0])[0:1]]), fanart=custom_background,
                         code='[B][COLOR %s]%s[/COLOR][/B]' % ('green', str(litera[1]) + ' pozycji'))
        else:
            addDir(str(litera[0]), url, 'AOListTitles', section=str(litera[0])[0:1],
                         thumb=str(Letter[str(litera[0])[0:1]]), fanart=custom_background,
                         code='[B][COLOR %s]%s[/COLOR][/B]' % ('green', str(litera[1]) + ' pozycji'))
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE, 
                             label2Mask='%P')

def ListTitles():

    section = params['section']
    name = params['name']
    url = params['url']
           
    result = requests.get(url, timeout=15).text
    result = CleanHTML(result)
    if section == 'All':

        result = parseDOM(result, 'tr', {'class': r'anime-title letter-.'})
        link = [parseDOM(item, 'a', ret='href')[0] for item in result]
        title = [parseDOM(item, 'a')[0] for item in result]
        
    elif section == 'Aired':

        result = parseDOM(result, 'section', {'id': 'block-views-anime-emitowane-block'})
        link = parseDOM(result, 'a', ret='href')
        title = parseDOM(result, 'a')
        
    else:

        result = parseDOM(result, 'tr', {'class': f'anime-title letter-{section.lower()}'})
        link = [parseDOM(item, 'a', ret='href')[0] for item in result]
        title = [parseDOM(item, 'a')[0] for item in result]

    for i in zip(title, link):
        poster = cache.cache_get(hash_md5(i[0]))
        if poster:
            poster = poster['value']
        else:
            poster = fanartAodc
        addDir(str(i[0]), str(i[1]), 'AOListEpisodes',
               poster=poster, section=section,
                     thumb=poster, fanart=custom_background, subdir=name)

def ListEpisodes():

    url = params['url']
    subdir = params['subdir']
    name = params['name']
    
    result = requests.get(url, timeout=15).text
    result = CleanHTML(result)
    results = parseDOM(result, 'section', {'id':'anime-header'})
    try:
        poster = parseDOM(results, 'img', ret='src')[0]
        cache.cache_insert(hash_md5(name), poster)
    except:
        poster = parseDOM(results, 'img', ret='src')[0]

    head = {'referer': url}
    link = parseDOM(results, 'a', ret='href')
    title= parseDOM(results, 'a')
    try:
        tags = [parseDOM(i, 'a') for i in
                parseDOM(result, 'div', {'class':'field field-name-field-tags'}) if 'Gatunek' in i][0]
    except: tags = ''

    try:
        plot = re.findall('p><p>(.+?)</p>', result)[0]
        if len(re.findall('<span', plot)) >= 0:
            plot = re.sub('<span.+?/span>', '', plot)
    except: plot = ''

    data = {'genre': tags,
            'plot': plot,
            'poster': f'{poster}|{urlencode(head)}',
            'subdir': subdir
            }

    for i in zip(title, link):
            
        addLink(str(i[0]), str(i[1]), 'AOListLinks', section='links',
                      thumb=data['poster'], fanart=custom_background,
                      subdir=subdir, data=data)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')

def ListLinks():

    name = params['name']
    url = params['url']
    data = params['data']
    subdir = data['subdir']
    
    result = requests.get(url, timeout=15).text
    result = result.replace('&quot;', '"')
    result = flat_html(result)
    result = parseDOM(result, 'div', {'id': 'video-player-control'})[0]
    patt = re.compile('(<noscript>|<img)')
    player = [re.split(patt, item)[0].strip() for item in
              parseDOM(result, 'div', {'class': 'video-player-mode'})]
    hash_links = re.findall('data-hash=["|\'](\{.+?\})["|\']', result)
    link = [encryptPlayerUrl(item) for item in hash_links]

    SourceSelect(players=player, links=link, title=name,
                       subdir=subdir)

def Search():

    addDir("[B]Nowe wyszukiwanie...[/B]", search_url, 'AOSearchnew',
                 fanart=default_background, section='search', thumb=searchicon)

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = search_url + quote_plus(term)
            addDir(term, quote, "AOSearchResults", fanart=default_background,
                         thumb=searchicon)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
                     fanart=default_background)

def Searchnew():

    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()
    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()

    url = search_url + quote_plus(search)
    search_results(url)


def search_results(url):

    html = requests.get(url, timeout=15).text
    result = parseDOM(html, 'li', {'class': 'search-result'})

    for item in result:

        nazwa = CleanHTML(str(parseDOM(item, 'a')[0]))
        link = str(parseDOM(item, 'a', ret='href')[0])
        plot = CleanHTML(str(parseDOM(item, 'p')[0]))

        addDir(nazwa, link, 'AOListEpisodes', thumb=fanartAodc, plot=plot,
                     fanart=custom_background, section='search', subdir=nazwa)

    if 'nextpostslink' in html:
        nextpage = parseDOM(html, 'a', {'class': 'nextpostslink'}, ret='href')[0]
        addDir('[I]następna strona[/I]', nextpage, 'AOSearchResults', thumb=nexticon,
                     fanart=custom_background, section='nextpage')


def Gatunki():

    section = params['section']
    name = params['name']
    url = params['url']    
    
    if section == 'gatunki':
    
        result = requests.get(url, timeout=15).text
        result = parseDOM(result, 'div', {'class': 'panel-body'})[0]
        taglist = [item for item in parseDOM(result, 'div', {'class': r'.+?' + 'checkbox'}) if len(item)>0]
        tagname = [CleanHTML(item) for item in parseDOM(taglist, 'label')]

        tagcat = [item for item in parseDOM(taglist, 'input', ret='name') ]
        tagcode = ['=' + i for i in parseDOM(taglist, 'input', ret= 'value')]
        taglink = []
        for item in zip(tagcat, tagcode):

            taglink.append(str(item[0]) + str(item[1]))
                
        d = xbmcgui.Dialog()
        select = d.multiselect('Wybór Gatunku', tagname)
        if select == None:
            PageAnimeOdcinki(BASE_URL)
            return
        seltags = []
        for idx in select:
            seltags.append(taglink[idx])
        sep = '&'
        url = url + '?' + sep.join(seltags)
    

    elif section == 'nextpage':
        url = url

    html = requests.get(url, timeout=15).text
    result = parseDOM(html, 'li', {'class': 'search-result'})

    for item in result:
      
        nazwa = CleanHTML(str(parseDOM(item, 'a')[0]))
        link = str(parseDOM(item, 'a', ret='href')[0])
        plot = CleanHTML(str(parseDOM(item, 'p')[0]))

        addDir(nazwa, link, 'AOListEpisodes', thumb=fanartAodc, plot=plot,
                     fanart=custom_background, section='search', subdir=name)

    if 'nextpostslink' in html:
        nextpage = parseDOM(html, 'a', {'class':'nextpostslink'}, ret='href')[0]
        addDir('[I]następna strona[/I]', nextpage, 'AOGatunki', thumb=nexticon,
                     fanart=custom_background, section='nextpage')

#####Helpers####

def encryptPlayerUrl(data):

#    print(("_encryptPlayerUrl data[%s]" % data))
    decrypted = ''
    try:
        data = json.loads(data)
        salt = a2b_hex(data["v"])
        const = 's05z9Gpd=syG^7{'.encode('utf-8')
        key, iv = EVP_BytesToKey(md5, const, salt, 32, 16, 1)
        bcompare = a2b_hex(data['b']).decode('iso-8859-1')
        if iv != bcompare:

            print("_encryptPlayerUrl IV mismatched")
        else:
            kSize = len(key)
            alg = AES_CBC(key, keySize=kSize)
            input = a2b_base64(data["a"]).decode('iso-8859-1')
            decrypted = alg.decrypt(input, iv=iv)
            decrypted = decrypted.split('\x00')[0]
        decrypted = json.loads(decrypted)

    except:
       decrypted = ''
    return decrypted






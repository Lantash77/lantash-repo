# -*- coding: utf-8 -*-
# Python 3.8
###############################################################################
###############################################################################
# STREFADB.PL
#
# 
###############################################################################
###############################################################################
### Imports ###
#import re
#import xbmcgui
import requests
import json
import os
import xbmcvfs
from copy import deepcopy
from sqlite3 import dbapi2 as db, OperationalError
from concurrent.futures import ThreadPoolExecutor
from resources import libs
from resources.libs.addon_tools import *
from resources.libs import cache

from resources.libs import scraper
from resources.libs.log_utils import log_exc
from resources.libs.helper import *
from resources.libs.worker import *

#import json

MEDIA = libs.MEDIA
Getsetting = libs.Getsetting
Setsetting = libs.Setsetting
BASE_URL = 'https://strefadb.pl/'

cacheFile = os.path.join(libs.DATA_PATH, 'dragon.db')
params = get_params()

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
DBthumb = MEDIA + 'dbposter.jpg'
DBZthumb = MEDIA + 'dbzposter.jpg'
DBKAIthumb = MEDIA + 'dbkaiposter.jpg'
DBGTthumb = MEDIA + 'dbgtposter.jpg'
DBSUPERthumb = MEDIA +  'dbsuperposter.jpg'
DBSUPERHEROthumb = MEDIA + 'dbsuperheroposter.jpg'
DBZABRIDGthumb = MEDIA + 'dbzabridgposter.jpg'
DBMOVIEthumb = MEDIA + 'dbmovieposter.jpg'
DBAllfanart = MEDIA + 'dballfanart.jpg'
DBfanart = MEDIA + 'dbfanart.jpg'

host = 'DragonBall'

#HTML HEADER
HDR = {'User-Agent': libs.UA}

### ##########################################################################
### ##########################################################################

def Logowanie():
    headers = {
        'user-agent': libs.UA,
        'referer': 'https://strefadb.pl/',
    }
    data = {
        'login': Getsetting('userdb'),
        'password': Getsetting('passdb'),
        'strefadbautologin': 'on',
        'signin': 'OK'
    }

    cookie = requests.post('https://strefadb.pl', headers=headers, data=data)
    kuki = cookie.cookies.get_dict()
    cache.cache_insert('db_cookie', json.dumps(kuki))


def Pagedragon():
    meta = get_show_metas()

    addItem('Filmy Kinowe', f'{BASE_URL}filmy-kinowe.html', 'DBListTitles',
            data={'fanart': DBAllfanart,
                  'thumb': DBMOVIEthumb,
                  'poster': DBMOVIEthumb})
    for k, m in meta.items():
        addItem(m['title'], m['kurl'], 'DBListEpisodes', data=m, isFolder=True)

    addItem('DragonBall Z Abridged', f'{BASE_URL}/odcinki/dragon-ball-z-abridged.html', 'DBListEpisodes',
           data={'fanart': DBAllfanart,
                 'thumb': DBZABRIDGthumb,
                 'poster': DBZABRIDGthumb, 'tmdb_id': '',
                 'mediatype': 'tvshow'}
            )


def ListTitles():
    url = params['url']
    name = params['name']
    data = params['data']

    html = requests.get(url, headers=HDR).text
    result = parseDOM(html, 'table', {'id': 'lista-odcinkow'})[0]
    results = [item for item in parseDOM(result, 'tr')]
    episodes = [parseDOM(item, 'td') for item in results if 'href' in item]
    year_pattern = re.compile(r'\((\d{4})\)')
    rate_pattern = re.compile(r'\[(\d+\.\d+)\]')
    title_pattern = re.compile(r'\s*\([^)]*\)\s*|\s*\[[^\]]*\]\s*')
    links_dict = {}
    for title, link, s, r, t in episodes:
        meta = {'fanart': DBAllfanart, 'thumb': data['thumb'],
                'poster': data['poster'], 'subdir': name}
        nazwa = parseDOM(link, 'a')[0]
        year_finder = re.search(year_pattern, nazwa)
        if year_finder:
            meta['year'] = int(year_finder.group(1))
        rating_finder = re.search(rate_pattern, nazwa)
        if rating_finder:
            meta['rating'] = float(rating_finder.group(1))
        title = re.sub(title_pattern, '', nazwa)
        link = BASE_URL + re.sub('^/', '', parseDOM(link, 'a', ret='href')[0])
        link_ = link.split('/')[-1]
        links_dict.update({link_: link})

        addItem(title, link_, 'DBListLinks',
                data=meta, isFolder=False
                )
    db_cache_insert(links_dict)
    xbmcplugin.addSortMethod(int(sys.argv[1]),
                             sortMethod=xbmcplugin.SORT_METHOD_TITLE)

def ListEpisodes():
    url = params['url']
    name = params['name']
    data = params['data']
    try:
        tmdb_ep_meta = cache.get(scraper.get_Episode_meta_absolute, 240 * 3600, tmdb=None, data=data)
    except:
        tmdb_ep_meta = None

    html = requests.get(url, headers=HDR).text
    result = parseDOM(html, 'table', attrs={'id': 'lista-odcinkow'})[0]
    results = [item for item in parseDOM(result, 'tr')][1:]
    arcs = [re.findall('<th>(.+?)</th>', item) for item in results]
    groups = []
    for arc in arcs:
        if arc:
            part = arc[0]
        groups.append(part)
    episodes = [parseDOM(item, 'td') for item in results if 'href' in item]
    title_pattern = re.compile(r'\s*\([^)]*\)\s*|\s*\[[^\]]*\]\s*')
    links_dict = {}
    for idx, episode in enumerate(episodes):
        ep_no = int(episode[0].strip('.'))
        if tmdb_ep_meta:
            ep_meta = tmdb_ep_meta.get(str(ep_no))
        else: ep_meta = None
        web_title = parseDOM(episode[1], 'a')[0]
        rate = re.search('\((\d+\.\d+)\)', web_title)
        rate = float(rate.group(1)) if rate else 0.0
        web_title = re.sub(title_pattern, '', web_title)
        meta = deepcopy(data)
        try:
            meta.pop('seasons')
        except:
            pass
        if ep_meta:
            if ep_meta.get('air_date'):
                #premiered = datetime.strptime(ep_meta.get('air_date'), "%Y-%m-%d")
                meta['premiered'] = ep_meta.get('air_date', '')
            if ep_meta.get('still_path'):
                meta['poster'] = ep_meta.get('still_path')
                meta['thumb'] = ep_meta.get('still_path')
        meta['subdir'] = name
        meta['episode'] = ep_no
        ep_title = f'Odcinek {ep_no} - {web_title} | {groups[idx]}'
        if '<span' in episode[1]:
            title = f'{ep_title}  [COLOR=green]  Filler[/COLOR]'
        else:
            title = f'{ep_title}'
        link = BASE_URL + re.sub('^/', '', parseDOM(episode[1], 'a', ret='href')[0])
        link_ = meta['short'] + str(ep_no)
        links_dict.update({link_: link})
        addItem(title, link_, 'DBListLinks',
                data=meta, isFolder=False
                )
    db_cache_insert(links_dict)
    xbmcplugin.addSortMethod(int(sys.argv[1]),
                             sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')



def ListLinks():

    Logowanie()
    cookie = cache.cache_get('db_cookie')['value']
    cookie = json.loads(cookie)

    name = params['name']
    data = params['data']
    subdir = data['subdir']
    url = db_cache_get(params['url'])['value']

    html = requests.get(url, headers=HDR, cookies=cookie).text
    result = parseDOM(html, 'table', {'id': 'video-table'})[0]

    results = parseDOM(result, 'tr', {'title':'Kliknij' + r'.+?'})
    playerlink = [parseDOM(item, 'a', ret='data-src') if 'vip_url' in item else
                  parseDOM(item, 'a', ret='href')
                  for item in results]
    playerlink = [BASE_URL + re.sub('^/', '', i[0]) for i in playerlink]
    playername = [parseDOM(item, 'a')[0] for item in results]
    player = []

    with ThreadPoolExecutor(max_workers=10) as executor:
        playerlink = list(executor.map(GetDragonVideolink, playerlink))
    playersubs = [re.sub('<span(.+?)span>', '', parseDOM(item, 'td')[2]) for item in results]
    playeraudio = [parseDOM(item, 'td')[1] for item in results]
    playerquality = [parseDOM(item, 'td')[4] for item in results]

    for item in zip(playername, playerlink, playersubs, playeraudio, playerquality):
        if 'VIP' in item[0]:
            if item[1] == '/vip.html':
                playertitle = f'{item[0]}   [COLOR=red] brak subskrypcji VIP [/COLOR]'
            else:
                playertitle = f'{item[0]}   [COLOR=green] napisy {item[2]} - audio {item[3]} - {item[4]}[/COLOR]'
        else:
            playertitle = f'{item[0]}   [COLOR=green] napisy {item[2]} - audio {item[3]} - {item[4]}[/COLOR]'
        player.append(playertitle)


    SourceSelect(player, playerlink, name, subdir)

def GetDragonVideolink(url):
    cookie = cache.cache_get('db_cookie')['value']
    cookie = json.loads(cookie)
    videolink = requests.get(url, cookies=cookie, headers=HDR)
    if url != videolink.url:
        return videolink.url
    else:
        try:
            vip_link = parseDOM(videolink.text, 'source', ret='src')[0]
        except IndexError:
            vip_link = '/vip.html'
        return vip_link

def DBPass_Check():

    if (Getsetting('userdb') == '') or (Getsetting('passdb') == ''):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Konta',
                           'Włączony host StrefaDB, ale nie podano danych konta \n'
                           'Wprowadź dane konta w ustawieniach \n'
                           'lub wyłącz hosta',
                           'Wyłącz hosta', 'Ustawienia')
        if ret:
            openSettings('1.8')
        else:
            Setsetting('DB.active', 'false')
    else:
        return


def get_show_metas():
    ids = {'12609': ['DragonBall', f'{BASE_URL}odcinki/dragon-ball.html', 'https://www.grupa-mirai.pl/db/', 'db'],
           '12971': ['DragonBall Z', f'{BASE_URL}odcinki/dragon-ball-z.html', 'https://www.grupa-mirai.pl/dragon-ball-z/', 'dbz'],
           '61709': ['DragonBall KAI', f'{BASE_URL}odcinki/dragon-ball-z.html', 'https://www.grupa-mirai.pl/dragon-ball-kai/', 'dbkai'],
           '12697': ['DragonBall GT', f'{BASE_URL}/odcinki/dragon-ball-gt.html', 'https://www.grupa-mirai.pl/dragon-ball-gt/', 'dbgt'],
           '62715': ['DragonBall Super', f'{BASE_URL}/odcinki/dragon-ball-super.html', 'https://www.grupa-mirai.pl/super/', 'sbsuper'],
           '80020': ['DragonBall Super Heroes', f'{BASE_URL}/odcinki/dragon-ball-super-heroes.html', 'https://www.grupa-mirai.pl/heroes/', 'dbheroes'],
           '236994' : ['Dragon Ball Daima', f'{BASE_URL}/odcinki/dragon-ball-daima.html', 'https://www.grupa-mirai.pl/daima/', 'dbdaima']
           }


    tmdb = [i for i in ids.keys()]
    titles = [i[0] for i in ids.values()]
#    meta = scraper.Get_meta(tmdb[1], titles[1], 'tv')
    multimeta = thread_it_multi(scraper.Get_meta, 0, tmdb, titles, 'tv')
    meta = {}
    for k, v in ids.items():
        for m in multimeta:
            if k == m['tmdb']:
                m.update({'kurl': ids[k][1],
                          'murl': ids[k][2],
                          'short': ids[k][3]})
                meta.update({k: m})
    return meta

def create_cache_table():
    cursor = _get_connection_cursor()
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS cache (key TEXT, value TEXT, UNIQUE(key))"
    )

def db_cache_get(key):
    try:
        create_cache_table()
        cursor = _get_connection_cursor()
        cursor.execute('SELECT * FROM cache WHERE key=?', (key,))
        return cursor.fetchone()
    except OperationalError:
        return None

def db_cache_insert(values: dict):

    try:
        create_cache_table()
        cursor = _get_connection_cursor()
        cursor.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT, value TEXT, UNIQUE(key))')
        for key, value in values.items():
            update_result = cursor.execute('UPDATE cache SET value=? WHERE key=?', (value, key))
            if update_result.rowcount == 0:
                cursor.execute('INSERT INTO cache Values (?, ?)', (key, value))
        cursor.connection.commit()

    except OperationalError:
        print(f'Błąd cache insert {key}')
        log_exc()
        pass

def cache_clear(flush_only=False):
    cleared = False
    try:
        dbcon = _get_connection()
        dbcur = _get_connection_cursor()
        #dbcur = _get_connection_cursor(dbcon)
        if flush_only:
            dbcur.execute('DELETE FROM cache')
            dbcur.connection.commit()  # added this for what looks like a 19 bug not found in 18, normal commit is at end
            dbcur.execute('VACUUM')
            cleared = True
        else:
            dbcur.execute('DROP TABLE IF EXISTS cache')
            dbcur.execute('VACUUM')
            dbcur.connection.commit()
            cleared = True
    except Exception as e:
        print(repr(e))
        print('Cache  cache_clear error: ')
        cleared = False
    finally:
        dbcon.close()
    return cleared


def _get_connection_cursor():
    return _get_connection().cursor()


def _get_connection():
    if not xbmcvfs.exists(libs.DATA_PATH):
        xbmcvfs.mkdir(libs.DATA_PATH)
    dbcon = db.connect(cacheFile, timeout=60)
    dbcon.execute('PRAGMA page_size = 32768')
    dbcon.execute('PRAGMA journal_mode = OFF')
    dbcon.execute('PRAGMA synchronous = OFF')
    dbcon.execute('PRAGMA temp_store = memory')
    dbcon.execute('PRAGMA mmap_size = 30000000000')
    dbcon.row_factory = _dict_factory
    return dbcon


def _dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

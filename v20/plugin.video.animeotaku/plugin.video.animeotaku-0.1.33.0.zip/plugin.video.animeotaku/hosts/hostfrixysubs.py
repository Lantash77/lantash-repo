# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# FrixySubs
###############################################################################
###############################################################################
### Imports ###

#import xbmcgui, xbmc, xbmcplugin
#import sys
from datetime import date
import requests
#from urllib.parse import quote_plus

from resources import libs
from resources.libs.addon_tools import *
from resources.libs.helper import *
from resources.libs import cache

MEDIA = libs.MEDIA

searchFile = libs.searchFile
settings = libs.settings

params = get_params()
limit = settings.getInt('FS.page')
# media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
#fanartFrixysubs = MEDIA + 'frixysubs.jpg'
host = 'FrixySubs'
BASE_URL = 'https://frixysubs.pl/api/'


### ##########################################################################
### ##########################################################################

class FrixySubs():
    ANIME_LIST_URL = f'{BASE_URL}anime?limit={{}}&offset=0'
    HOME_LINK = 'https://frixysubs.pl/api/home'
    EPISODES_URL = f'{BASE_URL}anime/{{}}'
    TAGS_LINK = f'{BASE_URL}tags?limit=0'
    STUDIOS_LINK = f'{BASE_URL}studios?limit=0'
    SEARCH_URL = f'{BASE_URL}anime?offset=0&limit={{}}&search={{}}'
    GENRE_URL = f'{BASE_URL}anime?offset=0&limit=0&tags={{}}'
    STUDIO_URL = f'{BASE_URL}anime?offset=0&limit=0&studio={{}}'
    MASTER = {'ongoing': 'Aktualnie wydawane serie', 'recommended': 'Polecane serie anime',
              'best': 'Najlepsze serie anime', 'episodes': 'Nowe odcinki'}
    SESS = requests.session()

    def __init__(self):

        self.tags_list()
        self.studios_list()
        self.get_list()
        self.main_list()
        self.anime_list_by_id()

    def jget(self, url):
        return self.SESS.get(url).json()

    def get_list(self):

        self.lista_anime = cache.get(self.jget, 24 * 3600, self.ANIME_LIST_URL.format('0'))
        self.clean_list(self.lista_anime)
        self.paginated_list = [self.lista_anime['series'][i:i + limit]
                               for i in range(0, self.lista_anime['rows_num'], limit)]
        return self.lista_anime['series']

    def main_list(self):
        self.lista_glowna = cache.get(self.jget, 24 * 3600, self.HOME_LINK)
        self.clean_list(self.lista_glowna)
        self.main_list_names = [[self.MASTER[i], i] for i in self.lista_glowna]

    def tags_list(self):
        self.tags_list = cache.get(self.jget, 720 * 3600, self.TAGS_LINK)
        self.tag_by_name = [[i['name'], i['id']] for i in self.tags_list]

    def studios_list(self):
        self.studio_list = cache.get(self.jget, 720 * 3600, self.STUDIOS_LINK)
        self.studio_by_name = [[i['name'], i['id']] for i in self.studio_list]

    def get_episode_list(self, url):
        self.episodes = cache.get(self.jget, 24 * 3600, self.EPISODES_URL.format(url))
        return self.episodes

    def get_search_res(self, query):
        self.list_results = cache.get(self.jget, 24 * 3600, self.SEARCH_URL.format(str(limit), query))
        self.clean_list(self.list_results)
        return self.list_results['series']

    def get_genre_list(self, query):
        # self.list_genre = cache.get(self.jget, 24, self.GENRE_URL.format(str(limit), query))
        self.list_genre = cache.get(self.jget, 24 * 3600, self.GENRE_URL.format(query))
        self.clean_list(self.list_genre)
        return self.list_genre['series']

    def get_studio_titles(self, query):
        self.list_studio = cache.get(self.jget, 24 * 3600, self.STUDIO_URL.format(query))
        self.clean_list(self.list_studio)
        return self.list_studio['series']

    def anime_list_by_id(self):
        self.ID_list = {elem['id'] : elem for elem in self.lista_anime['series']}


    def clean_list(self, list):

        keys = [i for i in list]
        skip = ['rows_num', 'episodes']
        for key in keys:
            if key not in skip:
                for item in list[key]:
                    for tag in item['tags']:
                        try:
                            clean_tag = [i['name'] for i in self.tags_list if tag == i['id']][0]
                            list_index = list[key].index(item)
                            tag_index = item['tags'].index(tag)
                            list[key][list_index]['tags'][tag_index] = clean_tag
                        except:
                            continue
                    try:
                        clean_studio = [i['name'] for i in self.studio_list if item['studio'] == i['id']][0]
                        list_index = list[key].index(item)
                        list[key][list_index]['studio'] = clean_studio
                    except:
                        continue


def PageFrixySubs():

    names = FS.main_list_names

    addItem("Lista Anime", '0', 'FSListTitles',
           data={'fanart': default_background, 'section': 'all'})
    for name in names:
        if 'Nowe odcinki' in name[0]:

            addItem(name[0], name[1], 'FSListNewEpisodes',
                   data={'fanart': default_background})
        else:
            addItem(name[0], name[1],'FSListTitles',
                   data={'fanart': default_background, 'section':'selected'})

    addItem("Gatunki", '', mode='FSGatunki',
           data={'thumb': searchicon, 'poster': searchicon,
                 'fanart': default_background, 'section': 'gatunki'})

    addItem("Studio", '', 'FSStudio',
           data={'thumb': searchicon, 'poster': searchicon,
                 'fanart': default_background, 'section': 'studio'})

    addItem("Wyszukiwarka", '', 'FSSearch',
           data={'thumb': searchicon, 'poster': searchicon,
                 'fanart': default_background, 'section': 'search'})

    xbmcplugin.setContent(addon_handle, 'files')


def ListTitles(url=None):

    data = params['data']
    section = data['section']
    if not url:
        url = params['url']

    nextpage = False
    match section:
        case 'selected':
            anime_list = FS.lista_glowna[url]
        case 'all':
            anime_list = FS.paginated_list[int(url)]
            if len(anime_list) == int(limit):
                nextpage = str(int(url) + 1)
        case 'search':
            anime_list = FS.get_search_res(url)
        case 'gatunki':
            anime_list = FS.get_genre_list(url)
        case 'studio':
            anime_list = FS.get_studio_titles(url)
        case _:
            ...
    '''

    if section == 'selected':
        anime_list = FS.lista_glowna[url]
    elif section == 'all':
        anime_list = FS.paginated_list[int(url)]
        if len(anime_list) == int(limit):
            nextpage = str(int(url) + 1)
    elif section == 'search':
        anime_list = FS.get_search_res(url)
    elif section == 'gatunki':
        anime_list = FS.get_genre_list(url)
    elif section == 'studio':
        anime_list = FS.get_studio_titles(url)
    '''
    for anime in anime_list:

        meta = {'thumb': anime['poster'], 'icon': anime['poster'],
                'fanart': fanart, 'poster': anime['poster'],
                'banner': anime['banner'], 'clearart': '',
                'clearlogo': '',
                'title': anime['title'],
                'genre': anime['tags'],
                'year': anime['season']['year'],
                'rating': anime['rating'],
                'premiered': getDateFromStamp(anime['added_at']),
                'plot': anime['description'],
                'studio': anime['studio'],
                'subdir': anime['title'],
                'episodes': anime['ep_count']
                }

        if anime['status'] == 'Planowana':
            meta['tvshowstatus'] = anime['status']

            addItem(anime['title'], anime['link'], 'empty',
                    data={'data': meta}, isFolder=False
                    )
        else:
            if not anime.get('movieseries'):
                meta['mediatype'] = 'tvshow'
                meta['tvshowtitle'] = anime['title']
                meta['tvshowstatus'] = anime['status']
                meta['season'] = anime['season']['season']
                addItem(anime['title'], anime['link'], 'FSListEpisodes',
                        data=meta)
            else:
                meta['mediatype'] = 'movie'
                meta['label2'] = 'Movie'
                addItem(anime['title'], f'{anime["link"]}|movie', 'FSListLinks',
                        data=meta, isFolder=False)
    if nextpage:
        meta['nextpage'] = True

        meta['section'] = section
        addItem('[I]następna strona[/I]', nextpage, 'FSListTitles',
               data=meta)

    xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE,
                             label2Mask='%P')


def NewEpisodes():

    new_episode_list = FS.lista_glowna['episodes']
    for ep in new_episode_list:
        anime_id = ep['series']['id']
        anime = FS.ID_list[anime_id]
        meta = {'thumb': ep['poster'], 'icon': ep['poster'],
                'fanart': ep['banner'], 'poster': ep['poster'],
                'banner': ep['banner'], 'clearart': '',
                'clearlogo': '',
                'title': ep['title'],
                'genre': anime['tags'],
                'premiered': getDateFromStamp(ep.get('added_at', None)),
                'plot': ep['description'],
                'year': anime['season']['year'],
                'url': ep['series']['link']}

        if not ep.get('movie'):
            meta['mediatype'] = 'tvshow'
            meta['tvshowtitle'] = ep['series']['title']
            meta['season'] = get_season_number(meta['tvshowtitle'])
            meta['episode'] = ep['number']
            meta['subdir'] = ep['series']['title']
            xbmcplugin.setContent(addon_handle, 'tvshows')
            itemTitle = f'EP {meta["episode"]} - {meta['title']} - {meta["tvshowtitle"]}'
            addItem(itemTitle, meta['url'], 'FSListEpisodes',
                         data=meta)

        else:
            meta['mediatype'] = 'movie'
            meta['subdir'] = ep['title']
            meta['label2'] = 'Movie'
            addItem(meta['title'], f'{meta["url"]}|movie','FSListLinks',
                         data=meta, isFolder=False)

    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE,
                             label2Mask='%P')


def Search():

    addItem("[B]Nowe wyszukiwanie...[/B]", '', 'FSSearchnew',
           data={'thumb': searchicon, 'poster': searchicon,
                 'fanart': default_background, 'section': 'search'})

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            addItem(term, quote, "FSListTitles",
                   data={'thumb': searchicon, 'poster': searchicon,
                         'fanart': default_background, 'section': 'search'})
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addItem("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
                     data={'fanart': default_background, 'section': 'search'})


def Searchnew():

    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()
    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = quote_plus(search)
    ListTitles(url)


def ListEpisodes():

    url = params['url']
    episodes = FS.get_episode_list(url)
    anime = FS.ID_list[episodes['id']]

    for ep in episodes['episodes']:
        meta = {'title': ep['title'],
                'season': episodes['season']['season'],
                'episode': ep['number'],
                'year': episodes['season']['year'],
                'plot': ep['description'],
                'premiered': getDateFromStamp(ep.get('added_at', None)),
                'rating': float(anime['rating']),
                'poster': ep['poster'],
                'banner': ep['banner'],
                'genre': anime['tags'],
                'tvshowtitle': anime['title'],
                'mediatype': 'tvshow',
                'subdir': anime['title'],
                }

        addItem(f'{meta["episode"]}. {meta["title"]}', f'{url}|{meta["episode"]}', 'FSListLinks',
                data=meta, isFolder=False)

    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE)


def ListLinks():
    print('ListLinks Started')
    name = params['name']
    data = params['data']
    url, type = params['url'].split('|')

    if type == 'movie':
        players = FS.get_episode_list(url)['episodes']['players']
    else:
        episode = int(type) - 1
        players = FS.get_episode_list(url)['episodes'][episode]['players']

    player = [p['name'] for p in players]
    playerlink = [l['link'] for l in players]
    fix_FD_liks = [i for i in player if 'FD' in i]
    if fix_FD_liks:
        for i in fix_FD_liks:
            idx = player.index(i)
            fd_fixed = get_FD_link(playerlink[idx])
            if fd_fixed:
                playerlink[idx] = fd_fixed
            else:
                player.pop(idx)
                playerlink.pop(idx)

    SourceSelect(player, playerlink, name, data['subdir'])


def Gatunki():
    tag_list = [tag[0] for tag in FS.tag_by_name]
    tag_code = [code[1] for code in FS.tag_by_name]

    d = xbmcgui.Dialog()
    select = d.multiselect('Wybór Gatunku', tag_list)
    if select == None:
        PageFrixySubs()
        return
    seltags = []
    for idx in select:
        seltags.append(tag_code[idx])
    sep = ','
    url = sep.join(seltags)
    ListTitles(url)


def Studio():
    studio_list = FS.studio_by_name
    for studio in studio_list:
        addItem(studio[0], studio[1], 'FSListTitles',
               data={'thumb': searchicon, 'poster': searchicon,
                'fanart': default_background, 'section': 'studio'})


def get_FD_link(link):
    try:
        res = requests.get(link)
        lk = parseDOM(res.text, 'a', ret='href')[0]
        return lk
    except:
        return None


def getDateFromStamp(stamp):
    # added = date.fromtimestamp(stamp[:-3])
    return date.fromtimestamp(int(stamp[:-3])).strftime('%Y-%m-%d')

def website_status():
    try:
        t = requests.get(BASE_URL + 'anime').status_code
        if t == 200:
            return True
        return False
    except:
        return False


if website_status():
    FS = FrixySubs()


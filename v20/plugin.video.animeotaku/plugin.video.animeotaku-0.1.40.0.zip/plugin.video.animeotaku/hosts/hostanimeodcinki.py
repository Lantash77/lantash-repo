# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Anime-Odcinki
# Some part of code comes from Anonek
# Link decryption fixed for Python 3
###############################################################################
###############################################################################
### Imports ###
#import re, os
#import sys
#import xbmc
#import xbmcgui
#import xbmcplugin
import sys
import json

import xbmcplugin
from resources.libs.addon_tools import *
from resources.libs.helper import *
from resources.libs import cache
try:
    from Crypto.Cipher import AES
    from Crypto.Util import Counter
except ImportError:
    from Cryptodome.Cipher import AES
    from Cryptodome.Util import Counter
from concurrent.futures import ThreadPoolExecutor
from binascii import a2b_hex, a2b_base64
from html import unescape
from hashlib import md5


MEDIA = libs.MEDIA
LETTERS = libs.LETTERS
BASE_URL = 'https://anime-odcinki.pl/'
search_url = 'https://anime-odcinki.pl/szukaj/'
searchFile = libs.searchFile
params = get_params()
addon_handle = int(sys.argv[1])

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
previcon = MEDIA + 'prev.png'
seasonicon = MEDIA + 'calendar.png'
fanartAodc = MEDIA + 'animeodcinki.jpg'
searchicon = MEDIA + 'search.png'

Alfabet = libs.Alfabet
Alfabet.insert(0, '#')
Letters = [(LETTERS + item + '.png') for item in Alfabet]
Letter = dict(zip(Alfabet, Letters))

### ##########################################################################
### ##########################################################################



def PageAnimeOdcinki():
    addItem("[Anime] Alfabetycznie", f"{BASE_URL}anime-lista", 'AOAlfabetycznie',
           data={'fanart': default_background,
                 'mediatype': 'tvshow'})
    addItem("[Anime] Emitowane", f"{BASE_URL}anime-lista", 'AOListTitles',
           data={'fanart': default_background,
                 'section': 'Aired','mediatype': 'tvshow'})
    addItem("[Anime] Wszystkie", f"{BASE_URL}anime-lista", 'AOListTitles',
           data={'fanart': default_background,
                 'section': 'All', 'mediatype': 'tvshow'})
    addItem("[Chińskie] Alfabetycznie", f"{BASE_URL}chinskie-lista-serii-anime", 'AOAlfabetycznie',
            data={'fanart': default_background, 'mediatype': 'movie'})
    addItem("[Chińskie] Wszystkie", f"{BASE_URL}chinskie-lista-serii-anime", 'AOListTitles',
            data={'fanart': default_background,
                  'section': 'All', 'mediatype': 'movie'})
    addItem("[Filmy] Alfabetycznie", f"{BASE_URL}filmy-anime-v2/", 'AOAlfabetycznie',
            data={'fanart': default_background, 'mediatype': 'movie'})
    addItem("[Filmy] Wszystkie", f"{BASE_URL}filmy-anime-v2/", 'AOListTitles',
            data={'fanart': default_background,
                  'section': 'All', 'mediatype': 'movie'})
    addItem("Gatunki", f"{BASE_URL}gatunki/", 'AOGatunki',
           data={'fanart': default_background,
                 'section': 'gatunki',
                 'thumb': searchicon,
                 'poster': searchicon},)
    addItem("Sezony", f"{BASE_URL}gatunki/", 'AOSeasons',
            data={'fanart': default_background,
                  'section': 'sezony',
                  'thumb': seasonicon,
                  'poster': seasonicon})
    addItem("Studio", f"{BASE_URL}gatunki/", 'AOSeasons',
            data={'fanart': default_background,
                  'section': 'studio',
                  'thumb': searchicon,
                  'poster': searchicon}
            )
    addItem("Wyszukiwarka", search_url, 'AOSearch',
           data={'fanart': default_background,
                 'section': 'search',
                 'thumb': searchicon,
                 'poster': searchicon})


def Alfabetyczna():


    url = params['url']
    result = cache.get(fetch_page, 48, url)
    result = parseDOM(result, 'div', {'id': 'letter-index'})[0]
    lista = re.findall(r'data-index.+?>\s*([A-Z#])\s*\(<span class="letter-count">(\d+)</span>\)', result)

    for litera in lista:
        meta = {'section': litera[0][0:1],
                'icon': Letter[litera[0][0:1]],
                'thumb': Letter[litera[0][0:1]],
                'poster': Letter[litera[0][0:1]],
                'fanart': custom_background,
                'label2': f"[B][COLOR gold]{litera[1]} pozycji[/COLOR][/B]"
                }
        if 'anime-lista' or 'chinskie-lista-serii-anime' in url:
            meta['mediatype'] = 'tvshow'
        else:
            meta['mediatype'] = 'movie'

        addItem(litera[0], url, 'AOListTitles',
                   data=meta)
        if meta.get('label2'):
            xbmcplugin.addSortMethod(addon_handle,
                                     sortMethod=xbmcplugin.SORT_METHOD_NONE,
                                     label2Mask='%P')
    xbmcplugin.setContent(addon_handle, 'movies')



def ListTitles():


    url = params['url']
    data = params['data']

    res = cache.get(fetch_page, 48, url)
    if data['section'] == 'Aired':
        # regex
        result = re.findall(r'class="ao-anime-item"[^>]*>(.+?)</li>', res, re.DOTALL)
        title = [re.findall(r'">([^<]+)</a>', i)[0] for i in result]
        link = [re.findall(r'href="([^"]+)"', i)[0] for i in result]
        poster = [re.findall(r'data-src="([^"]+)"', i, re.DOTALL)[0]
                  if re.search(r'data-src="([^"]+)"', i, re.DOTALL) else '' for i in result]
        year = [0 for i in result]
        plot = [re.findall(r'<p[^>]*>([^<]+)</p>', i, re.DOTALL)[0]
                if re.search(r'<p[^>]*>([^<]+)</p>', i, re.DOTALL) else '' for i in result]
    else:
        if data['section'] == 'All':
            section = '.'
        else:
            section = data["section"].lower()
       # gone into regex as quickest compared to parseDOM
        result = re.findall(rf'anime-title letter-{section}"(.+?)</a></div>', res, re.DOTALL)
        link = [re.findall(r'href="([^"]+)"', i)[0] for i in result]
        poster = [parseDOM(item, 'a', ret='data-image')[0] for item in result]
        year = [int(re.findall(r'data-year="(\d{4})"', i)[0])
                if re.search(r'data-year="(\d{4})"', i)
                else 0 for i in result]
        plot = ['' for item in result]
        title = [re.findall(r'<span>([^<]+)</span>', i)[0] for i in result]

    for i in zip(title, link, poster, plot, year):
        meta = {'poster': i[2],
                     'thumb': i[2],
                     'fanart': custom_background,
                     'plot': i[3],
                     'year': i[4],
                     'mediatype': data['mediatype'],
                     'subdir': i[0]}
        if data['mediatype'] == 'tvshow':
            meta['tvshowtitle'] = i[0]

        addItem(i[0], i[1], 'AOListEpisodes',
               data=meta)
    if data['mediatype'] == 'tvshow':
        xbmcplugin.setContent(addon_handle, 'tvshows')
    else:
        xbmcplugin.setContent(addon_handle, 'movies')


def ListEpisodes():

    url = params['url']
    data = params['data']

    result = fetch_page(url)

    results = parseDOM(result, 'div', {'class': 'anime-container'})
    try:
        posterbox = parseDOM(results, 'div', {'class': 'cover-section'})
        poster = parseDOM(posterbox, 'img', ret='src')[0]
    except:
        poster = data['poster']

    links = parseDOM(results, 'div', {'class': 'episodes-section'})
    link = parseDOM(links, 'a', ret='href')[::-1]
    title = parseDOM(links, 'a')[::-1]

    episode_number = [re.findall(r'(\d+(?:\.\d+)?)[^0-9]*$', i)[0]
                      if re.search(r'(\d+(?:\.\d+)?)[^0-9]*$', i)
                      else '' for i in title]

    try:
        tags = [parseDOM(i, 'a') for i in
                parseDOM(result, 'div', {'class': 'info-content-tags'})][0]
    except:
        tags = []

    try:
        plotbox = parseDOM(result, 'div', {'class': 'description-section'})[0]
        plot = clear_HTML_tags(plotbox)
    except:
        plot = ''

    for i in zip(title, link, episode_number):
        meta = {'poster': poster,
               'thumb': poster,
               'fanart': custom_background,
               'genre': tags,
               'plot': plot,
               'year': data.get('year', 0),
               'subdir': data['subdir']}
        if data['mediatype'] == 'tvshow':
            meta['episode'] = int(float(i[2]))
            meta['tvshowtitle'] = data['tvshowtitle']
            meta['mediatype'] = 'tvshow'

        addItem(i[0], i[1], 'AOListLinks',
                data=meta, isFolder=False)
    xbmcplugin.setContent(addon_handle, 'episodes')


def ListLinks():
    name = params['name']
    url = params['url']
    data = params['data']

    res = fetch_page(url)

    result = parseDOM(res, 'div', {'id': 'video-player-control'})[0]
    patt = re.compile('(<noscript>|<img)')
    player = [clear_HTML_tags(re.split(patt, item)[0]) for item in
              parseDOM(result, 'div', {'class': r'.+?-player-mode'})]
    print(player)
    hash_links = re.findall(r'data-hash=["|\'](\{.+?\})["|\']', result)
    print(hash_links)
    with ThreadPoolExecutor(max_workers=10) as executor:
        link = list(executor.map(_encryptPlayerUrl, hash_links))

    SourceSelect(players=player, links=link, title=name,
                 subdir=data['subdir'])

def Search():

    addItem("[B]Nowe wyszukiwanie...[/B]", search_url, 'AOSearchnew',
            data={'thumb': searchicon, 'poster': searchicon,
            'fanart': default_background})

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = search_url + quote_plus(term)
            addItem(term, quote, "AOSearchResults",
                    data={'poster': searchicon, 'thumb': searchicon,
                          'fanart': default_background},)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addItem("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
                data={'fanart': default_background})



def Searchnew():

    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()
    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()

    url = search_url + quote_plus(search)
    search_results(url)


def search_results(url):

    html = fetch_page(url)
    result = parseDOM(html, 'article')
    #previous page if exist (require for label2mask as special sort not working)

    previouse_page = parseDOM(html, 'a',
                              {'class': 'page-numbers prev'}, ret='href')
    if previouse_page:
        addItem('[I]poprzednia strona[/I]', previouse_page[0], 'AOSearchResults',
                data={'poster': previcon,
                      'thumb': previcon,
                      'previouspage': True,
                      'fanart': custom_background,
                      'label2': re.findall(r'/(\d+)/', previouse_page[0])[-1] if
                      re.search(r'/(\d+)/', previouse_page[0]) else '1'})
    #main list
    for item in result:
        _item = parseDOM(item, 'h3',)[0]
        title = parseDOM(_item, 'a')[0]
        link = parseDOM(_item, 'a', ret='href')[0]
        poster = parseDOM(item, 'img', ret='src')[0]
        plot = clear_HTML_tags(parseDOM(item, 'p')[0])

        addItem(title, link, 'AOListEpisodes',
               data={'poster': poster,
                     'thumb': poster,
                     'fanart': custom_background,
                     'plot': plot,
                     'mediatype': 'tvshow',
                     'subdir': title})
    next_page = parseDOM(html, 'a',
                         {'class': 'page-numbers next'}, ret='href')
    # next page if exist (require for label2mask as special sort not working)
    if next_page:
        addItem('[I]następna strona[/I]', next_page[0], 'AOSearchResults',
                data={'poster': previcon,
                      'thumb': previcon,
                      'nextpage': True,
                      'fanart': custom_background,
                      'label2': re.findall(r'/(\d+)/', next_page[0])[-1]})
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask='%P')
    xbmcplugin.setContent(addon_handle, 'tvshows')


def _get_tag(tags: list):
    tagname = [item for item in parseDOM(tags, 'label')]
    tagcat = [item for item in parseDOM(tags, 'input', ret='name')]
    tagcode = ['=' + i for i in parseDOM(tags, 'input', ret='value')]
    taglink = [x + y for x, y in zip(tagcat, tagcode)]

    return tagname, taglink


def Sezony():
    url = params['url']
    data = params['data']

    result = cache.get(fetch_page, 48, url)
    taglist = parseDOM(result, 'div', {'class': r'search-category-checkbox'})

    if data.get('section') == 'sezony':
        tag_filter = ['sezon[]']
        taglist_filtered = [i for i in taglist if any(e in i for e in tag_filter)]

    elif data.get('section') == 'studio':
        tag_filter = ['studio[]']
        taglist_filtered = [i for i in taglist if any(e in i for e in tag_filter)]
    tagname, taglink = _get_tag(taglist_filtered)
    for tag in zip(tagname, taglink):
        addItem(tag[0], f'{url}?{tag[1]}', 'AOGatunki',
                data={'poster': seasonicon,
                      'thumb': seasonicon,
                      'fanart': custom_background,
                      'mediatype': 'tvshow', })
    xbmcplugin.setContent(addon_handle, 'tvshows')


def Gatunki():

    url = params['url']
    data = params['data']

    if data.get('section') == 'gatunki':

        result = fetch_page(url)
        taglist = parseDOM(result, 'div', {'class': r'search-category-checkbox'})
        excluded = ['studio[]', 'sezon[]', 'rating[]', 'nadchodzące[]']
        taglist_filtered = [i for i in taglist if all(e not in i for e in excluded)]
        tagname, taglink = _get_tag(taglist_filtered)

        d = xbmcgui.Dialog()
        select = d.multiselect('Wybór Gatunku', tagname)
        if select == None:
            PageAnimeOdcinki()
            return
        seltags = []
        for idx in select:
            seltags.append(taglink[idx])
        sep = '&'
        url = f'{url}?{sep.join(seltags)}'
    else:
        url = url

    html = fetch_page(url)
    result = parseDOM(html, 'li', {'class': 'search-result-item'})

    #main list
    for item in result:
        title = parseDOM(item, 'a')[0]
        link = parseDOM(item, 'a', ret='href')[0]
        plot = parseDOM(item, 'p')[0]
        poster = parseDOM(item, 'img', ret='src')[0]
        meta = {'poster': poster,
                'thumb': poster,
                'fanart': custom_background,
                'plot': plot,
                'mediatype': 'tvshow',
                'subdir': title}
        addItem(title, link, 'AOListEpisodes',
               data=meta
               )
    # next page if exist (require for label2mask as special sort not working)
    next_page = parseDOM(html, 'a',
                         {'class': 'next page-numbers'}, ret='href')
    if next_page:
        addItem('[I]następna strona[/I]', next_page[0], 'AOGatunki',
                data={'poster': previcon,
                      'thumb': previcon,
                      'nextpage': True,
                      'fanart': custom_background,
                      'label2': re.findall(r'/(\d+)/', next_page[0])[-1]
                      }
                )
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask='%P')
    xbmcplugin.setContent(addon_handle, 'tvshows')

#####Helpers####

def _encryptPlayerUrl(data):

#    print(("_encryptPlayerUrl data[%s]" % data))
    decrypted = ''
    try:
        data = json.loads(data)
        salt = a2b_hex(data["v"])
        const = 's05z9Gpd=syG^7{'.encode('utf-8')
        #key, iv = EVP_BytesToKey(md5, const, salt, 32, 16, 1)
        key, iv = EVP_BytesToKey(const, salt, 32, 16, 1)
        #bcompare = a2b_hex(data['b']).decode('iso-8859-1')
        #bcompare = a2b_hex(data['b'])
        if iv != a2b_hex(data['b']):
            print("_encryptPlayerUrl IV mismatched")
        else:
            #kSize = len(key)
            #alg = AES_CBC(key, keySize=kSize)
            alg = AES.new(key, AES.MODE_CBC, iv=iv)
            input = a2b_base64(data["a"])
            #input = a2b_base64(data["a"]).decode('iso-8859-1')
            #decrypted = alg.decrypt(input, iv=iv)
            #decrypted = decrypted.split('\x00')[0]
            decrypted = alg.decrypt(input).splitlines()[0].decode('utf-8')
            decoder = json.JSONDecoder()
            decrypted, _ = decoder.raw_decode(decrypted)
            #print(f"_encryptPlayerUrl decrypted[{decrypted}]")
    except Exception as e:
        print(repr(e))
        decrypted = ''
    return decrypted










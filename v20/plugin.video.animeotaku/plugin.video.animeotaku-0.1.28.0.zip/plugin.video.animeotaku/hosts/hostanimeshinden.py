# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Anime-Shinden
###############################################################################
###############################################################################
### Imports ###
import json
#import re
#import xbmc
#import xbmcgui
#import sys
#import xbmcplugin
import time
import requests

from resources import libs
from ast import literal_eval
#from urllib.parse import quote_plus
#import json

from concurrent.futures import ThreadPoolExecutor
from resources.libs.addon_tools import *
from resources.libs import cache
from resources.libs.helper import *
from resources.libs.scraper import *


MEDIA = libs.MEDIA
LETTERS = libs.LETTERS
BASE_URL = 'https://shinden.pl/'
search_url = 'https://shinden.pl/series?search='
searchFile = libs.searchFile
settings = libs.settings
COOKIE = 'shinden_cookie'

params = get_params()
addon_handle = int(sys.argv[1])

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
previcon = MEDIA + 'prev.png'
searchicon = MEDIA + 'search.png'
calendaricon = MEDIA + 'calendar.png'
fanartAshinden = MEDIA + 'animeshinden.jpg'
host = 'AnimeShinden'

Alfabet = libs.Alfabet
Alfabet.append('#')
Letters = [(LETTERS + item + '.png') for item in Alfabet]
Letter = dict(zip(Alfabet, Letters))

#HTML HEADER
headersget = {'user-agent': libs.UA,
              'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',}

### ##########################################################################
### ##########################################################################

def PageAnimeShinden():

   addItem("[Anime] Alfabetycznie", f'{BASE_URL}series', 'SHAlfabetycznie',
       data={'fanart': default_background, 'section': 'Alfabetycznie'}, isFolder=True
       )
   addItem("[Anime] Wszystkie", f'{BASE_URL}series', 'SHListTitles',
       data={'fanart': default_background, 'section': 'All'}, isFolder=True
       )
   addItem("[Anime] Emitowane", f'{BASE_URL}series?series_status[0]=Currently+Airing', 'SHListTitles',
       data={'fanart': default_background, 'section': 'Aired'}, isFolder=True
       )
   addItem("Sezony", f'{BASE_URL}series/season/archive', 'SHSeasons',
       data={'section': 'seasons', 'page': 0}, isFolder=True
       )
   addItem("Gatunki", f'{BASE_URL}series?', 'SHGatunki',
       data={'fanart': default_background, 'section': 'gatunki',
             'poster': searchicon, 'thumb': searchicon}, isFolder=True
       )
   addItem("Wyszukiwarka", search_url, 'SHSearch',
          data={'fanart': default_background, 'section': 'search',
                'poster': searchicon, 'thumb': searchicon}, isFolder=True
          )


def Logowanie(popup=False):

    headers = {
        'origin': 'https://shinden.pl',
        'User-Agent': libs.UA,
        'referer': 'https://shinden.pl/',
    }
    data = {
        'username': settings.getString('usershinden'),
        'password': settings.getString('passshinden'),
        'login': ''
    }

    cookie = requests.post('https://shinden.pl/main/0/login', headers=headers, data=data)
    response = cookie.status_code
    kuki = cookie.cookies.get_dict()
    if response == 200:
        ###LoginCheck - server error handling
        if any('jwtCookie' in key for key in kuki.keys()):
            if popup == True:
                dialog = xbmcgui.Dialog()
                dialog.notification('Anime-Otaku ', 'Zalogowano pomyślnie do Shinden.pl.',
                                    xbmcgui.NOTIFICATION_INFO, 5000, sound=False)
            cache.cache_insert(COOKIE, json.dumps(kuki))
        else:
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno('Nie jesteś zalogowany',
                               'Sprawdź dane logowania w ustawieniach wtyczki \nZarejestruj się na Shinden.pl.' ,
                               'Wyjdź', 'Ustawienia')
            if ret:
                libs.my_addon.openSettings()
                xbmc.executebuiltin('Container.Refresh')
    else:
        d = xbmcgui.Dialog()
        d.notification('Anime-Otaku.pl ',
                       f'[COLOR red]Problem  -  Błąd serwera {str(response)}[/COLOR]',
                       xbmcgui.NOTIFICATION_INFO, 5000)
        exit()

def get_cookie():

    now = int(time.time())
    exp = 3600  # 1 hour valid cookie
    cached_cookie = cache.cache_get(COOKIE)
    if cached_cookie:
        if now - cached_cookie['date'] > exp:
            Logowanie()
            return json.loads(cache.cache_get(COOKIE)['value'])
        return json.loads(cached_cookie['value'])
    else:
        Logowanie(True)
        return json.loads(cache.cache_get(COOKIE)['value'])


def Alfabetyczna():

    url = params['url']
    html = cache.get(fetch_page, 48, url)
    result = parseDOM(html, 'ul', {'id': 'TabLetters'})[0]
    letterlink = [item.replace('r307=1&', '') for item in parseDOM(result, 'a', ret='href')]
    letter = parseDOM(result, 'a')

    for i in zip(letter, letterlink):
        link = f'{url}{i[1]}'
        meta = {'poster': Letter[i[0]],
                'thumb': Letter[i[0]],
                'icon': Letter[i[0]],
                'fanart': custom_background,}
        addItem(i[0] , link, mode='SHListTitles',
                data=meta, isFolder=True)


def ListSeasons():

    url = params['url']
    data = params['data']
    page = data.get('page') ###check if it will be int
    limit = 40

    html = fetch_page(url)
    table_box = parseDOM(html, 'ul', {'class': 'seasons-archive'})
    seasons_list = parseDOM(table_box, 'a', ret='href')
    seasons_names = parseDOM(table_box, 'a')
    seasons_list = [f'{BASE_URL[:-1]}{i}' for i in seasons_list]
    seasons = [seasons_list, seasons_names]
    # paging seasons list
    seasons_list_paged = [[seasons[0][i:i + limit], seasons[1][i:i + limit]]
                        for i in range(0, len(seasons[0]), limit)]
    pages = len(seasons_list_paged) - 1
    for item in zip(*seasons_list_paged[page]):
        addDir(item[1], item[0], 'SHSeasonsTitles',
               data={'poster': calendaricon, 'thumb': calendaricon, 'fanart': custom_background,
                     }
               )
    if not page == pages:
        page += 1
        addDir('[I]następna strona[/I]', url, 'SHSeasons',
               data={'poster': nexticon, 'thumb': nexticon, 'fanart': custom_background,
                     'page': page}
               )
    pass


def ListSeasonsTitles():

    url = params['url']
    #data = params['data']
    html = fetch_page(url)
    html = flat_html(html)
    titles_list = re.findall('class="title anime"(.*?)</footer>', html)

    for title_block in titles_list:
        #linki = parseDOM(title_block, 'a', ret='href')[0]
        link = f"{BASE_URL[:-1]}{parseDOM(title_block, 'a', ret='href')[0]}"
        try:
            mpaa = re.findall('data-rating="(.+?)"', title_block)[0].upper()
        except:
            mpaa = ''
        title = parseDOM(title_block, 'a')[0]
        poster = f"{BASE_URL[:-1]}{parseDOM(title_block, 'img', ret='src')[0]}"
        plot = parseDOM(title_block, 'div', {'class': 'title.*?'})[0]
        year = re.findall('Emitowane.*?([1-2][0-9]{3})', title_block)[0]

        try:
            genres_list = parseDOM(parseDOM(title_block, 'ul', {'class': 'genres'}), 'a')
        except IndexError:
            genres_list = []
        pass
        data = {'poster': poster,
                'thumb': poster,
                'plot': plot,
                'year': year,
                'genre': genres_list,
                'mpaa': mpaa,
                'section': 'seasons'
                }
        addDir(title, link, 'SHListEpisodes',
               data=data
               )


def ListTitles(url=None):

    if not url:
        url = params['url']

    html = cache.get(fetch_page, 48, url).replace('r307=1&', '').replace('&r307=1', '')
    html = flat_html(html)
    result = parseDOM(html, 'section', {'class': 'anime-list box'})[0]
    results = parseDOM(result, 'ul', {'class': 'div-row'})[1:]

    for item in results:
        try:
            link = [BASE_URL + i.replace('/series/', 'series/')
                 for i in parseDOM(item, 'a' , ret='href') if 'series/' in i][0]
        except IndexError:
            link = [BASE_URL + i.replace('/titles/', 'titles/')
                    for i in parseDOM(item, 'a', ret='href') if 'titles/' in i][0]
        obraz = [BASE_URL + i.replace('/res/', 'res/')
             for i in parseDOM(item, 'a' , ret='href') if 'res/' in i][0]
        title = clear_HTML_tags(parseDOM(item, 'a')[1])

        try:
            datasite = requests.get(link, timeout=10).text
            plotdata = parseDOM(datasite, 'div', {'id':'description'})[0]
            plot = clear_HTML_tags(CleanHTML(plotdata))
        except:
            plot = ''
        try:
            genredata = [item for item in parseDOM(datasite, 'tr') if 'Gatunki' in item][0]
            genre = parseDOM(genredata, 'a')
        except:
            genre = []
        try:
            infodata = parseDOM(datasite, 'dl', {'class': 'info-aside-list'})[0]
            info = re.findall(r'<dt>\s*(.+?)\s*</dt>\s*(?:<[^>]*>)*\s*<dd>\s*(.+?)\s*</dd>', infodata,
                              re.DOTALL | re.IGNORECASE)
            if info:
                info = {i[0].replace(':', ''): clear_HTML_tags(i[1]) for i in info}
                year_ = re.search(r'\d{4}',info.get('Data emisji', ''))
                if year_:
                    year = year_.group(0)
        except:
            info = {}
        try:
            if not year:
                yeardata = parseDOM(datasite, 'section', {'class': 'title-small-info'})[0]
                year = re.findall(r'[1-2][0-9]{3}', yeardata)[0]
        except:
            year = None
        try:
            ratingdata = parseDOM(datasite, 'div', {'class': 'bd'})[0]
            ratingblock = parseDOM(ratingdata, 'span')
            rating = (float(ratingblock[0].replace(',', '.')), int(re.findall(r'\d+', ratingblock[1])[0]))
        except:
            rating = 0

        _media = 'tvshow'
        tmdb_id = find_tmdb_ID(title, _media, year, 'ja')
        if not isinstance(tmdb_id, int):
            _media = 'movie'
            tmdb_id = find_tmdb_ID(title, _media, year, 'ja')
            if not isinstance(tmdb_id, int):
                tmdb_id = None
        _meta = Get_meta(tmdb_id, title, _media) if tmdb_id else {}
        meta = {'poster': obraz,
                'thumb': obraz,
                'fanart': _meta.get('fanart', custom_background),
                'banner': _meta.get('banner', ''),
                'clearlogo': _meta.get('clearlogo', ''),
                'clearart': _meta.get('clearart', ''),
                'castandart': _meta.get('castandart'),
                'plot': plot,
                'year': int(year),
                'genre': genre,
                'rating': rating,
                'status': info.get('Status'),
                'premiered': info.get('Data emisji'),
                'mpaa': info.get('MPAA'),
                'studios': _meta.get('studio'),
                'episode_count': int(info.get('Liczba odcinków', 0)),
                'subdir': title,
                'mediatype': 'movie' if info.get('Typ') == 'Movie' else 'tvshow',
                'label2': f'{info.get("Typ")}'}
        if meta['mediatype'] == 'tvshow':
            meta['tvshowtitle'] = title
            isFolder = True
        else:
            isFolder = False
        addItem(title , link, 'SHListEpisodes',
                     data=meta, isFolder=isFolder)

    next_page = parseDOM(result, 'a', {'rel': 'next'}, ret='href')
    if next_page:
        nextpage = BASE_URL + re.sub('/', '', next_page[0])
        nextpage_no = nextpage.split('=')[-1]
        total_pages = parseDOM(result, 'a', {'rel': 'last'}, ret='href')[0].split('=')[-1]
        label2 = f'{nextpage_no} / {total_pages}'
        addItem('[I]następna strona[/I]', nextpage, 'SHListTitles',
                data={'poster': nexticon,
                      'thumb': nexticon,
                      'nextpage': True,
                      'label2': label2,
                      'fanart': custom_background},
                isFolder=True
                )
    xbmcplugin.addSortMethod(addon_handle,
                             sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask='%P')

def Search():

    addDir("[B]Nowe wyszukiwanie...[/B]", search_url, 'SHSearchnew',
           data={'fanart': default_background, 'section': 'search'}
           )

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            url = search_url + quote
            addDir(term, url, "SHListTitles",
                   data={'poster': searchicon, 'thumb': searchicon,
                         'fanart': default_background}
                   )
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
               data={'fanart': default_background}
               )


def Searchnew():
    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = search_url + quote_plus(search)
    ListTitles(url)


def ListEpisodes():

    name = params['name']
    url = params['url'] + '/all-episodes'
    data = params['data']

    cookie = get_cookie()

    html = requests.get(url, headers=headersget, cookies=cookie, timeout=15).text

    result = parseDOM(html, 'tbody', {'class': 'list-episode-checkboxes'})[0]
    results = parseDOM(result, 'tr')[::-1]
    epNo = [parseDOM(item, 'td')[0] for item in results]
    epTitle = [parseDOM(item, 'td', {'class': 'ep-title'})[0] for item in results]
    epstatus = [re.findall('<i class="fa fa-fw fa-(.+?)"></i>', item)[0] for item in results]
    epDate = [parseDOM(item, 'td', {'class': 'ep-date'})[0] for item in results]
    link = [BASE_URL + re.sub('^/', '', parseDOM(item, 'a', ret='href')[0]) for item in results]
    #print(html)
    for ep in zip(epNo, epTitle, epDate, link, epstatus):
        label2 = f'[B][COLOR=blue]{ep[2]}[/COLOR][/B]'

        if ep[4] == 'check':
            title = f'{ep[0]}  :  {ep[1]}'
            ep_status = True
        else:
            title = f'{ep[0]}  [COLOR=red]  offline [/COLOR]'
            ep_status = False
        meta = {k: v for k, v in data.items()}
        meta['label2'] = label2
        meta['active'] = ep_status
        if meta['mediatype'] == 'tvshow':
            meta['episode'] = ep[0]
            meta['premiered'] = ep[2]

            addItem(title, ep[3], 'SHListLinks', data=meta, isFolder=False)
        else:
            ListLinks(ep[3], name, meta)
            break
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_NONE,
                             label2Mask='%P')


def ListLinks(url=None, title=None, data={}):

    name = title if title else params['name']
    url = url if url else params['url']
    data = data if data else params['data']

    if data.get('active'):
        cookie = get_cookie()
        html = requests.get(url, headers=headersget, cookies=cookie, timeout=15).text.replace('&quot;', '"')
        result = [item for item in parseDOM(html, 'tbody') if 'player' in item]
        results = parseDOM(result, 'tr')

        playerinfo = [re.findall(r'data-episode=.(\{.+?\}). ', item) for item in results]

        code = re.findall(r"""_Storage\.basic.*=.*'(.*?)'""", html)[0]
        playerdata = [json.loads(item[0]) for item in playerinfo]
        playerlink = []
        player = []

        for i in playerdata:

            title = f'{i["player"]} [COLOR=green]    Audio  {i["lang_audio"]} {"" if (i["lang_subs"] == "") or (i["lang_subs"] == None) else "   SUB  " + i["lang_subs"]}[/COLOR]'

            player.append(title)
            ID = (i['online_id'])
            playerlink.append(f"https://api4.shinden.pl/xhr/{ID}/player_load?auth={code}")

        with ThreadPoolExecutor(max_workers=10) as executor:
            playerlink = list(executor.map(ShindenGetVideoLink, playerlink))

        players = []
        players_link = []
        for idx, lnk in enumerate(playerlink):
            player_item = player[idx]
            for i, l in enumerate(lnk):
                if len(lnk) > 1:
                    players.append(f'{player_item} part {i + 1}')
                else:
                    players.append(f'{player_item}')
                players_link.append(l)
                pass

        SourceSelect(player, playerlink, name, data['subdir'])
    else:
        d = xbmcgui.Dialog()
        d.notification('Anime-Otaku.pl ',
                       f'[COLOR red]Brak aktywnych linków[/COLOR]',
                       xbmcgui.NOTIFICATION_INFO, 5000)
        return


def Gatunki():


    url = params['url']
    data = params['data']
    section = data['section']

    if section == 'gatunki':
        html = requests.get(url, timeout=10).text
        tagname = [re.sub('<i(.+?)</i>', '', item) for item in parseDOM(html, 'a', {'class': 'genre-item'})]
        tagcode = ['i' + item for item in parseDOM(html, 'a', {'class': 'genre-item'}, ret='data-id')]
        taglink = []

        d = xbmcgui.Dialog()
        select = d.multiselect('Wybór Gatunku', tagname)
        seltags = []
        if select == None:
            PageAnimeShinden()
            return
        for idx in select:
            seltags.append(tagcode[idx])
        sep = ';'
        url = url + 'genres-type=all&genres=' + sep.join(seltags)

    elif section == 'nextpage':
        url = url

    ListTitles(url)


def ShindenPass_Check():

    if ((settings.getString('usershinden') == '')
            or (settings.getString('passshinden') == '')):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Konta',
                           'Włączony host Shinden, ale nie podano danych konta \n'
                           'Wprowadź dane konta w ustawieniach \n'
                           'lub wyłącz hosta',
                           'Wyłącz hosta', 'Ustawienia')
        if ret:
            openSettings('1.5')
        else:
            settings.setBool('SH.active', 'false')
            xbmc.executebuiltin('Container.Refresh')
    else:
        return

   
def ShindenGetVideoLink(url):

    headers = {
            'Accept': '*/*',
            'Origin': 'https://shinden.pl',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.46 Safari/537.36',
            'DNT': '1',
        }

    if str(url).startswith("//"): url = "https://" + url
    session = requests.session()
    session.get(url, headers=headers, timeout=15)
    time.sleep(5)
    video = session.get(url.replace("player_load", "player_show") + "&width=508", timeout=5).text
    video_url = ''
    try:
        video_url = parseDOM(video, 'iframe', ret='src')[0]
    except:
        pass
    if not video_url:
        try:
            video_url = parseDOM(video, 'a', ret='href')[0]
        except:
            pass
    if not video_url:
        try:
            video_url = re.findall("src=\"(.*?)\"", video)[0]
        except:
            pass
    if str(video_url).startswith("//"): video_url = "http:" + video_url    
    return video_url

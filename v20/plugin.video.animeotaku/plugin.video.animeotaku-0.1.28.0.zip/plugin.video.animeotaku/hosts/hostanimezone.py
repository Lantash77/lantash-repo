# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# AnimeZone
#
# Some part of code comes from Anonek
###############################################################################
###############################################################################
import requests
#import re
import time
import datetime

from resources import libs
from resources.libs.helper import *
from resources.libs.addon_tools import *
from resources.libs import cache
from resources.libs.worker import *

HOST = 'animezone'
MEDIA = libs.MEDIA
LETTERS = libs.LETTERS
COOKIE = f'{HOST}_cookie'
UA = libs.UA
searchFile = libs.searchFile
Getsetting = libs.Getsetting
BASE_URL = 'https://www.animezone.pl'
search_url = 'https://www.animezone.pl/szukaj?q='

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
posterAzone = MEDIA + 'animezone.jpg'
searchicon = MEDIA + 'search.png'
calendaricon = MEDIA + 'calendar.png'

params = get_params()

Alfabet = libs.Alfabet
Alfabet.insert(0, '#')
Letters = [(LETTERS + item + '.png') for item in Alfabet]
Letter = dict(zip(Alfabet, Letters))



def PageAnimeZone():


    addDir('Premiery', f'{BASE_URL}/anime/premiery', 'AZCalendar',
           data={'fanart': default_background, 'section': 'gatunki',
                 'thumb': calendaricon, 'poster': calendaricon})
    addDir('Lista Anime', f'{BASE_URL}/anime/lista', 'AZAlfabetycznie',
           data={'fanart': default_background, 'section': 'Alfabetycznie'})
    addDir('Lista Filmów', f'{BASE_URL}/anime/filmy', 'AZAlfabetycznie',
           data={'fanart': default_background, 'section': 'Alfabetycznie'})
    addDir('Ranking Anime', f'{BASE_URL}/anime/ranking/ocen', 'AZRanking',
           data={'fanart': default_background, 'section': 'ranking'})
    addDir('Ranking Filmy', f'{BASE_URL}/anime/ranking/ocen/filmy', 'AZRanking',
           data={'fanart': default_background, 'section': 'ranking'})
    addDir('Sezony', f'{BASE_URL}/anime/sezony', 'AZSezony',
           data={'fanart': default_background, 'section': 'sezony',
                 'thumb': calendaricon, 'poster': calendaricon,
                 'page': 0})
    addDir('Wyszukiwarka', search_url, 'AZSearch',
           data={'fanart': default_background, 'section': 'search',
                 'thumb': searchicon})

def Alfabetyczna():

    url = params['url']
    for litera in Letter:
        if litera == '#':
            addDir(litera, url, 'AZListTitles',
                   data={'fanart': default_background,
                         'thumb': Letter[litera]})
        else:
            addDir(litera, f'{url}/{litera}', 'AZListTitles',
                   data={'fanart': default_background,
                         'thumb': Letter[litera], })

def seasons():

    url = params['url']
    data = params['data']
    page = data.get('page')
    year_now = datetime.datetime.now().year
    y_seasons = ['wiosna', 'lato', 'jesien', 'zima']
    y_years = [str(i) for i in range(1963, year_now + 1)]
    y_years.insert(0, '0000')
    y_years.reverse()
    limit = 40

    season_list = [[f'{url}/{y}/{s}', f'{s.capitalize()} {y}'] for y in y_years for s in y_seasons]
    seasons_list_paged = [season_list[i:i + limit]
                          for i in range(0, len(season_list), limit)]
    pages = len(seasons_list_paged) - 1
    for item in seasons_list_paged[page]:
        print(item[0], item[1])


        addDir(item[1], item[0], 'AZListTitles',
               data={'poster': calendaricon, 'thumb': calendaricon, 'fanart': custom_background,
                     'section': 'seasons'}
               )
    if not page == pages:
        page += 1
        addDir('[I]następna strona[/I]', url, 'AZSeasons',
               data={'poster': nexticon, 'thumb': nexticon, 'fanart': custom_background,
                     'page': page}
               )

def calendar():

    url = params['url']
    data = params['data']
    result = requests.get(url, timeout=15)
    result = result.text
    result = CleanHTML(result).replace('<mark>', '').replace('</mark>', '')
    # parse items
    blocks = parseDOM(result, 'div', {'class': r'well .*?'})
    links = [f"{BASE_URL}{i[2:]}" for i in parseDOM(blocks, 'a', ret='href')[::3]]
    posters = [f'{BASE_URL}{i[2:]}' for i in parseDOM(blocks, 'img', ret='src')]
    emisja = [re.findall('>(.+?)<', i)[-1] for i in parseDOM(blocks, 'p', {'class': 'time'})]
    titles = [parseDOM(i, 'a')[1:3] for i in blocks]
    episodes = [f"{re.sub('<span.*?span>', '', t[1])}" for t in titles]
    titles = [f"{t[0]}" for t in titles]
    for item in zip(links, titles, emisja, posters, episodes):
        data['tvshowtitle'] = item[1]

        label = f'{item[1]} - {item[4]} - {item[2]}'
        ep_no = re.findall('\d+$', item[4])[0]
        data['episode'] = ep_no
        data.update({'poster': item[3],
                    'thumb': item[3]})
        addLink(label, item[0], 'AZListLinks',
               data=data)


def ListTitles(url=None):


    data = params['data']
    section = data.get('section')
    if not url:
        url = params['url']

    result = requests.get(url, timeout=15).text
    result = CleanHTML(result).replace('<mark>', '').replace('</mark>', '')
    # parse items
    blocks = parseDOM(result, 'div', {'class': r'well .*?'})
    links = [f'{BASE_URL}{i}' for i in parseDOM(blocks, 'a', ret='href')[::2]]
    posters = [f'{BASE_URL}{i}' for i in parseDOM(blocks, 'img', ret='src')]
    titles = parseDOM(blocks, 'a')[1::2]
    plots = parseDOM(blocks, 'p')


    try:
        rates = [re.findall('fa.*?([\d.]+)', i)[0] for i in blocks]
    except IndexError:
        rates = ['' for i in links]

    if section == 'seasons':
        pages = parseDOM(result, 'ul', {'class': 'pager'})
        next_url = None
        try:
            pages = [[parseDOM(i, 'a', ret='href')[0], parseDOM(i, 'a', )[0]]
                     for i in parseDOM(pages, 'li')]
            pages = [[f"{BASE_URL}{p[0]}", f"{re.sub('&.+?;', '', p[1])} sezon"] for p in pages]
            for idx, p in enumerate(pages):
                parts = p[0].split('/')
                pages[idx][1] = f'{p[1]} {parts[-1].capitalize()} {parts[-2]}'
            previous_season = pages[0]
            next_season = pages[1]
        except IndexError:
            previous_season = None
            next_season = None
    else:

        next_url = parseDOM(result, 'ul', {'class': 'pagination'})
        previous_season = None
        next_season = None
        try:
            next_url = [parseDOM(i, 'a', ret='href')[0] for i in parseDOM(next_url, 'li') if '&raquo;' in i]
            next_url = [f"{BASE_URL}{next_url[0]}", '[I]następna strona[/I]']
        except IndexError:
            next_url = None

    if previous_season:
       addDir(previous_season[1], previous_season[0], 'AZListTitles',
              data={'fanart': default_background, 'previouspage': True,
                     'thumb': calendaricon, 'poster': calendaricon,
                    'section': 'seasons'})

    for item in zip(links, posters, titles, plots, rates):
        addDir(item[2], item[0], 'AZListEpisodes',
               data={'fanart': default_background, 'poster': item[1],
                     'thumb': item[1], 'plot': item[3], 'rate': item[4]})
    if next_url:
        addDir('[I]następna strona[/I]', next_url, 'AZListTitles',
               data={'fanart': default_background, 'nextpage': True,
                     'thumb': nexticon})
    if next_season:
        addDir(next_season[1], next_season[0], 'AZListTitles',
             data={'fanart': default_background, 'nextpage': True,
                   'thumb': calendaricon, 'poster': calendaricon,
                   'section': 'seasons'})

    xbmcplugin.setContent(addon_handle, 'tvshows')


def ListEpisodes():

    name = params['name']
    url = params['url']

    result = cache.get(fetch_page, 24, url)
    result = parseDOM(result, 'div', {'class': 'site-main'})[0]
    poster = f"{BASE_URL}{parseDOM(result, 'img', ret='src')[0]}"
    year = [re.findall('[\d]{4}', i)[0] for i in parseDOM(result, 'tr') if 'Rok' in i][0] or None
    genre = [parseDOM(i, 'td')[1] for i in parseDOM(result, 'tr') if 'Tematyka' in i][0].split(',')
    type = [parseDOM(i, 'td')[1] for i in parseDOM(result, 'tr') if 'Rodzaj' in i][0]
    ep_blocks = [i for i in parseDOM(result, 'tr') if 'class="episode' in i][1:]
    ep_titles = parseDOM(ep_blocks, 'td', {'class' : 'episode-title'})[::-1]
    ep_numbers = [parseDOM(i, 'td')[0].replace('<strong>', '').replace('</strong>', '') for i in ep_blocks][::-1]
    ep_links = [f"{BASE_URL}{i.replace('..', '')}" for i in parseDOM(ep_blocks, 'a', ret='href')][::-1]
    ep_release = [re.search('[\d]+-[\d]+-[\d]+', i) for i in ep_blocks][::-1]

    for i in zip(ep_links, ep_numbers, ep_release, ep_titles):

        data = {
                'poster': poster,
                'thumb': poster,
                'year': year,
                'genre': genre,
                }
        if i[3]:
            data['title'] = f'{i[1]} - {i[3]}'
        else:
            data['title'] = i[1]
        if i[2]:
            data['premiered'] = i[2].group(0)
        if type == 'TV':
            data['tvshowtitle'] = name
            data['episode'] = i[1]

        print(i[0], data['title'], data)
        addLink(data['title'], i[0], 'AZListLinks',
                data=data)
    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)



def ListLinks():

    name = params['name']
    url = params['url']
    data = params['data']

    result = cache.get(fetch_page, 24, url)

    link_block = parseDOM(result, 'tr')
    lang = [re.findall('"sprites(.+?)lang"', i) for i in link_block][1:]
    player_list = parseDOM(link_block, 'td')
    player_list = [re.sub('<.*?>', '', t) for t in player_list]
    subdir = data.get('tvshowtitle')
    # players = []
    enc_links = get_links(url, player_list)
    link = [i[0][0] for i in zip(enc_links, lang)]
    players = [f'{i[0][1].strip()}  {i[1][0]}' for i in zip(enc_links, lang)]

    SourceSelect(players, link, name, subdir)


def get_links(url, players):

    s = requests.Session()
    s.get('https://www.animezone.pl/images/statistics.gif')
    HDR = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.26 Safari/537.36',
        'referer': url,
    }
    cookie = s.cookies.get_dict()
    urls = [url for i in players]
    def decode_links(url, player):
        res = s.get(url)
        player_block = parseDOM(res.text, 'tr')
        link_code = [re.findall('data-.*="([0-9]+:.*)">', i)[0] for i in player_block if player in i]
        data = {'data': link_code[0]}
        response = s.post(url, headers=HDR, cookies=cookie, data=data)
        try:
            link = parseDOM(response.text, 'a', ret='href')[0]
        except:
            link = parseDOM(response.text, 'iframe', ret='src')[0]
        return link, player
    links = thread_it_multi(decode_links, 0, urls, players)
    return links

def Search():

    addDir("[B]Nowe wyszukiwanie...[/B]", search_url, 'AZSearchnew',
                 fanart=default_background, section='search')

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            url = search_url + quote
            addDir(term, url, "AZListTitles",
                   fanart=default_background, thumb=searchicon)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
               fanart=default_background)

def Searchnew():


    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = search_url + quote_plus(search)
    ListTitles(url)


def fetch_page(url):

    HDR = {'user-agent': UA,
           'cookie': get_cookie()}
    return requests.get(url, headers=HDR, timeout=15).text


def get_cookie():
    now = int(time.time())
    exp = 1209600  # 14 days cookie valid
    cached_cookie = cache.cache_get(COOKIE)
    if cached_cookie:
        if now - cached_cookie['date'] > exp:
            Logowanie()
            return cache.cache_get(COOKIE)['value']
        return cached_cookie['value']
    else:
        Logowanie()
        return cache.cache_get(COOKIE)['value']

def Ranking():

    url = params['url']
    result = cache.get(fetch_page, 24, url)
    data_blocks = parseDOM(result, 'tr')[1:]
    links = [f'{BASE_URL}{i}' for i in parseDOM(data_blocks, 'a', ret='href')]
    numer_data = [re.findall('\"text-center\">(.+?)</td>', i) for i in data_blocks]
    titles = parseDOM(data_blocks, 'a')
    for item in zip(links, titles, numer_data):

        type = 'movie' if '/filmy' in url else 'tvshow'
        data = {'title': item[1], 'rate': item[2][1],
                'fanart': default_background, 'poster': posterAzone,
                'thumb': posterAzone}
        if type == 'tvshow':
            data['tvshowtitle'] = item[1]

        addDir(f'{item[2][0]} -- {item[1]}', item[0], 'AZListEpisodes',
               data=data)


def Logowanie(popup=False):

    data = {
        'login': Getsetting('useranimezone'),
        'password': Getsetting('passanimezone')}
    sess = requests.session()
    GetLogin = sess.post('https://www.animezone.pl/login', data=data)
    response = GetLogin.status_code
    kuki = sess.cookies.get_dict()
    cookie = "; ".join([f'{k}={v}' for k, v in kuki.items()])
    cache.cache_insert(COOKIE, cookie)

    if response == 200:
        if len(re.findall('Wyloguj się', GetLogin.text, re.IGNORECASE)) >= 1:
            if popup == True:

                dialog = xbmcgui.Dialog()
                dialog.notification('animezone.pl ', 'Zalogowano pomyślnie.', xbmcgui.NOTIFICATION_INFO, 5000, sound=False)
            else:
                pass
        else:
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno('Nie jesteś zalogowany', 'animezone.pl. \nWprowadź dane logowania w ustawieniach wtyczki' ,
                               'Wyjdź', 'Ustawienia')
            if ret:
                #libs.my_addon.openSettings()
                xbmc.executebuiltin('Container.Refresh')
    else:
        d = xbmcgui.Dialog()
        d.notification('animezone.pl ',
                       '[COLOR red]%s[/COLOR]' % ('Problem  -  Błąd serwera -' + str(response)),
                       xbmcgui.NOTIFICATION_INFO, 5000)
        exit()

def AnimezonePass_Check():

    if (Getsetting('useranimezone') == '') or (Getsetting('passanimezone') == ''):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Konta',
                           'Włączony host AnimeZone, ale nie podano danych konta \n'
                           'Wprowadź dane konta w ustawieniach \n'
                           'lub wyłącz hosta',
                           'Wyłącz hosta', 'Ustawienia')
        if ret:
            openSettings('1.5')
        else:
            Setsetting('AZ.active', 'false')
            xbmc.executebuiltin('Container.Refresh')
    else:
        return
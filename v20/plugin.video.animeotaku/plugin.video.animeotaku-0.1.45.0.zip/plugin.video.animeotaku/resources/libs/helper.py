import re
import json
import xbmc, xbmcaddon
import base64
from hashlib import md5
import requests
from html import unescape
from inspect import isclass, currentframe


# regex na wyszukiwanie sezonu z nazw
SEASON_PATTERN = re.compile(
    r'(?i)(?:'                           # case-insensitive
    r'\bSeason\s*(\d+)|'                 # Season 2
    r'\bSezon\s*(\d+)|'                  # Sezon 2
    r'\bPart\s*(\d+)|'                   # Part 2
    r'\b(\d+)(?:st|nd|rd|th)\s*Season\b|'# 2nd Season
    r'\b(\d+)(?:st|nd|rd|th)\b|'         # 2nd
    r'(?<=\D)(\d+)\s*$'                  # liczba na końcu, ale po znaku niebędącym cyfrą
    r')'
)



my_addon = xbmcaddon.Addon()
plugin = my_addon.getAddonInfo('id')

def metadataClean(metadata):
    if not metadata: return metadata
    allowed = ['genre', 'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide',
               'showlink', 'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount',
               'overlay', 'cast', 'castandrole', 'director', 'mpaa', 'plot', 'plotoutline', 'title',
               'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer', 'tvshowtitle',
               'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits',
               'lastplayed', 'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid']
    return {k: v for k, v in metadata.items() if k in allowed}

def CleanHTML(html):
    if ("&amp;" in html):
        html = html.replace('&amp;', '&')
    if ("&nbsp;" in html):
        html = html.replace('&nbsp;', '')
    if ('[&hellip;]' in html):
        html = html.replace('[&hellip;]', '[…]')
    if (u'\u2019' in html):
        html = html.replace(u'\u2019', '\'')
    if (u'\u2661' in html):
        html = html.replace(u'\u2661', ' ')
    if (u'\u222c' in html):
        html = html.replace(u'\u222c', ' ')
    if ('<br />\n' in html):
        html = html.replace('<br />\n', ' ')
    if ('&#' in html) and (';' in html):
        if ("&#8211;" in html):
            html = html.replace("&#8211;", "-")
        if ("&#8216;" in html):
            html = html.replace("&#8216;", "'")
        if ("&#8217;" in html):
            html = html.replace("&#8217;", "'")
        if ("&#8220;" in html):
            html = html.replace('&#8220;', '"')
        if ("&#8221;" in html):
            html = html.replace('&#8221;', '"')
        if ("&#0421;" in html):
            html = html.replace('&#0421;', "")
        if ("&#038;" in html):
            html = html.replace('&#038;', "&")
        if ('&#8230;' in html):
            html = html.replace('&#8230;', '[…]')

    return html


def flat_html(html):
    return html.replace("\r", "").replace("\n", "")


def clear_HTML_tags(tekst):

    """
    Remove all HTML tags from the input text while preserving the actual content.
    Args:
        tekst (str): Input text containing HTML tags
    Returns:
        str: Clean text with all HTML tags removed, excess whitespace trimmed
    """

    # Usuń najpierw wszystkie tagi HTML, zachowując tekst
    tekst_clean = re.sub(r'<[^>]+>', ' ', tekst)

    # Usuń nadmiarowe spacje i białe znaki
    tekst_clean = re.sub(r'\s+', ' ', tekst_clean)

    # Usuń pozostałe znaki specjalne i nadmiarowe spacje na początku/końcu
    return tekst_clean.strip()


def colored(text, color):
    return f'[COLOR={color}]{text}[/COLOR]'


def decrypt(hashed):
    return base64.b64decode(hashed.encode('ascii')).decode('ascii')


def hash_md5(string: str):
    md = md5(string.encode('utf-8'))
    return md.hexdigest()


def EVP_BytesToKey(data: bytes, salt: bytes, key_len: int, iv_len: int, count: int):
    assert data, "data (password) must not be empty"
    assert key_len > 0, "key_len must be > 0"
    assert iv_len >= 0, "iv_len must be >= 0"
    if salt:
        assert len(salt) == 8, "salt must be 8 bytes long"
    assert count >= 1, "count must be >= 1"

    key = b''
    iv = b''
    prev = b''

    while len(key) < key_len or len(iv) < iv_len:
        m = md5()
        m.update(prev)
        m.update(data)
        if salt:
            m.update(salt)
        digest = m.digest()

        # repeat hash count-1 times
        for _ in range(count - 1):
            m = md5()
            m.update(digest)
            digest = m.digest()

        needed_key = key_len - len(key)
        if needed_key > 0:
            key += digest[:needed_key]
        needed_iv = iv_len - len(iv)
        if needed_iv > 0:
            iv += digest[needed_key:needed_key + needed_iv]
        prev = digest

    return key, iv


def get_season_number(title: str) -> int:
    match = SEASON_PATTERN.search(title)
    if match:
        return int(next(g for g in match.groups() if g))
    return 1


def czas_na_sekundy(text):
    hours = 0
    minutes = 0
    h_match = re.search(r'(\d+)\s*hr', text)
    m_match = re.search(r'(\d+)\s*min', text)
    if h_match:
        hours = int(h_match.group(1))
    if m_match:
        minutes = int(m_match.group(1))
    return hours * 3600 + minutes * 60


def fetch_page(url, headers=None, cookie=None):
    res = requests.get(url, headers=headers, cookies=cookie, timeout=15).text
    return unescape(res)


####################################################################
#  ParseDOM
####################################################################
def _getDOMContent(html, name, match, ret):  # Cleanup

    endstr = f'</{name}'  # + '>'
    start = html.find(match)
    end = html.find(endstr, start)
    pos = html.find('<' + name, start + 1)

    while pos < end and pos != -1:  # Ignore too early </endstr> return
        tend = html.find(endstr, end + len(endstr))
        if tend != -1:
            end = tend
        pos = html.find("<" + name, pos + 1)
    if (start == -1) and (end == -1):
        result = ""
    elif start > -1 and end > -1:
        result = html[start + len(match):end]
    elif end > -1:
        result = html[:end]
    elif start > -1:
        result = html[start + len(match):]
    if ret:
        endstr = html[end:html.find(">", html.find(endstr)) + 1]
        result = match + result + endstr
    return result


def _getDOMAttributes(match, name, ret):

    lst = re.compile(f'''<{name}.*?{ret}=([\'"].[^>]*?[\'"])>''', re.M | re.S).findall(match)
    if len(lst) == 0:
        lst = re.compile(f'''<{name}.*?{ret}=(.[^>]*?)>''', re.M | re.S).findall(match)
    ret = []
    for tmp in lst:
        cont_char = tmp[0]
        if cont_char in "'\"":
            #log(f'Using {cont_char} as quotation mark')
            # Limit down to next variable.
            if tmp.find('=' + cont_char, tmp.find(cont_char, 1)) > -1:
                tmp = tmp[:tmp.find('=' + cont_char, tmp.find(cont_char, 1))]

            # Limit to the last quotation mark
            if tmp.rfind(cont_char, 1) > -1:
                tmp = tmp[1:tmp.rfind(cont_char)]
        else:
            if tmp.find(" ") > 0:
                tmp = tmp[:tmp.find(" ")]
            elif tmp.find("/") > 0:
                tmp = tmp[:tmp.find("/")]
            elif tmp.find(">") > 0:
                tmp = tmp[:tmp.find(">")]
        ret.append(tmp.strip())
    return ret


def _getDOMElements(item, name, attrs):

    lst = []
    for key in attrs:
        lst2 = re.compile(f'''(<{name}[^>]*?(?:{key}=[\'"]{attrs[key]}[\'"].*?>))''', re.M | re.S).findall(item)

        if len(lst2) == 0 and attrs[key].find(" ") == -1:  # Try matching without quotation marks
            lst2 = re.compile(f'''(<{name}[^>]*?(?:{key}={attrs[key]}.*?>))''', re.M | re.S).findall(item)

        if len(lst) == 0:
            lst = lst2
            lst2 = []
        else:
            test = list(range(len(lst)))
            test.reverse()
            for i in test:  # Delete anything missing from the next list.
                if not lst[i] in lst2:
                    del(lst[i])

    if len(lst) == 0 and attrs == {}:
        lst = re.compile(f'''(<{name}>)''', re.M | re.S).findall(item)
        if len(lst) == 0:
            lst = re.compile(f'''(<{name} .*?>)''', re.M | re.S).findall(item)
    return lst

def parseDOM(html, name="", attrs={}, ret=False):
    """
        parseDOM module:
        parseDOM(self, html, name = "", attrs = {}, ret = False)
        :param html: (string or list) - String to parse, or list of strings to parse.
        :param name: (string) - Element to match ( for instance "span" )
        :param attrs: (dict or str) - Dictionary with attributes you want matched in the element.
                    ex { "id": "span3", "class": "oneclass.*anotherclass", "attribute": "a random tag" }
                                    - attribute only allowed as string
                    ex { "id", "attribute": "a random tag" }
        :param ret: (string or False) - Attribute in element to return value of. If not set(or False), returns content of DOM element.

        :return: list
        """
    if isinstance(name, str):
        try:
            name = name
        except:
            _log(f"Couldn't decode name binary string: {repr(name)}", 0)

    if isinstance(html, str):
        html = [html]
    elif not isinstance(html, list):
        _log("Input isn't list or string/unicode.", 0)
        return ""
    if not name.strip():
        _log("Missing tag name", 0)
        return ""
    if isinstance(attrs, str):
        attrs = {attrs: ""}
    if isinstance(attrs, list):
        attrs = dict((atr, "") for atr in attrs)
    ret_lst = []
    for item in html:
        temp_item = re.compile('(<[^>]*?\n[^>]*?>)').findall(item)
        for match in temp_item:
            item = item.replace(match, match.replace("\n", " "))
        lst = _getDOMElements(item, name, attrs)

        if isinstance(ret, str):
            lst2 = []
            for match in lst:
                lst2 += _getDOMAttributes(match, name, ret)
            lst = lst2
        else:
            lst2 = []
            for match in lst:
                temp = _getDOMContent(item, name, match, ret).strip()
                item = item[item.find(temp, item.find(match)) + len(temp):]
                lst2.append(temp)
            lst = lst2
        ret_lst += lst
    return ret_lst


def _log(description, level=1):
    #loglevel == -1 (NONE, nothing at all is logged to the log)
    #loglevel == 0 (NORMAL, shows LOGINFO, LOGWARNING, LOGERROR and LOGFATAL) - Default kodi behaviour
    #loglevel == 1 (DEBUG, shows all) - Behaviour if you toggle debug log in the GUI

    if (level == 'LOGINFO') or (level == 0): level = xbmc.LOGINFO
    elif level == 'LOGWARNING': level = xbmc.LOGWARNING
    elif level == 'LOGERROR': level = xbmc.LOGERROR
    elif level == 'LOGFATAL': level = xbmc.LOGFATAL
    elif level == 'LOGDEBUG' : level = xbmc.LOGDEBUG

    try:
        xbmc.log(f'[{plugin}] : {description}', level)
    except:
        xbmc.log(f"[{plugin}] : {repr(description)}", level)

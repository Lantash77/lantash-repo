# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Docchi.pl
# Part of code thanks to Scorupa
###############################################################################
###############################################################################
### Imports ###
#import re
#import sys
#import xbmcgui, xbmcplugin, xbmc
import requests
from resources import libs
import time
from datetime import date, datetime
from urllib.parse import quote_plus, quote
from collections import namedtuple
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor

from resources.libs import cache
from resources.libs.addon_tools import *
from resources.libs.helper import *

MEDIA = libs.MEDIA


searchFile = libs.searchFile
settings = libs.settings


params = get_params()

# media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
trashicon = MEDIA + 'trash.png'
#fanartDesu = MEDIA + 'desu.jpg'
limit = settings.getInt('DC.page') or 30

# HTML HEADER
host = 'Docchi'
BASE_URL = 'https://api.docchi.pl/v1'

@dataclass
class Season:
    en: str
    year: int
    pl: str = field(init=False)

    def __post_init__(self):
        mapping = {
            'spring': 'Wiosna',
            'summer': 'Lato',
            'fall': 'Jesień',
            'autumn': 'Jesień',
            'winter': 'Zima'
        }
        self.pl = mapping.get(self.en.lower(), self.en)


class Docci:

    HOME_LINK = f'https://docchi.pl/_next/data/{{}}/{{}}.json'
    ANIME_LIST_URL = f'{BASE_URL}/series/list'
    ANIME_DETAILS_URL = f'{BASE_URL}/series/find/{{}}'
    EPISODES_URL = f'{BASE_URL}/episodes/count/{{}}'
    LINKS_URL = f'{BASE_URL}/episodes/find/{{}}/{{}}'
    SEARCH_URL = f'{BASE_URL}/series/related/{{}}'
    GENRE_URL = f'https://docchi.pl/_next/data/{{}}/pl/production/as/list.json?tags={{}}'

    SESS = requests.session()

    def __init__(self):

        self.main_list()
        self.get_list()
    def jget(self, url):
        return self.SESS.get(url).json()

    def paginate_list(self, list):
        return [list[i:i + limit] for i in range(0, len(list), limit)]


    def get_buildID(self):

        r = self.SESS.get('https://docchi.pl/')
        id = re.search(r'"buildId":"(.*?)"', r.text).group(1)
        return id

    def main_list(self):
        self.lista_glowna = cache.get(self.jget, 24 * 3600,
                                      self.HOME_LINK.format(self.get_buildID(), 'pl'))
        self.lista_glowna = self.clean_list(self.lista_glowna)

        curr_season = self.get_current_season()

        MASTER = {'trending': 'Najpopularniejsze miesiąca',
                  'series': 'Nowo dodane tytuły',
                  'season': f'{curr_season.pl} {curr_season.year}',
                  'emitted': 'Ostatnio dodane'}

        self.main_list_names = [[MASTER[i], i] for i in self.lista_glowna]


    def get_list(self):

        self.lista_all = cache.get(self.jget, 24 * 3600, self.ANIME_LIST_URL)


    def create_genres_list(self):
        genres_set = set()

        # Iteruj przez wszystkie elementy w lista_all
        for item in self.lista_all:
            if 'genres' in item and item['genres']:
                # Jeśli genres to lista
                if isinstance(item['genres'], list):
                    genres_set.update(item['genres'])
                # Jeśli genres to pojedynczy string
                else:
                    genres_set.add(item['genres'])

        # Konwertuj set na posortowaną listę
        genres_list = sorted(list(genres_set))
        return genres_list

    def create_season_list(self):
        season_dict = {}
        # Mapowanie angielskich nazw sezonów na polskie
        season_mapping = {
            'spring': 'Wiosna',
            'summer': 'Lato',
            'fall': 'Jesień',
            'autumn': 'Jesień',
            'winter': 'Zima'
        }
        for item in self.lista_all:
            # Sprawdź czy istnieją wymagane pola
            if 'season' not in item or 'season_year' not in item:
                continue

            season_name = item.get('season')
            season_year = item.get('season_year')
            # Pomiń jeśli brakuje danych lub season to "Nieznany"
            if not season_name or not season_year or season_name == 'Nieznany':
                continue
            # Konwertuj nazwę sezonu na małe litery dla mapowania
            season_lower = season_name.lower()
            # Przetłumacz nazwę sezonu na polski (jeśli znajdzie mapowanie)
            polish_season = season_mapping.get(season_lower, season_name)
            key = f"{polish_season} {season_year}"
            # Dodaj do słownika jeśli jeszcze nie istnieje
            if key not in season_dict:
                season_dict[key] = [season_lower, season_year]
        # Sortowanie według roku i sezonu
        season_order = ['winter', 'spring', 'summer', 'fall', 'autumn']
        sorted_seasons = sorted(season_dict.items(),
                                key=lambda x: (x[1][1], season_order.index(x[1][0])
                                if x[1][0] in season_order else 99),
                                reverse=True)  # Najnowsze sezony najpierw

        return dict(sorted_seasons)

    @staticmethod
    def get_current_season():
        """
		Get current anime season
		:return: tuple of season and season_year
		"""

        now = datetime.now()
        current_year = now.year

        # 1 kwietnia zaczyna się wiosna
        if now < datetime(current_year, 4, 1):
            # [1 stycznia ~ 31 marca)
            return Season("winter", current_year)
        if now < datetime(current_year, 7, 1):
            # [1 kwietnia ~ 30 czerwca)
            return Season("spring", current_year)
        if now < datetime(current_year, 10, 1):
            # [1 lipca ~ 30 września)
            return Season("summer", current_year)
        if now < datetime(current_year, 12, 1):
            # [1 października ~ 30 listopada)
            return Season("fall", current_year)
        # [1 grudnia ~ 31 grudnia]
        return Season("winter", current_year)


    def get_anime_list(self):
        self.lista_anime = [i for i in self.lista_all if i['series_type'] != 'Movie']
        return self.paginate_list(self.lista_anime)


    def get_movie_list(self):
        self.lista_movies = [i for i in self.lista_all if i['series_type'] == 'Movie']
        return self.paginate_list(self.lista_movies)



    def get_episode_list(self, slug):

        self.episodes = cache.get(self.jget, 24* 3600, self.EPISODES_URL.format(slug))
        return self.episodes

    def get_search_res(self, query):
        self.list_results = cache.get(self.jget, 24* 3600, self.SEARCH_URL.format(query))
        return self.list_results

    def get_episode_players(self, slug: str, episode: int):
        self.links = cache.get(self.jget, 24*3600, self.LINKS_URL.format(slug, episode))
        return self.links

    def get_genre_list(self, query):
        # self.list_genre = cache.get(self.jget, 24, self.GENRE_URL.format(str(limit), query))
        #t = quote(query)
        u = self.GENRE_URL.format(self.get_buildID(), quote(query))
        #s = self.jget(u)
        self.list_genre = cache.get(self.jget, 24 * 3600, u)
        self.list_genre = self.list_genre['pageProps']['series']
        return self.list_genre

    def anime_list_by_id(self):
        self.ID_list = {elem['id'] : elem for elem in self.lista_anime['series']}
        #return self.ID_list

    def clean_list(self, list):

        list = list['pageProps']
        skip = ['groups', 'comments', 'community', 'device']
        cleaned_list = {k: v for k, v in list.items() if k not in skip}
        return cleaned_list

    def get_detailed_list(self, list):
        results = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = []

            for item in list:
                futures.append(executor.submit(self.get_anime_details, item['slug']))
                time.sleep(0.1)  # 200 ms przerwy między dodaniem zadań

            for future in futures:
                try:
                    results.append(future.result())
                except Exception as e:
                    # Możesz tu zrobić logging, np. print(f"Błąd dla linku: {e}")
                    results.append(None)

        return results


    def get_anime_details(self, slug):
        url = self.ANIME_DETAILS_URL.format(slug)
        res = self.jget(url)
        #adb = AnimeMappingDB()
        #aa = adb.get_by_mal_id(res['mal_id'])
        return res


def PageDocchi():


    names = DC.main_list_names

    addItem("Lista Anime", '0', 'DCListTitles',
           data={'fanart': default_background,
                 'section': 'anime'},
           isFolder=True)

    addItem("Lista Filmów", '0', 'DCListTitles',
            data={'fanart': default_background,
                  'section': 'movies'},
            isFolder=True)

    for name in names:
        if 'emitted' in name[1]:

            addItem(name[0], name[1], 'DCListNewEpisodes',
                   data={'fanart': default_background, 'section':'new_episodes'},
                   isFolder=True)
        else:

            addItem(name[0], name[1],'DCListTitles',
                   data={'fanart': default_background, 'section':'selected'},
                   isFolder=True)

    addItem("Gatunki", '', mode='DCGatunki',
           data={'thumb': searchicon, 'section': 'gatunki',
                 'poster': searchicon,
                 'fanart': default_background},
                 isFolder=True)

    #addItem("Sezony", '', mode='DCSezony',
    #        data={'thumb': searchicon,
    #              'poster': searchicon,
    #              'fanart': default_background},
    #        isFolder=True)


    addItem("Wyszukiwarka", '', 'DCSearch',
           data={'thumb': searchicon, 'poster': searchicon,
                 'fanart': default_background},
           isFolder=True)


def ListTitles(url=None):

    data = params['data']
    section = data['section']
    if not url:
        url = params['url']

    nextpage = False
    if section == 'anime':
        anime_list_ = DC.get_anime_list()[int(url)]
        anime_list = cache.get(DC.get_detailed_list, 24* 3600, anime_list_)
        if len(anime_list) == int(limit):
            nextpage = str(int(url) + 1)
    elif section == 'movies':
        anime_list_ = DC.get_movie_list()[int(url)]
        anime_list = cache.get(DC.get_detailed_list, 24 * 3600, anime_list_)
        if len(anime_list) == int(limit):
            nextpage = str(int(url) + 1)

    elif section == 'selected':
        anime_list_ = DC.lista_glowna[url]
        anime_list = cache.get(DC.get_detailed_list, 24 * 3600, anime_list_)
    elif section == 'search':
        anime_list_ = DC.get_search_res(url)
        anime_list = cache.get(DC.get_detailed_list, 24 * 3600, anime_list_)
    elif section == 'gatunki':
        anime_list = DC.get_genre_list(url)

    for anime in anime_list:


        meta = {'thumb': anime['cover'], 'icon': anime['cover'],
                'fanart': fanart, 'poster': anime['cover'],
                'banner': anime['cover'], 'clearart': '',
                'clearlogo': '',
                'title': anime['title'],
                'genre': anime['genres'],
                'year': anime['season_year'],

                'premiered': anime['aired_from'].split('T')[0] if anime.get('aired_from') else 0,
                'plot': anime.get('description', ''),
                'slug': anime['slug'],
                }

        if anime['series_type'] != 'Movie':
            meta['mediatype'] = 'tvshow'
            meta['tvshowtitle'] = anime['title']
            try:
                meta['season'] = int(anime['season'])
            except:
                meta['season'] = 1
            #meta['episodes'] = anime['ep_count']
            addItem(anime['title'], anime['slug'], 'DCListEpisodes',
                   data=meta, isFolder=True)
        else:
            meta['mediatype'] = 'movie'
            meta['subdir'] = anime['title']
            addItem(anime['title'], anime["slug"], 'DCListLinks',
                    data=meta, isFolder=False)

    if nextpage:
        meta['nextpage'] = True
        meta['section'] = section
        meta['page'] = nextpage
        addItem('[I]następna strona[/I]', nextpage, 'DCListTitles',
               data=meta, isFolder=True)

    xbmcplugin.setContent(addon_handle, 'tvshows')
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')


def ListEpisodes():

    data = params['data']
    if data.get('section') == 'new_episodes':
        episode_list = DC.lista_glowna['emitted']
    else:
        episode_list = DC.get_episode_list(params['url'])

    for ep in episode_list:
        meta = {'title': f"Odcinek {ep['anime_episode_number']}",
                'slug': ep['anime_id'],
                'season': data['season'],
                'episode': ep['anime_episode_number'],
                'year': data['year'],
                'plot': data['plot'],
                'premiered': data['premiered'],
                'fanart': data['fanart'],
                'poster': ep['bg'],
                'banner': data['banner'],
                'genre': data['genre'],
                'tvshowtitle': params['name'],
                'mediatype': 'tvshow',
                'subdir': params['name'],
                }

        addItem(f'{meta["title"]}', meta['slug'], 'DCListLinks',
                data=meta, isFolder=False)
        

    xbmcplugin.setContent(addon_handle, 'episodes')
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE)

def NewEpisodes():

    new_episode_list = DC.lista_glowna[params['url']]
    for ep in new_episode_list:
        meta = {'title': f"Odcinek {ep['anime_episode_number']}",
                'slug': ep['anime_id'],                
                'episode': ep['anime_episode_number'],                
                'tvshowtitle': ep['title'],
                'mediatype': 'tvshow',
                'subdir': ep['title'],
                }
        
        itemTitle = f'EP {meta["title"]} - {ep['title']}'
        addItem(itemTitle, meta['slug'], 'DCListLinks',
                     data=meta, isFolder=False)
    xbmcplugin.setContent(addon_handle, 'tvshows')
            
            
def Search():
    addItem("[B]Nowe wyszukiwanie...[/B]", '', 'DCSearchnew',
           data={'thumb': searchicon, 'poster': searchicon,
                 'fanart': default_background, 'section': 'search'},
           isFolder=True)


    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            addItem(term, quote, "DCListTitles",
                   data={'thumb': searchicon, 'poster': searchicon,
                         'fanart': default_background, 'section': 'search'},
                   isFolder=True)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addItem("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
                     data={'fanart': default_background, 'section': 'search'},
               isFolder=True)


def Searchnew():
    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = quote_plus(search)
    ListTitles(url)

def ListLinks():

    data = params['data']
    if data['mediatype'] == 'movie':
        players = DC.get_episode_players(params['url'], 1)
    else:
        players = DC.get_episode_players(params['url'], data['episode'])


    player = [p['player_hosting'] for p in players]
    playerlink = [l['player'] for l in players]

    SourceSelect(player, playerlink, data['title'], data['subdir'])


def Gatunki():

    tags = DC.create_genres_list()
    d = xbmcgui.Dialog()
    select = d.multiselect('Wybór Gatunku', tags)
    if select == None:
        PageDocchi()
        return
    seltags = []
    for idx in select:
        seltags.append(tags[idx])
    sep = ','
    url = sep.join(seltags)
    ListTitles(url)

def website_status():
    try:
        t = requests.head(BASE_URL).status_code
        if t == 200:
            return True
        return False
    except:
        return False


if website_status():
    DC = Docci()
    print('wait')

import os
import xbmcvfs
import xbmcaddon
import platform

my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
MEDIA = xbmcvfs.translatePath(PATH + "resources/media/")
DATA_PATH = xbmcvfs.translatePath(my_addon.getAddonInfo("profile"))
LETTERS = xbmcvfs.translatePath(MEDIA + 'letters/')
Getsetting = my_addon.getSetting
Setsetting = my_addon.setSetting
settings = my_addon.getSettings()

searchFile = os.path.join(DATA_PATH, "search.db")
Alfabet = list(map(chr, list(range(65, 91))))
if platform.system() == 'Windows':
    CF_cookie = {'cf_clearance':
              'jqcXedQvDlbbFpzPQzz.Jy1hzPmQ8ZkewFT.prPzmr8-1758094907-1.2.1.1-0FhWQex11fYp3lzor69d7nSRoGiskeOuTCKSB6_1Zb8kpz7e9EvugEtHwZvAfPIfYJ04GoIEhVRsRaOdQDqy73w5FsfL7mJR4BXC4u8l9Xmv_mwuWTbks0JzwhLxyxvtRuSPMjeYY8.4XkpZLzJJvUk_2WHfzgWutWzSOl55rUJGkPxuWu6jRcdeCOkWariBn6Ho9TnJrf_QTkWl4MRnVcar4.e5D8pPBgGPq0zws.BqAv5ZkbUTDiQur8VvrLrx'}
    UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
elif platform.system() == 'Linux':
    CF_cookie = {
        'cf_clearance': 'X0g3MIygW7gxSKiM.DTSmU.l6.ZuxOy_9jTGBAKAynQ-1762089984-1.2.1.1-zLaiTPEGQJK4HN196yy4jAKSFL3g2dkfG_sNNbienPwDpVUFBdAol6veIAqLIGGARTTjiT2A0EpEvhJqghISp.X1ze.frY4h97Vo1bIJLowHoCUWcZFqOL2hNPI_WfBWvEzeNvjQOxeYZMel0MND9wW4HfSv3L1supmaHeH_gwNCXCMBrlQqbL8RfpBw7b31Db37CgeHstdgY2wd6zI34A3SIDaZ5v5vII6l1pXdsFzB.aewT6J190HKGIHQ8zQs'
        }
    UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
elif platform.system() == 'Android':
    CF_cookie = {'cf_clearance': 'N5zO6ZjiQp0lcuCGXq22Kzg3DcFLP9CFArjCgsUCqH8-1762095502-1.2.1.1-BQKoUsvGP2YEYB79LbKUbdX18dzDk3YOL2ou_uhizThbSqtx8r9CaEBGREGgYHFXfhL9r29R9yjXvQfghOQAVzy7Gu3ga.M2SP72usqqIyVf8HGgWebLqlLjyszZjlhyVMxb_PIYFZmhWMhRxqrYfV1FDSqEIgzqMSyT_Rg5nqFffYVEZ.VQnltmg3VEVsaRvtLxsFJfLPWV07gV3VzPREaV933xHKG.lyux__IRPVY'}
    UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36'





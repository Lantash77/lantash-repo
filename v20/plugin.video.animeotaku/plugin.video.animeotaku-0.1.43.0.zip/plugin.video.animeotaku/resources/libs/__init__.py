import os
import xbmcvfs
import xbmcaddon

my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
MEDIA = xbmcvfs.translatePath(PATH + "resources/media/")
DATA_PATH = xbmcvfs.translatePath(my_addon.getAddonInfo("profile"))
LETTERS = xbmcvfs.translatePath(MEDIA + 'letters/')
Getsetting = my_addon.getSetting
Setsetting = my_addon.setSetting
settings = my_addon.getSettings()

searchFile = os.path.join(DATA_PATH, "search.db")
Alfabet = list(map(chr, list(range(65, 91))))
CF_cookie = {'cf_clearance':
              'jqcXedQvDlbbFpzPQzz.Jy1hzPmQ8ZkewFT.prPzmr8-1758094907-1.2.1.1-0FhWQex11fYp3lzor69d7nSRoGiskeOuTCKSB6_1Zb8kpz7e9EvugEtHwZvAfPIfYJ04GoIEhVRsRaOdQDqy73w5FsfL7mJR4BXC4u8l9Xmv_mwuWTbks0JzwhLxyxvtRuSPMjeYY8.4XkpZLzJJvUk_2WHfzgWutWzSOl55rUJGkPxuWu6jRcdeCOkWariBn6Ho9TnJrf_QTkWl4MRnVcar4.e5D8pPBgGPq0zws.BqAv5ZkbUTDiQur8VvrLrx'}
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"





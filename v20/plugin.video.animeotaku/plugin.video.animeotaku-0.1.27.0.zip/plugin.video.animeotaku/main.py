# -*- coding: UTF-8 -*-
#####Python 3.9 #######

#import os
#import sys
#import xbmc
#import xbmcaddon
#import xbmcgui
#import xbmcplugin
#import xbmcvfs
from resources import libs
from resources.libs.addon_tools import *


GetSetting = libs.Getsetting
SetSetting = libs.Setsetting
DATA_PATH = libs.DATA_PATH
searchFile = libs.searchFile
MEDIA = libs.MEDIA

default_background = MEDIA + "fanart.jpg"
iconSite = libs.PATH + 'icon.png'
iconWbijam = MEDIA + 'wbijam.jpg'
iconOdcinki = MEDIA + 'animeodcinki.jpg'
iconFrixysubs = MEDIA + 'frixysubs.jpg'
iconDesu = MEDIA + 'desu.jpg'
iconShinden = MEDIA + 'animeshinden.jpg'
iconAzone = MEDIA + 'animezone.jpg'
iconstrefadb = MEDIA + 'strefadb.jpg'
iconsettings = MEDIA + 'settings.png'
color = GetSetting('highlight.color')

Odcinkifanart = MEDIA + 'aodcfanart.jpg'
DBfanart = MEDIA + 'dbfanart.jpg'
########################################

########################################
def MainMenu():
###Wbijam.pl###
    '''
    if GetSetting('wbijam.active') == 'true':
        addDir(f'[COLOR={color}]Wbijam.pl[/COLOR]',
                     'https://inne.wbijam.pl/', 'Pagewbijam',
                     fanart=default_background, thumb=iconWbijam, isFolder=True)
    '''
###Frixysubs###
    if GetSetting('FS.active') == 'true':
        addDir(f'[COLOR={color}]Frixysubs.pl[/COLOR]',
                     'https://frixysubs.pl/', 'Frixysubs',
                     fanart=default_background, thumb=iconFrixysubs, isFolder=True)

###Desu-Online
    if GetSetting('DS.active') == 'true':
        #website status check
        if hostdesu.website_status():
            addDir(f'[COLOR={color}]Desu-Online.pl[/COLOR]', '', 'Desu',
                         fanart=default_background, thumb=iconDesu)
        else:
            addDir(f'[COLOR={color}]Desu-Online.pl <OFFLINE>[/COLOR]', '', 'desuoffline',
                         fanart=default_background, thumb=iconDesu)

###Anime Odcinki###
    if GetSetting('AO.active') == 'true':
        addDir(f'[COLOR={color}]Anime Odcinki[/COLOR]', 'https://anime-odcinki.pl/', 'AnimeOdcinki',
                     fanart=Odcinkifanart, thumb=iconOdcinki)
###Shinden.pl###
    if GetSetting('SH.active') == 'true':
        addDir(f'[COLOR={color}]Shinden.pl[/COLOR]',
                     'https://shinden.pl/series', 'Shinden',
                     fanart=default_background, thumb=iconShinden)
###AnimeZone###
    if GetSetting('AZ.active') == 'true':
        addDir(f'[COLOR={color}]AnimeZone[/COLOR]', '', 'AnimeZone',
               fanart=default_background, thumb=iconAzone)
###StrefaDB.pl###
    if GetSetting('DB.active') == 'true':
        addDir(f'[COLOR={color}]StrefaDB.pl[/COLOR]', 'https://strefadb.pl/', 'Dragonball',
                     fanart=DBfanart, thumb=iconstrefadb)
###Ustawienia###
    addDir('Ustawienia', '', 'Settings',
                 fanart=default_background, thumb=iconsettings, isFolder=True)


def PathCheck():

    if GetSetting('download.path') == '':
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Ustawień - Download', 
                           'Włączone pobieranie, ale nie ustawiono ścieżki pobierania \n'
                           'Wprowadź scieżkę pobierania w ustawieniach \n' 
                           'lub wyłącz pobieranie',
                           'Wyłącz', 'Ustawienia')
        if ret:
            openSettings('2.2')
        else:
            SetSetting('download.opt', 'false')
    else:
        return

def clear_search():
    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DROP TABLE IF EXISTS movies")
    dbcur.execute("VACUUM")
    dbcon.commit()
    dbcur.close()

############################################################################################################
#=########################################################################################################=#
#                                               GET PARAMS                                                 #
#=########################################################################################################=#

params = get_params()
url = params.get('url')
mode = params.get('mode', None)

###############################################################################################################
#=###########################################################################################################=#
#                                                   MODES                                                     #
#=###########################################################################################################=#


def mode_check():

    if (mode == '') or (mode == None) or (mode == 'MainMenu'):
        MainMenu()
    elif mode == 'Settings':
        openSettings()
        xbmc.executebuiltin('Container.Refresh')
        return
    elif mode == 'clear_search':
        clear_search()
        xbmc.executebuiltin('Container.Refresh')
        return

# WBIJAM.PL
    elif mode == 'Pagewbijam':
        hostwbijam.Pagewbijam()
    elif mode == 'Browse_Titles':
        hostwbijam.Browse_Titles()
        xbmcplugin.setContent(addon_handle, 'tvshows')
    elif mode == 'Browse_Seasons':
        hostwbijam.Browse_Seasons()
        xbmcplugin.setContent(addon_handle, 'seasons')
    elif mode == 'List_Episodes':
        hostwbijam.List_Episodes()
        xbmcplugin.setContent(addon_handle, 'episodes')
    elif mode == 'List_Links':
        hostwbijam.List_Links()

# FRIXYSUBS
    elif mode == 'Frixysubs':
        hostfrixysubs.PageFrixySubs()
    elif mode == 'FSListTitles':
        hostfrixysubs.ListTitles()
    elif mode == 'FSListEpisodes':
        hostfrixysubs.ListEpisodes()
    elif mode == 'FSListLinks':
        hostfrixysubs.ListLinks()
    elif mode == 'FSSearch':
        hostfrixysubs.Search()
    elif mode == 'FSSearchnew':
        hostfrixysubs.Searchnew()
    elif mode == 'FSGatunki':
        hostfrixysubs.Gatunki()
    elif mode == 'FSStudio':
        hostfrixysubs.Studio()
    elif mode == 'FSListNewEpisodes':
        hostfrixysubs.NewEpisodes()
        xbmcplugin.setContent(addon_handle, 'episodes')

# DESU-ONLINE
    elif mode == 'Desu':
        hostdesu.PageDesuOnline()
    elif mode == 'DSListTitles':
        hostdesu.ListTitles()
    elif mode == 'DSAlfa':
        hostdesu.Alfabetycznie()
    elif mode == 'DSListEpisodes':
        hostdesu.ListEpisodes()
    elif mode == 'DSListLinks':
        hostdesu.ListLinks()
    elif mode == 'DSSearch':
        hostdesu.Search()
    elif mode == 'DSSearchnew':
        hostdesu.Searchnew()
    elif mode == 'DSGatunki':
        hostdesu.Gatunki()


# ANIME-ODCINKI
    elif mode == 'AnimeOdcinki':
        hostanimeodcinki.PageAnimeOdcinki()
    elif mode == 'AOAlfabetycznie':
        hostanimeodcinki.Alfabetyczna()
    elif mode == 'AOListTitles':
        hostanimeodcinki.ListTitles()
        xbmcplugin.setContent(addon_handle, 'tvshows')
    elif mode == 'AOSearch':
        hostanimeodcinki.Search()
    elif mode == 'AOGatunki':
        hostanimeodcinki.Gatunki()
        xbmcplugin.setContent(addon_handle, 'genres')
    elif mode == 'AOListEpisodes':
        hostanimeodcinki.ListEpisodes()
        xbmcplugin.setContent(addon_handle, 'episodes')
    elif mode == 'AOListLinks':
        hostanimeodcinki.ListLinks()
    elif (mode == "AOSearchnew"):
        hostanimeodcinki.Searchnew()
    elif mode == "AOSearchResults":
        hostanimeodcinki.search_results(url)
        xbmcplugin.setContent(addon_handle, 'tvshows')
# ANIME-SHINDEN        
    elif mode == 'Shinden':
        hostanimeshinden.PageAnimeShinden()
    elif mode == 'SHAlfabetycznie':
        hostanimeshinden.Alfabetyczna()
    elif mode == 'SHListTitles':
        hostanimeshinden.ListTitles()
        xbmcplugin.setContent(addon_handle, 'tvshows')
    elif mode == 'SHSeasons':
        hostanimeshinden.ListSeasons()
        xbmcplugin.setContent(addon_handle, 'tvshows')
    elif mode == 'SHSeasonsTitles':
        hostanimeshinden.ListSeasonsTitles()
        xbmcplugin.setContent(addon_handle, 'tvshows')
    elif mode == 'SHSearch':
        hostanimeshinden.Search()
    elif mode == 'SHSearchnew':
        hostanimeshinden.Searchnew()
    elif mode == 'SHGatunki':
        hostanimeshinden.Gatunki()
        xbmcplugin.setContent(addon_handle, 'genres')
    elif mode == 'SHListEpisodes':
        hostanimeshinden.ListEpisodes()
        xbmcplugin.setContent(addon_handle, 'episodes')
    elif mode == 'SHListLinks':
        hostanimeshinden.ListLinks()
    elif mode == 'SHLogowanie':
        hostanimeshinden.Logowanie()

# ANIMEZONE
    elif mode == 'AnimeZone':
        hostanimezone.PageAnimeZone()
    elif mode == 'AZAlfabetycznie':
        hostanimezone.Alfabetyczna()
    elif mode == 'AZListTitles':
        hostanimezone.ListTitles()
    elif mode == 'AZSezony':
        hostanimezone.seasons()
    elif mode == 'AZCalendar':
        hostanimezone.calendar()
    elif mode == 'AZSearch':
        hostanimezone.Search()
    elif mode == 'AZSearchnew':
        hostanimezone.Searchnew()
    elif mode == 'AZListEpisodes':
        hostanimezone.ListEpisodes()
    elif mode == 'AZListLinks':
        hostanimezone.ListLinks()
    elif mode == 'AZRanking':
        hostanimezone.Ranking()


# STREFA-DB
    elif mode == 'Dragonball':
        hostdragon.Pagedragon()
        #xbmcplugin.setContent(addon_handle, 'tvshows')

    elif mode == 'DBListTitles':
        hostdragon.ListTitles()
        xbmcplugin.setContent(addon_handle, 'movies')
    elif mode == 'DBListEpisodes':
        hostdragon.ListEpisodes()
        xbmcplugin.setContent(addon_handle, 'episodes')
    elif mode == 'DBListLinks':
        hostdragon.ListLinks()

# Brak linku - monit
    elif mode == 'empty':
        dialog = xbmcgui.Dialog()
        dialog.notification('Anime Otaku', '[COLOR=red]Brak odcinków.[/COLOR]  Anime w planach',
                            xbmcgui.NOTIFICATION_INFO, 5000)
# Brak linku - monit
    elif mode == 'desuoffline':
        dialog = xbmcgui.Dialog()
        dialog.notification('Anime Otaku', '[COLOR=red]Strona chwilowo niedostępna[/COLOR]',
                            xbmcgui.NOTIFICATION_INFO, 5000)
        
# clear search list
    elif mode == 'delete_table':
        from resources.libs.scraper import delete_table
        delete_table()
    elif mode == 'clear_cache':
        from resources.libs import cache
        c = cache.cache_clear()
        if c:
            dialog = xbmcgui.Dialog()
            dialog.notification('anime-otaku ', '[COLOR=gold]Wyczyszczono cache.[/COLOR]',
                                xbmcgui.NOTIFICATION_INFO, 5000)
    endOfDir()

if GetSetting('download.opt') == 'true':
    PathCheck()
if GetSetting('wbijam.active') == 'true':
    from hosts import hostwbijam
if GetSetting('FS.active') == 'true':
    from hosts import hostfrixysubs
if GetSetting('DS.active') == 'true':
    from hosts import hostdesu
if GetSetting('AO.active') == 'true':
    from hosts import hostanimeodcinki
if GetSetting('SH.active') == 'true':
    from hosts import hostanimeshinden
    hostanimeshinden.ShindenPass_Check()
if GetSetting('AZ.active') == 'true':
    from hosts import hostanimezone
    hostanimezone.AnimezonePass_Check()
    xbmc.executebuiltin('Container.Refresh')
if GetSetting('DB.active') == 'true':
    from hosts import hostdragon
    hostdragon.DBPass_Check()
mode_check()
    
        

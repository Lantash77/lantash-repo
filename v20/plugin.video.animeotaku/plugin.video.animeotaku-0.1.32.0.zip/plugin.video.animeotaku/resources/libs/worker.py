from threading import Thread
import time


class Worker(Thread):
    def __init__(self, group=None, target=None, name=None,
                 args=(), kwargs={}):
        super().__init__(group, target, name, args, kwargs)
        self._return = None
    def run(self):
        #print(type(self._target))
        if self._target is not None:
            self._return = self._target(*self._args,
                                        **self._kwargs)
    def join(self, *args):
        Thread.join(self, *args)
        return self._return


def thread_it_multi(function, delay: int, *args, **kwargs) -> list:

    """
    :param function: Function to be executed
    :param delay: Duration of delay between start each thread
    :param args: Optional arguments for the provided function [enter as List]
    :param kwargs: Optional arguments for the provided function [enter as key=[List of dictionaries]
    :return:  function return [List]

    Useful function for executing functions in threads
     - select function
     - choose delay when needed or enter 0
     - provide arguments as Lists
       ex. thread_it_multi(function, 0, [param], key=[Value list]
       a=[11,21,28,41]
       b=[12,22,30,42]
       d=[13,15,33,43]
       thread_it_multi(foo, 0, a, b, c=d)

    delay  must be provided - 0 if no delay required ]
    List of args and kwargs must be same lenght !
    args and kwargs are transpositioned before preparing threads to start

    Credits to rysson for advice
    """
#############################################################################
    """
    Testowy upgrade pozwalający na pojedyncze kolejne argumenty
    (pierwszy musi być listą)
    zostaną utworzone listy z powielonych wartości argumentów
    ex. thread_it_multi(function, 0, param, key=value
            a=[11,21,28,41]
            b=foo
            d=bar
            thread_it_multi(foo, 0, a, b, c=d)
      utworzy przed transpozycją
           a=[11,21,28,41]
           b=[foo,foo,foo,foo]
           d=[bar,bar,bar,bar]
           
    Zachowuje kompatybilność wsteczną - można użyć list
"""
    # powielanie argumentów

    # *args:
    if isinstance(args[0], list):
        first_arg = args[0]
        args2 = []
        for arg in args:
            if isinstance(arg, list):
                args2.append(arg)
            else:
                args2.append([arg] * len(first_arg))
        args2 = tuple(args2)
    else:
        raise TypeError("Pierwszy argument musi być listą")
    # **kwargs
    kwargs2 = {}
    for key, value in kwargs.items():
        if isinstance(value, list):
            kwargs2[key] = value
        else:
            kwargs2[key] = [value] * len(first_arg)

    #args transposition
    A = len(args2)
    args_tr = zip(*args2, *kwargs2.values())
    th = [Worker(target=function, args=arg[:A],
                 kwargs=dict(zip(kwargs2, arg[A:]))) for arg in args_tr]

    for t in th:
        t.start()
        time.sleep(delay)
    return [i.join() for i in th]


def thread_it(start=True):
    """
    thread_it decorator

    :param output: optional [False, 'thread', True]
    When no output arg provided - Runs function in background and continue main script
    :return:  if output = True - starting function in thread and return value
    :return:  if output = thread - returns thread worker for further handle

    """
    def wrapper(function):
        def inner(*args, **kwargs):

            th = Worker(target=function, args=args,
                        kwargs=kwargs)

            if start:
                th.start()
                return th
            return th

        return inner
    if callable(start):
        func, start = start, True
        return wrapper(func)
    return wrapper




# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Desu-Online
###############################################################################
###############################################################################
### Imports ###
import re
import sys
import xbmcgui, xbmcplugin, xbmc
import requests
import hosts
from urllib.parse import quote_plus
from resources.libs import cache

from resources.libs.addon_tools import *
from resources.libs.helper import *

MEDIA = hosts.MEDIA
LETTERS = hosts.LETTERS

searchFile = hosts.searchFile
Getsetting = hosts.Getsetting


params = get_params()

# media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
fanartDesu = MEDIA + 'desu.jpg'
limit = int(Getsetting('DS.page'))
Alfabet = hosts.Alfabet
Alfabet.insert(0, '#')
Letters = [(LETTERS + item + '.png') for item in Alfabet]
Letter = dict(zip(Alfabet, Letters))

# HTML HEADER
HDR = {'User-Agent': 'KODI (anime-otaku)'}
SEARCH_URL = 'https://desu-online.pl/?s='

class Desu():
    BASE_URL = 'https://desu-online.pl/'
    ANIME_LIST_URL = f'{BASE_URL}anime/list-mode/'

    def __init__(self):
        self.main_list()
        self.alphabetic_list()
        self.popular_list()
        self.genres_list()
        self.studios_list()

    def fetch_page(self, url):
        return requests.get(url, headers=HDR).text

    def page_it(self, list):
        return [list[i:i + limit] for i in range(0, len(list), limit)]

    def main_list(self):
        self.result_page = cache.get(self.fetch_page, 48, self.ANIME_LIST_URL)
        self.list_page = parseDOM(self.result_page, 'div', {'class': 'soralist'})[0]
        self.all_list = parseDOM(self.list_page, 'li')
        self.all_list_paged = self.page_it(self.all_list)

    def alphabetic_list(self):
        self.lett_list = parseDOM(self.list_page, 'div', {'class': 'blix'})
        self.alpha_list = dict((parseDOM(i, 'a')[0], self.page_it(parseDOM(i, 'li')))
                               for i in self.lett_list)

    def popular_list(self):
        popularweekly = parseDOM(self.result_page, 'div',
                                 {'class': 'serieslist pop wpop wpop-weekly'})[0]
        self.popularweekly = parseDOM(popularweekly, 'li')
        popularmonth = parseDOM(self.result_page, 'div',
                                {'class': 'serieslist pop wpop wpop-monthly'})[0]
        self.popularmonth = parseDOM(popularmonth, 'li')
        popularall = parseDOM(self.result_page, 'div',
                              {'class': 'serieslist pop wpop wpop-alltime'})[0]
        self.popularall = parseDOM(popularall, 'li')

    def genres_list(self):
        genre_list = [i for i in parseDOM(self.result_page, 'div', {'class': 'filter .+?'})
                      if ' Gatunek' in i][0]
        self.genre_list = [[parseDOM(i, 'label')[0], parseDOM(i, 'input', ret='value')[0]]
                           for i in parseDOM(genre_list, 'li')]

    def studios_list(self):
        studio_list = [i for i in parseDOM(self.result_page, 'div', {'class': 'filter .+?'})
                       if ' Studio' in i][0]
        self.studio_list = [[parseDOM(i, 'label')[0], parseDOM(i, 'input', ret='value')[0]]
                            for i in parseDOM(studio_list, 'li')]


def website_status():
    t = requests.get(DS.BASE_URL, headers=HDR).status_code
    if t == 200:
        return True


def PageDesuOnline():
    addDir("Lista Anime", '0', 'DSListTitles',
           fanart=default_background, section='all')

    addDir("Alfabetycznie", '0', 'DSAlfa',
           fanart=default_background)

    addDir("Najpopularniejsze w tygodniu", 'weekly', 'DSListTitles',
           fanart=default_background, section='popular')

    addDir("Najpopularniejsze w miesiącu", 'monthly', 'DSListTitles',
           fanart=default_background, section='popular')

    addDir("Najpopularniejsze", 'all', 'DSListTitles',
           fanart=default_background, section='popular')

    addDir("Gatunki", '', 'DSGatunki',
           fanart=default_background, section='gatunki',
           thumb=searchicon)

    addDir("Wyszukiwarka", '', 'DSSearch',
           fanart=default_background, section='search',
           thumb=searchicon)

def ListTitles(url=''):
    section = params['section']
    if not url:
        url = params['url']

    data = {}
    nextpage = False
    if section == 'all':
        anime_list = DS.all_list_paged[int(url)]
        if len(anime_list) == int(limit):
            nextpage = str(int(url) + 1)

    elif section == 'alfabetyczny':
        dat = url.split('|')
        anime_list = DS.alpha_list[dat[0]][int(dat[1])]
        if len(anime_list) == int(limit):
            nextpage = f'{dat[0]}|{str(int(dat[1]) + 1)}'

    elif section == 'popular':
        anime_list = getattr(DS, f'{section}{url}')

    elif section == 'search':
        page = cache.get(DS.fetch_page, 24, url)
        res = parseDOM(page, 'div', {'class': 'listupd'})[0]
        res_nxt = parseDOM(page, 'div', {'class': 'pagination'})[0]
        anime_list = parseDOM(res, 'div', {'class': 'bsx'})
        if res_nxt:
            nextpage = parseDOM(res_nxt, 'a', {'class': 'next .+?'},
                                ret='href')[0]
    elif section == 'gatunki':
        page = cache.get(DS.fetch_page, 24, url)
        res = parseDOM(page, 'div', {'class': 'listupd'})[0]
        res_nxt = parseDOM(page, 'div', {'class': 'hpage'})[0]
        anime_list = parseDOM(res, 'div', {'class': 'bsx'})
        if res_nxt:
            nextpage = DS.BASE_URL + parseDOM(res_nxt, 'a', {'class': 'r'},
                                           ret='href')[0]

    for anime in anime_list:
        link = parseDOM(anime, 'a', ret='href')[0]
        if (section == 'all') or (section == 'alfabetyczny'):
            title = parseDOM(anime, 'a')[0]
            poster = fanartDesu
        elif section == 'popular':
            pos = parseDOM(anime, 'div', {'class': 'ctr'})[0]
            title = f"{pos} - {[parseDOM(i, 'a')[0] for i in parseDOM(anime, 'h4')][0]}"
            poster = parseDOM(anime, 'img', ret='data-src')[0]

        else:
            title = parseDOM(anime, 'h2')[0]
            poster = parseDOM(anime, 'img', ret='data-src')[0]

        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        addDir(title, link, 'DSListEpisodes', section='episodes',
               thumb=poster, fanart=custom_background, subdir=title,
               data=data)

    if nextpage:
        data['nextpage'] = True
        addDir('[I]następna strona[/I]', nextpage, 'DSListTitles',
               section=section, thumb=str(nexticon), fanart=custom_background,
               data=data)


def Alfabetycznie():
    for litera in Alfabet:
        addDir(litera, f'{litera}|0', 'DSListTitles', section='alfabetyczny',
               thumb=Letter[litera], fanart=custom_background)


def Search():
    addDir("[B]Nowe wyszukiwanie...[/B]", SEARCH_URL, 'DSSearchnew',
           fanart=default_background, section='search')

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            url = SEARCH_URL + quote
            addDir(term, url, "DSListTitles", fanart=default_background,
                   thumb=searchicon, section='search')
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search', fanart=default_background)

def Searchnew():
    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = SEARCH_URL + quote_plus(search)
    ListTitles(url)


def ListEpisodes():
    url = params['url']
    name = params['name']
    thumb = params['img']
    res = DS.fetch_page(url)
    epbox = parseDOM(res, 'div', {'class': 'eplister'})[0]
    ep_number = parseDOM(epbox, 'div', {'class': 'epl-num'})
    ep_titles = parseDOM(epbox, 'div', {'class': 'epl-title'})
    ep_links = parseDOM(epbox, 'a', ret='href')
    ep_list = zip(ep_titles, ep_number, ep_links)

    for ep in ep_list:
        addLink(f'{ep[1]} - {ep[0]}', ep[2], 'DSListLinks', subdir=name,
                poster=thumb)

    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)


def ListLinks():
    url = params['url']
    name = params['name']
    subdir = params['subdir']

    res = DS.fetch_page(url)
    sourcebox = parseDOM(res, 'select', {'class': 'mirror'})[0]

    players = parseDOM(sourcebox, 'option')[1:]
    playerlink = [parseDOM(decrypt(i), 'iframe', ret='src')[0]
                  for i in parseDOM(sourcebox, 'option', ret='value') if i != '']

    SourceSelect(players, playerlink, name, subdir)


def Gatunki():
    tags = DS.genre_list
    tag_list = [i[0] for i in tags]

    d = xbmcgui.Dialog()
    select = d.multiselect('Wybór Gatunku', tag_list)
    if select == None:
        PageDesuOnline()
        return
    seltags = []
    for idx in select:
        seltags.append('genre[]=' + tags[idx][1])
    sep = '&'
    url = f'{DS.BASE_URL}?{sep.join(seltags)}'
    ListTitles(url)


def Studio():
    pass

DS = Desu()

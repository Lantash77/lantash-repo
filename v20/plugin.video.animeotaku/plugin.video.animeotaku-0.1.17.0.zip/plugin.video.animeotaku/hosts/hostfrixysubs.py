# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# FrixySubs
###############################################################################
###############################################################################
### Imports ###

import hosts
import xbmcgui, xbmc, xbmcplugin
import sys
from datetime import date
import requests
from urllib.parse import quote_plus

#from resources.libs import addon_tools as addon
from resources.libs.addon_tools import *
from resources.libs import cache

MEDIA = hosts.MEDIA

searchFile = hosts.searchFile
Getsetting = hosts.Getsetting

params = get_params()
limit = int(Getsetting('FS.page'))
# media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
#fanartFrixysubs = MEDIA + 'frixysubs.jpg'
host = 'FrixySubs'

### ##########################################################################
### ##########################################################################

class FrixySubs():
    BASE_URL = 'https://frixysubs.pl/api/'
    ANIME_LIST_URL = f'{BASE_URL}anime?limit={{}}&offset=0'
    HOME_LINK = 'https://frixysubs.pl/api/home'
    EPISODES_URL = f'{BASE_URL}anime/{{}}'
    TAGS_LINK = f'{BASE_URL}tags?limit=0'
    STUDIOS_LINK = f'{BASE_URL}studios?limit=0'
    SEARCH_URL = f'{BASE_URL}anime?offset=0&limit={{}}&search={{}}'
    GENRE_URL = f'{BASE_URL}anime?offset=0&limit=0&tags={{}}'
    STUDIO_URL = f'{BASE_URL}anime?offset=0&limit=0&studio={{}}'
    MASTER = {'ongoing': 'Aktualnie wydawane serie', 'recommended': 'Polecane serie anime',
              'best': 'Najlepsze serie anime', 'episodes': 'Nowe odcinki'}
    SESS = requests.session()

    def __init__(self):

        self.tags_list()
        self.studios_list()
        self.get_list()
        self.main_list()

    def jget(self, url):
        return self.SESS.get(url).json()

    def get_list(self):

        self.lista_anime = cache.get(self.jget, 24, self.ANIME_LIST_URL.format('0'))
        self.clean_list(self.lista_anime)
        self.paginated_list = [self.lista_anime['series'][i:i + limit]
                               for i in range(0, self.lista_anime['rows_num'], limit)]
        return self.lista_anime['series']

    def main_list(self):

        self.lista_glowna = cache.get(self.jget, 24, self.HOME_LINK)
        self.clean_list(self.lista_glowna)
        self.main_list_names = [[self.MASTER[i], i] for i in self.lista_glowna]

    def tags_list(self):

        self.tags_list = cache.get(self.jget, 720, self.TAGS_LINK)
        self.tag_by_name = [[i['name'], i['id']] for i in self.tags_list]

    def studios_list(self):

        self.studio_list = cache.get(self.jget, 720, self.STUDIOS_LINK)
        self.studio_by_name = [[i['name'], i['id']] for i in self.studio_list]

    def get_episode_list(self, url):

        self.episodes = cache.get(self.jget, 24, self.EPISODES_URL.format(url))
        return self.episodes

    def get_search_res(self, query):
        self.list_results = cache.get(self.jget, 24, self.SEARCH_URL.format(str(limit), query))
        self.clean_list(self.list_results)
        return self.list_results['series']

    def get_genre_list(self, query):
        # self.list_genre = cache.get(self.jget, 24, self.GENRE_URL.format(str(limit), query))
        self.list_genre = cache.get(self.jget, 24, self.GENRE_URL.format(query))
        self.clean_list(self.list_genre)
        return self.list_genre['series']

    def get_studio_titles(self, query):
        self.list_studio = cache.get(self.jget, 24, self.STUDIO_URL.format(query))
        self.clean_list(self.list_studio)
        return self.list_studio['series']

    def clean_list(self, list):

        keys = [i for i in list]
        skip = ['rows_num', 'episodes']
        for key in keys:
            if key not in skip:
                for item in list[key]:
                    for tag in item['tags']:
                        try:
                            clean_tag = [i['name'] for i in self.tags_list if tag == i['id']][0]
                            list_index = list[key].index(item)
                            tag_index = item['tags'].index(tag)
                            list[key][list_index]['tags'][tag_index] = clean_tag
                        except:
                            continue
                    try:
                        clean_studio = [i['name'] for i in self.studio_list if item['studio'] == i['id']][0]
                        list_index = list[key].index(item)
                        list[key][list_index]['studio'] = clean_studio
                    except:
                        continue


def PageFrixySubs():
    names = FS.main_list_names

    addDir("Lista Anime", '0',
                 'FSListTitles', fanart=default_background, section='all')

    for name in names:
        if 'Nowe odcinki' in name[0]:
            # continue
            addDir(name[0], name[1],
                         'FSListNewEpisodes', fanart=default_background)
        else:

            addDir(name[0], name[1],
                         'FSListTitles', fanart=default_background,
                         section='selected')

    addDir("Gatunki", '', 'FSGatunki',
                 fanart=default_background, section='gatunki',
                 thumb=searchicon)

    addDir("Studio", '', 'FSStudio',
                 fanart=default_background, section='studio',
                 thumb=searchicon)

    addDir("Wyszukiwarka", '', 'FSSearch',
                 fanart=default_background, section='search',
                 thumb=searchicon)


def ListTitles(url=''):
    section = params['section']
    if not url:
        url = params['url']

    nextpage = False
    if section == 'selected':
        anime_list = FS.lista_glowna[url]
    elif section == 'all':
        anime_list = FS.paginated_list[int(url)]
        if len(anime_list) == int(limit):
            nextpage = str(int(url) + 1)
    elif section == 'search':
        anime_list = FS.get_search_res(url)
    elif section == 'gatunki':
        anime_list = FS.get_genre_list(url)
    elif section == 'studio':
        anime_list = FS.get_studio_titles(url)

    for anime in anime_list:

        data = {'thumb': anime['poster'], 'icon': anime['poster'],
                'fanart': anime['banner'], 'poster': anime['poster'],
                'banner': anime['banner'], 'clearart': '',
                'clearlogo': '',
                'title': anime['title'],
                'genre': anime['tags'],
                'year': anime['season']['year'],
                'rating': anime['rating'],
                'plot': anime['description'],
                'studio': anime['studio'],
                'season': anime['season']['season'],
                'episodes': anime['ep_count'],

                }

        if anime['status'] == 'Planowana':
            data['code'] = anime['status']
            addLink(anime['title'], anime['link'], 'empty', section='episodes',
                          thumb=data['thumb'], fanart=data['banner'], subdir=data['title'],
                          year=data['year'], data=data)

        else:
            if anime['movieserie'] == False:

                xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
                addDir(data['title'], anime['link'], 'FSListEpisodes', section='episodes',
                             thumb=data['thumb'], fanart=data['banner'], subdir=data['title'],
                             year=data['year'], data=data)

            else:
                xbmcplugin.setContent(int(sys.argv[1]), 'movies')
                addDir(anime['title'], f'{anime["link"]}|movie',
                             'FSListLinks', section='episodes',
                             thumb=data['thumb'], fanart=data['banner'], subdir=data['title'],
                             year=data['year'], data=data)

    if nextpage:
        data['nextpage'] = True
        addDir('[I]następna strona[/I]', nextpage, 'FSListTitles',
                     section='all', thumb=str(nexticon), fanart=custom_background, data=data)
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')


def NewEpisodes():
    new_episode_list = FS.lista_glowna['episodes']

    for ep in new_episode_list:

        data = {'thumb': ep['poster'], 'icon': ep['poster'],
                'fanart': ep['banner'], 'poster': ep['poster'],
                'banner': ep['banner'], 'clearart': '',
                'clearlogo': '',
                'title': ep['title'],
                'plot': ep['description'],
                'episode': ep['number'],
                'tvshowtitle': ep['serie']['title'],
                'url': ep['serie']['link']}

        if ep.get('added_at'):
            stamp = int(ep.get('added_at')[:-3])
            added = date.fromtimestamp(stamp)
            data['code'] = added.strftime("%Y-%m-%d")
            data['year'] = added.strftime("%Y")

        if ep['movie'] == False:
            xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            addDir(f'Odcinek {data["episode"]} - {data["tvshowtitle"]}', data['url'],
                         'FSListEpisodes',
                         thumb=data['thumb'], fanart=data['fanart'],
                         data=data)
        else:
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
            addDir(data['title'], f'{data["url"]}|movie',
                         'FSListEpisodes',
                         thumb=data['thumb'], fanart=data['fanart'],
                         year=data['year'], data=data)

    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')


def Search():
    addDir("[B]Nowe wyszukiwanie...[/B]", '', 'FSSearchnew',
                 fanart=default_background, thumb=searchicon, section='search')

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            addDir(term, quote, "FSListTitles", fanart=default_background,
                         thumb=searchicon, section='search')
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
                     fanart=default_background)


def Searchnew():
    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = quote_plus(search)

    ListTitles(url)


def ListEpisodes():
    # section = params['section']
    name = params['name']
    url = params['url']

    episodes = FS.get_episode_list(url)

    for ep in episodes['episodes']:
        data = {'title': ep['title'].replace('\t', ''),
                'season': episodes['season']['season'],
                'episode': ep['number'],
                'plot': ep['description'],
                'poster': ep['poster'],
                'banner': ep['banner'],
                'tvshowtitle': ep['serie']['title']
                }

        addLink(f'{data["episode"]}. {data["title"]}',
                      f'{url}|{data["episode"]}', 'FSListLinks',
                      fanart=data['banner'], thumb=data['poster'],
                      subdir=name, data=data,
                      )
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE)


def ListLinks():
    subdir = params['subdir']
    name = params['name']
    url, type = params['url'].split('|')

    if type == 'movie':
        players = FS.get_episode_list(url)['episodes']['players']
    else:
        episode = int(type) - 1
        players = FS.get_episode_list(url)['episodes'][episode]['players']

    player = [p['name'] for p in players]
    playerlink = [l['link'] for l in players]

    SourceSelect(player, playerlink, name, subdir)


def Gatunki():
    tag_list = [tag[0] for tag in FS.tag_by_name]
    tag_code = [code[1] for code in FS.tag_by_name]

    d = xbmcgui.Dialog()
    select = d.multiselect('Wybór Gatunku', tag_list)
    if select == None:
        PageFrixySubs()
        return
    seltags = []
    for idx in select:
        seltags.append(tag_code[idx])
    sep = ','
    url = sep.join(seltags)
    ListTitles(url)


def Studio():
    studio_list = FS.studio_by_name
    for studio in studio_list:
        addDir(studio[0], studio[1], 'FSListTitles',
                     fanart=default_background, section='studio',
                     )

FS = FrixySubs()

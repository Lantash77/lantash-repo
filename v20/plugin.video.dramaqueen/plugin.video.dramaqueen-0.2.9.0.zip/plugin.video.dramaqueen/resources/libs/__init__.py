import xbmcaddon
import xbmcvfs

my_addon = xbmcaddon.Addon()

DATA_PATH = xbmcvfs.translatePath(my_addon.getAddonInfo("profile"))
PATH = my_addon.getAddonInfo('path')
MEDIA = xbmcvfs.translatePath(f'{PATH}media/')
settings = my_addon.getSettings()
GetSetting = my_addon.getSetting
SetSetting = my_addon.setSetting

UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Mobile Safari/537.36 Kodi-19.4-DQ'
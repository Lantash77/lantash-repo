
import sys as _sys

PY2 = _sys.version_info < (3, 0)


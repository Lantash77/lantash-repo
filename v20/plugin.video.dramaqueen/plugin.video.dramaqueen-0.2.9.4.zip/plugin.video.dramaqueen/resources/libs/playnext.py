import sys

import xbmc
import xbmcaddon
from urllib.parse import urlencode
from .. import libs

plugin = libs.my_addon.getAddonInfo('id')
Getsetting = libs.GetSetting
settings = libs.settings


def get_next_ep(data, ep):

    next_ep_data = data
    exclude_list = ['tłumaczeni', 'korekta']

    if any(exclude in data['episodes'][ep]['ep_title'] for exclude in exclude_list):

        return None
    else:
        links = {'ep_title': data['episodes'][ep]['ep_title'],
                 'ep_players': data['episodes'][ep]['players'],
                 'ep_links': data['episodes'][ep]['links'],
                 'episode': data['episodes'][ep]['episode'],
                 'episode_ID': data['episodes'][ep]['episode_ID'],
                 }
        try:
            next_ep = {'next_ep': True,
                       'next_ep_title': data['episodes'][ep + 1]['ep_title'],
                       'next_ep_players': data['episodes'][ep + 1]['players'],
                       'next_ep_links': data['episodes'][ep + 1]['links'],
                       'next_episode': data['episodes'][ep + 1]['episode'],
                       'next_episode_ID': data['episodes'][ep + 1]['episode_ID']
                       }
        except:
            next_ep = {'next_ep': False,
                       'next_ep_title': None,
                       'next_ep_players': None,
                       'next_ep_links': None,
                       'next_episode': None}
        next_ep_data.update(next_ep)
        next_ep_data.update(links)
        return next_ep_data


def next_ep_link(data, title):

    params = {'name': title,
              'mode': 'ListLinks',
              'data': data}
    quote = urlencode(params)
    url = f'{sys.argv[0]}?{quote}'
    return url


def next_ep(data):

    up_next_srv = 'service.upnext'
    if not data['type'] == 'drama':
        return None
    if not xbmc.getCondVisibility(f'System.HasAddon({up_next_srv})'):
        return None
    if not settings.getBool('upnext.on'):
        return None
    up_next_addon = xbmcaddon.Addon(up_next_srv)
    up_next_addon.setSetting('enablePlaylist', 'true')
    up_next_offset = settings.getInt('upnext.offset')

    current_episode = int(data.get('episode')) - 1
    next_data = get_next_ep(data, current_episode)
    next_link_url = next_ep_link(data, next_data.get('next_ep_title'))
    if not next_data.get('next_ep'):
        return None

    next_info = {
        'current_episode': {'episodeid': next_data.get('episode_ID'),
                            'tvshowid': next_data.get('title_ID'),
                            'title': next_data.get('ep_title'),
                            'art': {'thumb': next_data.get('thumb', ''),
                                    'tvshow.clearart': next_data.get('clearart', ''),
                                    'tvshow.clearlogo': next_data.get('clearlogo', ''),
                                    'tvshow.fanart': next_data.get('fanart', ''),
                                    'tvshow.landscape': next_data.get('banner', ''),
                                    'tvshow.poster': next_data.get('poster', ''),
                                    },
                            'season': '1',
                            'episode': next_data.get('episode'),
                            'showtitle': next_data.get('title'),
                            'plot': next_data.get('plot'),
                            'firstaired': next_data.get('year'),
                            'playcount': None,
                            'rating': None,
                            # 'runtime':item_details.runtime,  # NOTE: This is optional
                            },
        'next_episode': {'episodeid': next_data.get('next_episode_ID'),
                         'tvshowid': next_data.get('title_ID'),
                         'title': next_data.get('next_ep_title'),
                         'art': {'thumb': next_data.get('thumb', ''),
                                 'tvshow.clearart': next_data.get('clearart', ''),
                                 'tvshow.clearlogo': next_data.get('clearlogo', ''),
                                 'tvshow.fanart': next_data.get('fanart', ''),
                                 'tvshow.landscape': next_data.get('banner', ''),
                                 'tvshow.poster': next_data.get('poster', ''),
                                 },
                         'season': '1',
                         'episode': next_data.get('next_episode'),
                         'showtitle': next_data.get('title'),
                         'plot': next_data.get('plot'),
                         'firstaired': next_data.get('year'),
                         'playcount': None,
                         'rating': None,
                         # 'runtime':item_details.runtime,  # NOTE: This is optional
                        },
        'play_url': next_link_url,

        #'play_info':{'item_id':next_item_details.id},
        'notification_time': up_next_offset,  # NOTE: This is optional
        #'notification_offset':notification_offset,
    }
    return next_info
﻿from resources.libs import cache

from http.server import BaseHTTPRequestHandler
from socketserver import TCPServer
from urllib.parse import parse_qsl, quote, unquote, urlencode
import re
import xbmcaddon
import xbmc
import socket
from contextlib import closing

addon = xbmcaddon.Addon(id='plugin.video.dramaqueen')

import requests
import urllib3
import hashlib
from ast import literal_eval

requests.packages.urllib3.disable_warnings()
requests.packages.urllib3.util.ssl_.DEFAULT_CIPHERS += ':HIGH:!DH:!aNULL'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36 Edg/97.0.1072.62'

sess = requests.session()

import ssl
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):

    def parseUrl(self, tup):
        url = (self.path).split(tup)[-1]
        if "@" in url:
            urlk, h = url.split('@')
            SimpleHTTPRequestHandler.headers = dict(parse_qsl(h))
        else:
            urlk = url
        return urlk
        
    def do_HEAD(self):
    
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        """Handle http get requests, used for manifest"""
        path = self.path  # Path with parameters received from request e.g. "/manifest?id=234324"
        data = literal_eval(cache.cache_get('ping')['value'])

        if 'tqdrama=' in path:

            proxyport = addon.getSetting('proxyport')
            #proxyport = cache.cache_get('proxyport')['value']
            licurl = self.parseUrl('tqdrama=')

            if 'video.drm' in (self.path):

                result1 = sess.get(url=licurl, headers=data['header'], timeout=30)

                #result = re.sub('(".*?drmkey\?v=\d+")', '"https://github.com/Lantash77/lantash-repo/raw/main/dk"', result1)
                result = re.sub('"(.*?drmkey\?v=\d+)"', rf'"http://127.0.0.1:{proxyport}/tqdramakey=\1"', result1.text)
                #result = re.sub('https://', rf'http://127.0.0.1:{proxyport}/tqdramakey=https://', result1.text)
                #result = result1

                self.do_HEAD()
                result = result.encode(encoding='utf-8', errors='strict')
                self.wfile.write(result)

        if 'tqdramakey=' in path:

            keyurl = self.parseUrl('tqdramakey=')

            if re.search('drmkey\?v=\d+', keyurl):
                if xbmc.Player().isPlaying:
                    time = xbmc.Player().getTime()
                else: time = 0
                status = str(not(xbmc.Player().isPlaying)).lower()


                #print(f'DQ HTTP GET KEY STATUS : {getkey.status_code}')

                query = f'{data["h1"]}_{data["h2"]}_{time:.6f}_{status}_{data["res"]}'
                hashed = hashlib.md5(query.encode())
                params = {'hash': hashed.hexdigest(), 'time': f'{time:.6f}',
                          'paused': status, 'resolution': data["res"]}
                ping = sess.get(data["ping_url"], headers=data['header'], params=params)

            getkey = sess.get(keyurl, headers=data['header'])

            #print(f'DQ ping params  {params} PING: {ping.status_code}')

            self.do_HEAD()
            resp = getkey.content
            self.wfile.write(resp)

    def do_POST(self):
        """Handle http post requests, used for license"""
        path = self.path  # Path with parameters received from request e.g. "/license?id=234324"
        print('HTTP POST Request received to {}'.format(path))

        #print('HTTP POST Request received to {}'.format(path))
        #if '/license' not in path:
        #    self.send_response(404)
        #    self.end_headers()
        #    return
        #
        #length = int(self.headers.get('content-length', 0))
        #isa_data = self.rfile.read(length).decode('utf-8').split('!')
        #challenge = isa_data[0]
        #if 'cense=' in path:
        #    path2 = path.split('cense=')[-1]
        #
        #    licurl=(addon.getSetting('licurl'))
        #
        #    ab=eval(addon.getSetting('hea'))
        #    result = requests.post(url=licurl, headers=ab, data=challenge,verify=False).content
        #    if PY3:
        #        result = result.decode(encoding='utf-8', errors='strict')
        #    licens=re.findall('ontentid=".+?">(.+?)<',result)[0]
        #    if PY3:
        #        licens= licens.encode(encoding='utf-8', errors='strict')
        #elif 'censetv=' in path:
        #    path2 = path.split('censetv=')[-1]
        #
        #    licurl=(addon.getSetting('lictvurl'))
        #
        #    ab=eval(addon.getSetting('heatv'))
        #    result = requests.post(url=licurl, headers=ab, data=challenge,verify=False).json()
        #    licens=result['ServiceResponse']['OutData']['LicenseInfo']
        #    if PY3:
        #
        #        licens= licens.encode(encoding='utf-8', errors='strict')
        #
        #self.send_response(200)
        #self.end_headers()
        #
        #self.wfile.write(licens)

            
def find_free_port():
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        addon.setSetting('proxyport', str(s.getsockname()[1]))
        #cache.cache_insert('proxyport', str(s.getsockname()[1]))
        return s.getsockname()[1]           


address = '127.0.0.1'  # Localhost

port = find_free_port()

server_inst = TCPServer((address, port), SimpleHTTPRequestHandler)
# The follow line is only for test purpose, you have to implement a way to stop the http service!
server_inst.serve_forever()
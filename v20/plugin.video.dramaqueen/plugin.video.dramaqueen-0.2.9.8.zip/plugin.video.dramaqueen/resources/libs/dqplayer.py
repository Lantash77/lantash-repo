import requests
import re
import sys
import xbmc, xbmcaddon, xbmcplugin

from urllib.parse import parse_qsl, urlparse

from . import cache
from .log_utils import log
from .. import libs

sess = requests.session()
Getsetting = libs.GetSetting
UA = libs.UA
plugin = libs.my_addon.getAddonInfo('id')

class player(xbmc.Player):
    """
        Xbmc Player with Callbacks
    """
    def __init__(self):
        xbmc.Player.__init__(self)

    def run(self, item, nextitem=None):
        try:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            self.nextitem = nextitem
            self.keepPlaybackAlive()
        except:
            log('player_fail', 0)
            return

    def keepPlaybackAlive(self):
        xbmc.sleep(4000)
        while self.isPlayingVideo():
            xbmc.sleep(2000)

    def onAVStarted(self):

        log('AV STARTED', 0)
        if self.nextitem:  # check if next episode contains data
            import AddonSignals
            #sending next epizode data to upnext service
            AddonSignals.sendSignal(source_id=plugin,
                                    signal='upnext_data',
                                    data=self.nextitem)

        # from resources.libs.kodiutils import upnext_signal
        # status = upnext_signal(plugin, self.nextitem)
        # if status:
        #    log('SENT NEX EP DATA DONE', 0)

    def onPlayBackPaused(self) -> None:
        log('PAUSED', 0)

    def onPlayBackResumed(self) -> None:
        log('RESUMED', 0)

    def onPlayBackStopped(self):
        log('STOPPED', 0)

    def onPlayBackEnded(self):
        log('ENDED', 0)


def fetch(url):
    id = url.split("/")[-1]
    lib_id = url.split("/")[-2]
    base_url = re.findall('(.+?://.+?/)', url)[0]

    proxyport = cache.cache_get('proxyport')['value']

    # main
    headers = {
        'user-agent': UA,
        'referer': 'https://www.dramaqueen.pl/',
    }

    r = sess.get(url, headers=headers)
    '''temporary not active section
    # activate 
    activate_url = re.findall(';loadUrl\(\"(.+?)\",', r.text)[0].split(";")[-1].replace('loadUrl("', '')
    headers_activate = {
        'user-agent': UA,
        'referer': base_url
    }
    r_activate = sess.get(activate_url, headers=headers_activate)
    # src
    src_url = re.findall('e.loadSource\(\"(.+?)\"\);', r.text)[0]
    '''

    # src
    #src_url = re.findall('e.loadSource\(\"(.+?)\"\);', r.text)[0]
    src_url = re.findall('https.+?m3u8', r.text)[0]

    headers_src = {
        'user-agent': UA,
        'referer': base_url,
    }

    r_src = sess.get(src_url, headers=headers_src)
    res_list = re.findall('.*/video.m3u8?.*', r_src.text)

    if Getsetting('quality') == '0':
        res = res_list[-1]
    elif Getsetting('quality') == '1':
        res = [i for i in res_list if '720' in get_res(i)][0]

    elif Getsetting('quality') == '2':
        res = res_list[0]
    elif Getsetting('quality') == '3':
        import xbmcgui
        d = xbmcgui.Dialog()
        sel_list = [get_res(i) for i in res_list]
        select = d.select('Wybierz jakość', sel_list)
        if select > -1:
           res = res_list[select]
        else: exit()

    stream_netloc = re.findall('(.+?://.+?)/', src_url)[0]
    cached = {'header': headers_src,
              'key_netloc': stream_netloc }
    cache.cache_insert('ping', repr(cached))
    # hls
    strmUrl = re.sub('playlist.m3u8', '', src_url) + res
    strmUrl = f'http://127.0.0.1:{proxyport}/tqdrama={strmUrl}'

    return strmUrl, headers_src

def get_res(link):

    resolutions = re.search('x(.+?)/', link)
    if not resolutions:
        resolutions = re.search('(.+?)p/', link)
    return resolutions.group(1)



# -*- coding: UTF-8 -*-
import sys
import re

from urllib.parse import parse_qs, quote_plus, urlencode, urlparse
from ast import literal_eval

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
#import inputstreamhelper
from functools import reduce
from . import cache
from .. import libs
import resolveurl
from . import dqplayer
from .dqhelper import meta_check
from .helper import *
from . import playnext
from .log_utils import log, log_exc

my_addon = xbmcaddon.Addon()

execute = xbmc.executebuiltin
sysaddon = sys.argv[0]


def setContent(content):
    return xbmcplugin.setContent(int(sys.argv[1]), content)


def is_host_valid(url, domains):
    try:
        elements = urlparse(url)
        domain = elements.netloc or elements.path
        domain = domain.split("@")[-1].split(":")[0]
        pattern = re.compile("(?:www\.)?([\w\-]*\.[\w\-]{2,3}(?:\.[\w\-]{2,3})?)$")
        res = pattern.search(domain)
        if res:
            domain = res.group(1)
        host = domain.lower()
        hosts = [domain.lower() for domain in domains if host and host in domain.lower()]

        if hosts and "." not in host:
            host = hosts[0]
        if hosts and any([h for h in ["google", "picasa", "blogspot"] if h in host]):
            host = "gvideo"
        if hosts and any([h for h in ["akamaized", "ocloud"] if h in host]):
            host = "CDN"
        return any(hosts), host
    except:
        #log_exception()
        return False, ""

def get_hostList():

    hostDict = resolveurl.relevant_resolvers(order_matters=True)
    hostDict = [i.domains for i in hostDict if not "*" in i.domains]
    hostDict = [i.lower() for i in reduce(lambda x, y: x + y, hostDict)]
    hostDict = [x for y, x in enumerate(hostDict) if x not in hostDict[:y]]
    return hostDict


def set_art_dict(f_args):

    art_keys = ['icon', 'thumb', 'fanart',
                'poster', 'banner', 'landscape',
                'clearart', 'clearlogo']
    get_art = f_args.get
    get_from_data = get_art('data', {}).get
    get_from_art = get_from_data('art', {}).get
    art_dict = {key: get_from_data(key) or
                get_from_art(key) or
                get_art(key)
                for key in art_keys}
    return art_dict


def addDir(name, url, mode='', icon='', thumb='', fanart='', poster='',
           code='', studio='', data={}, isFolder=True, total=1):

    art_dict = set_art_dict(locals())
    urlparams = {'url': url, 'name': name, 'mode': mode, 'data': repr(data)}

    u = f'{sysaddon}?{urlencode(urlparams)}'

    liz = xbmcgui.ListItem(name)
    contextmenu = []
    contextmenu.append(('Informacja', 'Action(Info)'))

    #### K21 VTAGS
    v_tag = liz.getVideoInfoTag()
    v_tag.setTitle(name)
    v_tag.setYear(int(data.get('year', 0)))
    v_tag.setPlot(data.get('plot'))
    v_tag.setGenres(data.get('genre', []))  # lista
    if data.get('tvshowtitle'):
        v_tag.setMediaType('tvshow')
        v_tag.setTvShowTitle(name)
        v_tag.setSeason(int(data.get('season', 1)))
        v_tag.setUniqueID(data.get('title_ID'))

    else:
        v_tag.setMediaType('movie')
    '''
    info = {
        'title': name,
        'genre': data.get('genre'),
        'year': data.get('year'),
        'rating': data.get('rating'),
        'dateadded': data.get('dateadded'),
        'plot': data.get('plot'),
        'code': code or data.get('code'),
        'studio': studio or data.get('studio')
    }
    '''
    if data.get('nextpage'):
        liz.setProperty('SpecialSort', 'bottom')
    #liz.setInfo(type='video', infoLabels=info)
    liz.setArt(art_dict)
#    liz.setArt({
#        'thumb': thumb or data.get('thumb'),
#        'icon': icon or data.get('thumb'),
#        'fanart': fanart or data.get('fanart'),
#        'poster': poster or data.get('thumb'),
#        'banner': data.get('banner'),
#        'clearart': data.get('clearart'),
#        'clearlogo': data.get('clearlogo'),
#    })
    liz.addContextMenuItems(contextmenu)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,
                                isFolder=isFolder, totalItems=total)


def addLink(name, url, mode='',
            icon='', thumb='', fanart='', poster='',
            banner='', clearart='', clearlogo='', genre='', year='', data={},
            rating='', dateadded='', plot='', code='', studio='', pic='',
            isFolder=False, total=1, type='video', section='', page='', subdir=''):

    art_dict = set_art_dict(locals())
    urlparams = {'url': url, 'name': name, 'mode': mode,
                 'img': thumb,
                 'fanart': fanart, 'poster': poster,
                 'section': section, 'subdir': subdir, 'page': page,
                 'data': repr(data)
                 }
    u = f'{sysaddon}?{urlencode(urlparams)}'

    liz = xbmcgui.ListItem(name)
    contextmenu = []
    contextmenu.append(('Informacja', 'Action(Info)'))

    #### K21 VTAGS
    v_tag = liz.getVideoInfoTag()
    v_tag.setTitle(name)
    v_tag.setYear(int(data.get('year', 0)))
    v_tag.setPlot(data.get('plot'))
    v_tag.setGenres(data.get('genre', []))  # lista
    if data.get('tvshowtitle'):
        v_tag.setMediaType('episode')
        v_tag.setTvShowTitle(name)
        v_tag.setSeason(int(data.get('season', 1)))
        v_tag.setEpisode(int(data.get('episode')))
        v_tag.setUniqueID(data.get('episode_ID'))
    else:
        v_tag.setMediaType('movie')
        v_tag.setUniqueID(data.get('title_ID'))

    ###
    '''
    info = {
        'title': name,
        'episode': data.get('episode'),
        'season': data.get('season', '1'),
        'genre': genre or data.get('genre'),
        'year': year or data.get('year'),
        'rating': rating or data.get('rating'),
        'dateadded': dateadded or data.get('dateadded'),
        'plot': plot or data.get('plot'),
        'code': code or data.get('code'),
        'studio': studio or data.get('studio'),
        'tvshowtitle': data.get('tvshowtitle'),
        'setid': data.get('episode_ID')
    }
    '''
    liz.setProperty('IsPlayable', 'true')
    #liz.setInfo(type, infoLabels=info)
    liz.setArt(art_dict)
#    liz.setArt({
#        'thumb': thumb,
#        'icon': icon,
#        'fanart': fanart or data.get('fanart'),
#        'poster': poster or data.get('poster'),
#        'banner': banner or data.get('banner'),
#        'clearart': clearart or data.get('clearart'),
#        'clearlogo': clearlogo or data.get('clearlogo'),
#    })
    liz.addContextMenuItems(contextmenu)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,
                                isFolder=isFolder, totalItems=total)


def get_params():
    paramstring = sys.argv[2]
    if paramstring.startswith('?'):
        paramstring = paramstring[1:]
    params = dict((k, vv[0]) for k, vv in parse_qs(paramstring).items())
    if params.get('data'):
        params['data'] = literal_eval(params['data'])
    return params

def PlayFromHost(url,  title, data, mode='play' ,subdir=''):

    play_next = playnext.next_ep(data)
    #DQ Player
    try:
        if 'dqplayer' in url:
            videolink = url.split('|')[1]

            strmUrl, stream_header = dqplayer.fetch(videolink)
            stream_header = urlencode(stream_header)
            log(f'HLS sending to ISA : {strmUrl}')
            PROTOCOL = 'hls'
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper(PROTOCOL)

            if is_helper.check_inputstream() and meta_check(data):
                li = xbmcgui.ListItem(title, path=strmUrl)

                li.setMimeType('application/x-mpegURL')
                li.setContentLookup(False)
                li.setProperty('inputstream', is_helper.inputstream_addon)
                #li.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                # li.setProperty('inputstream.adaptive.license_key', '|' + stream_header)
                li.setProperty('inputstream.adaptive.stream_headers', stream_header)
                li.setProperty('inputstream.adaptive.manifest_headers', stream_header)

                dqplayer.player().run(li, play_next)

#                xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)

        # Send to resolver - no longer valid
        '''
        else:
            import resolveurl
            try:
                stream_url = resolveurl.resolve(url)
                log(f'Wynik z resolver : {stream_url}')
#                xbmc.log('DramaQueen.pl | wynik z resolve  : %s' % stream_url, xbmc.LOGINFO)
                li = xbmcgui.ListItem(title, path=str(stream_url))
                #from resources.libs.player import player
                dqplayer.player().run(li, play_next)
                #xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)
            except:
                log(f'Play Failed : {stream_url}')

                exit()
        '''
    except Exception:
        d = xbmcgui.Dialog()
        d.notification('dramaqueen.pl ',
                       '[COLOR red]Problem  -  Nie można wyciągnąć linku[/COLOR]',
                       xbmcgui.NOTIFICATION_INFO, 5000)
        log_exc()

def SourceSelect(players, links, title, data):

    hostDict = cache.get(get_hostList, 720)
    if len(players) == 1:
        link = links[0]
        PlayFromHost(link, title=title, data=data)

    elif len(players) > 1:
        valid_list = []
        for i in zip(players, links):
            # valid_list.append(i)
            if 'dqplayer|' in i[1]:
                valid_list.append(i)
                continue
            valid, host = is_host_valid(i[1], hostDict)
            if valid:
                valid_list.append(i)
        d = xbmcgui.Dialog()
        select = d.select('Wybór playera', [i[0] for i in valid_list])
        if select > -1:
            link = [i[1] for i in valid_list][select]
            PlayFromHost(link, title=title, data=data)
        else:
            pass
    else:
        xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]', 'Brak linków')


def idle():
    return execute('Dialog.Close(busydialog)')


def openSettings(query=None, id=my_addon.getAddonInfo('id')):
    try:
        idle()
        execute(f'Addon.OpenSettings({id})')
        if query == None: query = '0.0'
        c, f = query.split('.')
        execute(f'SetFocus({int(c) - 100})')
        execute(f'SetFocus({int(f) - 80})')

    except:
        return

def endOfDir():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


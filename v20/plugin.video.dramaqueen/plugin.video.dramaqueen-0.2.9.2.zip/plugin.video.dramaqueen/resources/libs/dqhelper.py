import re
import requests
import platform
import subprocess
import os
import signal
import xbmc
import xbmcgui
import json
from .. import libs
from . import cache
from .helper import *
from .log_utils import log



headersget = {'user-agent': libs.UA}
system = platform.system()
GetSetting = libs.GetSetting
settings = libs.settings


def Logowanie(popup):
    headers = {
        'user-agent': libs.UA,
        'referer': 'https://www.dramaqueen.pl/login/'
    }
    data = {
        'log': settings.getString('user'),
        'pwd': settings.getString('pass'),
        #'no_captcha': 'yes',
        'wp-submit': 'Zaloguj się',
    }
    sess = requests.session()
    GetLogin = sess.post('https://www.dramaqueen.pl/wp-login.php', headers=headers, data=data)
    response = GetLogin.status_code
    kuki = sess.cookies.get_dict()
    cache.cache_insert('dramaqueen_cookie', json.dumps(kuki))
    if response == 200:
        if logged_in(kuki):
            if popup == True:

                dialog = xbmcgui.Dialog()
                dialog.notification('dramaqueen.pl ',
                                    'Zalogowano pomyślnie.',
                                    xbmcgui.NOTIFICATION_INFO, 5000, sound=False)
            else:
                pass
        else:
            dialog = xbmcgui.Dialog()
            cache.cache_clear()
            ret = dialog.yesno('Nie jesteś zalogowany',
                               'Zarejestruj się na dramaqueen.pl \n'
                               'Wprowadź dane logowania w ustawieniach\n'
                               'Otworzyć ustawienia wtyczki?')
            if ret:
                libs.my_addon.openSettings()
                xbmc.executebuiltin('Container.Refresh')
            else:
                exit()
    else:
        d = xbmcgui.Dialog()
        d.notification('dramaqueen.pl ',
                       f'[COLOR red]Problem  -  Błąd serwera - {str(response)}[/COLOR]',
                       xbmcgui.NOTIFICATION_INFO, 5000)

        exit()


def logged_in(cookies):
    ok = 'wordpress_logged_in'
    for key in cookies.keys():
        if ok in key:
            return True
    return False


class process_list():

    def __init__(self):
        if system == 'Windows':
            output = subprocess.check_output(('TASKLIST', '/FO', 'CSV'), shell=True).decode('utf-8', errors='ignore')
            output = output.replace('"', '').split('\r\n')
            self.proc_list = [[i.split(',')[1], i.split(',')[0]] for i in output[1:] if i]
        elif system == 'Linux':
            output = subprocess.check_output(('ps', '-A'), shell=True).decode('utf-8', errors='ignore')
            output = output.replace('"', '').split('\n')
            list = [i.strip().split(' ') for i in output[1:] if i]
            self.proc_list = [[i[0], i[-1]] for i in list if i]

def process_check():
    processes = process_list()
    for proc in processes.proc_list:
        try:
            processName = proc[1]
            processID = proc[0]
            for d in list.keys():
                if d in processName:
                    log(f'found {processName} ::: {processID}', 0)
                    if 'GameBar' in processName:
                        os.kill(int(processID), signal.SIGTERM)  # or signal.SIGKILL
                        continue
                    return list[d]
        except Exception as e:
            print(e)
            continue
    return False


def meta_check(data):

    Logowanie(False)
    cookie = literal_eval(cache.cache_get('dramaqueen_cookie')['value'])
    #headersget.update({'Cookie': cookie})
    check = process_check()
    if check:

        url = 'https://www.dramaqueen.pl/wp-comments-post.php'
        post = {'comment': f'Super drama! obejrzana z włączonym {check}',
                'submit': 'Opublikuj komentarz',
                'comment_post_ID': data['title_ID'],
                'comment_parent': '0'}

        p = requests.post(url, headers=headersget, data=post, cookies=cookie)
        return False
    return True


if platform.system() == 'Windows':
    list = {'vlc.exe': ' VLC',
            'Adobe Premiere': 'Adobe Premiere',
            'GameBar': 'XBOX Gamebar', #kill only
            'obs64.exe': 'OBS-Studio', 'obs32.exe': 'OBS-Studio',
            'FlashBack.exe': 'FlashBack',
            'Recorder.exe': 'CamStudio',
            'bdcam.exe': 'Bandicam',
            'debut.exe': 'Debut Video Capture',
            'TinyTake by MangoApps.exe': 'TinyTake',
            'ApowerREC.exe': 'ApowerREC - Apowersoft',
            'Loom.exe': 'Loom', #Teams like program
            'Ezvid.exe': 'Ezvid',
            'ezvid.exe': 'EZvid',
            'recorder.exe': 'IceCream Screen Recorder', #5min tylko w free ver
            'Screencast-O-Matic.exe': 'Screencast-O-Matic', #only video in free ver
            'msedgewebview2.exe': 'Camtasia',
            'freecam.exe': 'Free Cam',
            'Action.exe': 'Mirillis Action!',
            'Aiseesoft Screen Recorder.exe': 'Aiseesoft Screen Recorder', #paid
            'Apeaksoft Screen Recorder.exe': 'Apeaksoft Screen Recorder', #paid
            'Apowersoft Screen Recorder.exe': 'Apowersoft Screen Recorder Pro', #paid
            'TuneFab Screen Recorder.exe': 'TuneFab Screen Recorder', #paid
            'Captura.exe': 'Captura',
            'ChrisPCScreenRec.exe': 'ChrisPC Screen Recorder',
            'ScreenRecorder.exe': 'CyberLink Screen Recorder',
            'd3dGear.exe': 'D3DGear',
            'Dxtory.exe': 'Dxtory',
            'FFsplit.exe': 'FFsplit',
            'BBPlayFx.exe': 'FBX Game Recorder',
            'fraps.exe': 'Fraps',
            'GOMCam.exe': 'GOM Cam',
            'coolcut.exe': 'GoPlay Editor',
            'Gregion.exe': 'Gregion',
            'liteCAM.exe': 'liteCAM',
            'LoiLoGameRecorder.exe': 'LoiLo Game Recorder',
            'Gecata.exe': 'Gecata by Movavi',
            'My Screen Recorder.exe': 'My Screen Recorder',
            'oCam.exe': 'oCam',
            'PlayClaw': 'PlayClaw',
            'RECORDzilla.exe': 'RECORDzilla',
            'NSR.exe': 'Rylstim Screen Recorder',
            'smartpixel.exe': 'SmartPixel',
            'Streamlabs OBS.exe': 'Streamlabs OBS',
            'SnagitCapture.exe': 'Snagit',
            'vrec.exe': 'Video Detailer',
            'ScreenCapturerApp.exe': 'VidShot Capturer',
            'WinCam.exe': 'WinCam',
            'FSRecorder.exe': 'Wondershare Filmora Scrn',
            'Gamecaster.exe': 'XSplit Gamecaster',
            'ScnRec.exe': 'ZD Soft Screen Recorder',
            'vokoscreenNG.exe': 'vokoscreenNG',
            'screenrec.exe': ''
            }
elif platform.system() == 'Linux':
    list = {'vlc': ' VLC',
            'obs': 'OBS Studio',
            'simplescreenrecorder': 'SimpleScreenRecorder',
            'vokoscreenNG': 'vokoscreenNG',
            'kazam': 'Kazam',
            'screenstudio': 'ScreenStudio',
            'recordmydesktop': 'recordmydesktop',
            'byzant': 'Byzant',
            'screenrec': 'ScreenRec',
            }



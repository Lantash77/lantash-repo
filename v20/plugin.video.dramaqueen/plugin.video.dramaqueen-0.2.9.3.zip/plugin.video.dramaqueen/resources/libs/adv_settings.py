import os
import xml.etree.ElementTree as ET
import xbmcvfs
import xbmc
import xbmcgui


ADSFNAME = "advancedsettings.xml"
adv_settings_path = xbmcvfs.translatePath("special://userdata")
adv_settings_file = os.path.join(adv_settings_path, ADSFNAME)

def indent(elem, level=0):
    i = "\n" + level * "  "
    j = "\n" + (level - 1) * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for subelem in elem:
            indent(subelem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = j
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = j
    return elem

def _backup_file():

    fpathbak = f'{adv_settings_file}.bak'
    if xbmcvfs.exists(fpathbak):
        xbmcvfs.delete(fpathbak)
    return xbmcvfs.copy(adv_settings_file, fpathbak)

def closeKodi():
    choice = xbmcgui.Dialog().ok(
        "DramaQueen Informacja", "Aby umożliwić korzystanie z DQPlayer\n"
                                 "Zmodyfikowano plik advancedsettings\n"
                                 "Teraz Kodi zostanie zamknięte aby zatwierdzić zmiany"
    )
    if choice == 1:
        os._exit(1)
    else:
        xbmc.executebuiltin("Action(Close)")
    pass

def check_advanced_settings():

    if os.path.exists(adv_settings_file):
        adv_set_xml = ET.parse(adv_settings_file)
        root = adv_set_xml.getroot()
        network = root.find('network')
        if network:
            http2 = network.find('disablehttp2')
            if http2 is not None:
                http2_status = http2.text
                if http2_status == 'true':
                    return
                else:
                    _backup_file()
                    http2.text = 'true'
            else:
                _backup_file()
                dis_http2_tag = ET.SubElement(network, 'disablehttp2')
                dis_http2_tag.text = 'true'
        else:
            _backup_file()
            network_tag = ET.SubElement(root, 'network')
            dis_http2_tag = ET.SubElement(network_tag, 'disablehttp2')
            dis_http2_tag.text = 'true'
    else:
        root = ET.Element('advancedsettings')
        network_tag = ET.SubElement(root, 'network')
        dis_http2_tag = ET.SubElement(network_tag, 'disablehttp2')
        dis_http2_tag.text = 'true'

    adv_set_xml_new = ET.ElementTree(indent(root))
    adv_set_xml_new.write(adv_settings_file, encoding='utf-8')
    closeKodi()


import re
import json
import xbmc, xbmcaddon
import base64
from ast import literal_eval
from .log_utils import log
#execute = xbmc.executebuiltin
#my_addon = xbmcaddon.Addon()
#plugin = my_addon.getAddonInfo('id')

def metadataClean(metadata):
    if not metadata: return metadata
    allowed = ['genre', 'country', 'year', 'episode', 'season', 'sortepisode', 'sortseason', 'episodeguide',
               'showlink', 'top250', 'setid', 'tracknumber', 'rating', 'userrating', 'watched', 'playcount',
               'overlay', 'cast', 'castandrole', 'director', 'mpaa', 'plot', 'plotoutline', 'title',
               'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer', 'tvshowtitle',
               'premiered', 'status', 'set', 'setoverview', 'tag', 'imdbnumber', 'code', 'aired', 'credits',
               'lastplayed', 'album', 'artist', 'votes', 'path', 'trailer', 'dateadded', 'mediatype', 'dbid']
    return {k: v for k, v in metadata.items() if k in allowed}

def CleanHTML(html):
    if '&amp;' in html:
        html = html.replace('&amp;', '&')
    if '&quot;' in html:
        html = html.replace('&quot;', '"')
    if '&nbsp;' in html:
        html = html.replace('&nbsp;', '')
    if '&hellip;' in html:
        html = html.replace('&hellip;', '…')
    if '&#8211;' in html:
        html = html.replace('&#8211;', '-')
    if '&#8216;' in html:
        html = html.replace('&#8216;', "'")
    if '&#8217;' in html:
        html = html.replace('&#8217;', "'")
    if '&#8220;' in html:
        html = html.replace('&#8220;', '"')
    if '&#8221;' in html:
        html = html.replace('&#8221;', '"')
    if '&#0421;' in html:
        html = html.replace('&#0421;', "")
    if '&#038;' in html:
        html = html.replace('&#038;', '&')
    if '&#8230;' in html:
        html = html.replace('&#8230;', '…')
    if '<br />\n' in html:
        html = html.replace('<br />\n', ' ')
    if u'\u2019' in html:
        html = html.replace(u'\u2019', '\'')
    if u'\u2661' in html:
        html = html.replace(u'\u2661', ' ')
    if u'\u222c' in html:
        html = html.replace(u'\u222c', ' ')

    return html


def decrypt(hashed):
    return base64.b64decode(hashed.encode('ascii')).decode('ascii')


####################################################################
#  ParseDOM
####################################################################
def _getDOMContent(html, name, match, ret):  # Cleanup

    endstr = f'</{name}'  # + '>'
    start = html.find(match)
    end = html.find(endstr, start)
    pos = html.find('<' + name, start + 1)

    while pos < end and pos != -1:  # Ignore too early </endstr> return
        tend = html.find(endstr, end + len(endstr))
        if tend != -1:
            end = tend
        pos = html.find("<" + name, pos + 1)
    if (start == -1) and (end == -1):
        result = ""
    elif start > -1 and end > -1:
        result = html[start + len(match):end]
    elif end > -1:
        result = html[:end]
    elif start > -1:
        result = html[start + len(match):]
    if ret:
        endstr = html[end:html.find(">", html.find(endstr)) + 1]
        result = match + result + endstr
    return result


def _getDOMAttributes(match, name, ret):

    lst = re.compile(f'''<{name}.*?{ret}=([\'"].[^>]*?[\'"])>''', re.M | re.S).findall(match)
    #lst = re.compile('<' + name + '.*?' + ret + '=([\'"].[^>]*?[\'"])>', re.M | re.S).findall(match)
    if len(lst) == 0:
        lst = re.compile(f'''<{name}.*?{ret}=(.[^>]*?)>''', re.M | re.S).findall(match)
        #lst = re.compile('<' + name + '.*?' + ret + '=(.[^>]*?)>', re.M | re.S).findall(match)
    ret = []
    for tmp in lst:
        cont_char = tmp[0]
        if cont_char in "'\"":
            #log(f'Using {cont_char} as quotation mark')
            # Limit down to next variable.
            if tmp.find('=' + cont_char, tmp.find(cont_char, 1)) > -1:
                tmp = tmp[:tmp.find('=' + cont_char, tmp.find(cont_char, 1))]

            # Limit to the last quotation mark
            if tmp.rfind(cont_char, 1) > -1:
                tmp = tmp[1:tmp.rfind(cont_char)]
        else:
            if tmp.find(" ") > 0:
                tmp = tmp[:tmp.find(" ")]
            elif tmp.find("/") > 0:
                tmp = tmp[:tmp.find("/")]
            elif tmp.find(">") > 0:
                tmp = tmp[:tmp.find(">")]
        ret.append(tmp.strip())
    return ret


def _getDOMElements(item, name, attrs):

    lst = []
    for key in attrs:
        lst2 = re.compile(f'''(<{name}[^>]*?(?:{key}=[\'"]{attrs[key]}[\'"].*?>))''', re.M | re.S).findall(item)
        #lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=[\'"]' + attrs[key] + '[\'"].*?>))', re.M | re.S).findall(item)

        if len(lst2) == 0 and attrs[key].find(" ") == -1:  # Try matching without quotation marks
            lst2 = re.compile(f'''(<{name}[^>]*?(?:{key}={attrs[key]}.*?>))''', re.M | re.S).findall(item)
            #lst2 = re.compile('(<' + name + '[^>]*?(?:' + key + '=' + attrs[key] + '.*?>))', re.M | re.S).findall(item)

        if len(lst) == 0:
            lst = lst2
            lst2 = []
        else:
            test = list(range(len(lst)))
            test.reverse()
            for i in test:  # Delete anything missing from the next list.
                if not lst[i] in lst2:
                    del(lst[i])

    if len(lst) == 0 and attrs == {}:
       # lst = re.compile('(<' + name + '>)', re.M | re.S).findall(item)
        lst = re.compile(f'''(<{name}>)''', re.M | re.S).findall(item)
        if len(lst) == 0:
            #lst = re.compile('(<' + name + ' .*?>)', re.M | re.S).findall(item)
            lst = re.compile(f'''(<{name} .*?>)''', re.M | re.S).findall(item)
    return lst

def parseDOM(html, name="", attrs={}, ret=False):
    """
        parseDOM module:
        parseDOM(self, html, name = "", attrs = {}, ret = False)
        :param html: (string or list) - String to parse, or list of strings to parse.
        :param name: (string) - Element to match ( for instance "span" )
        :param attrs: (dict or str) - Dictionary with attributes you want matched in the element.
                    ex { "id": "span3", "class": "oneclass.*anotherclass", "attribute": "a random tag" }
                                    - attribute only allowed as string
                    ex { "id", "attribute": "a random tag" }
        :param ret: (string or False) - Attribute in element to return value of. If not set(or False), returns content of DOM element.

        :return: list
        """
    if isinstance(name, str):
        try:
            name = name
        except:
            log(f"Couldn't decode name binary string: {repr(name)}", 0)

    if isinstance(html, str):
        html = [html]
    elif not isinstance(html, list):
        log("Input isn't list or string/unicode.", 0)
        return ""
    if not name.strip():
        log("Missing tag name", 0)
        return ""
    if isinstance(attrs, str):
        attrs = {attrs: ""}
    if isinstance(attrs, list):
        attrs = dict((atr, "") for atr in attrs)
    ret_lst = []
    for item in html:
        temp_item = re.compile('(<[^>]*?\n[^>]*?>)').findall(item)
        for match in temp_item:
            item = item.replace(match, match.replace("\n", " "))
        lst = _getDOMElements(item, name, attrs)

        if isinstance(ret, str):
            lst2 = []
            for match in lst:
                lst2 += _getDOMAttributes(match, name, ret)
            lst = lst2
        else:
            lst2 = []
            for match in lst:
                temp = _getDOMContent(item, name, match, ret).strip()
                item = item[item.find(temp, item.find(match)) + len(temp):]
                lst2.append(temp)
            lst = lst2
        ret_lst += lst
    return ret_lst


def extractJS(data, function=False, variable=False, match=False, evaluate=False, values=False):

    scripts = parseDOM(data, "script")
    if len(scripts) == 0:
        #log("Couldn't find any script tags. Assuming javascript file was given.")
        scripts = [data]

    lst = []
    #log("Extracting")
    for script in scripts:
        tmp_lst = []
        if function:
            tmp_lst = re.compile(function + '\(.*?\).*?;', re.M | re.S).findall(script)
        elif variable:
            tmp_lst = re.compile(variable + '[ ]+=.*?;', re.M | re.S).findall(script)
        else:
            tmp_lst = [script]
        if len(tmp_lst) > 0:
            #log(f"Found: {repr(tmp_lst)}")
            lst += tmp_lst
        else:
            pass
            #log(f"Found nothing on: {script}")

    test = list(range(0, len(lst)))
    test.reverse()
    for i in test:
        if match and lst[i].find(match) == -1:
            #log(f"Removing item: {repr(lst[i])}")
            del lst[i]
        else:
            #log(f"Cleaning item: {repr(lst[i])}")
            if lst[i][0] == "\n":
                lst[i] == lst[i][1:]
            if lst[i][len(lst) - 1] == "\n":
                lst[i] == lst[i][:len(lst) - 2]
            lst[i] = lst[i].strip()

    if values or evaluate:
        for i in range(0, len(lst)):
            #log(f"Getting values {lst[i]}")
            if function:
                if evaluate: # include the ( ) for evaluation
                    data = re.compile("(\(.*?\))", re.M | re.S).findall(lst[i])
                else:
                    data = re.compile("\((.*?)\)", re.M | re.S).findall(lst[i])
            elif variable:
                tlst = re.compile(variable +".*?=.*?;", re.M | re.S).findall(lst[i])
                data = []
                for tmp in tlst:
                    # This breaks for some stuff. "ad_tag": "http://ad-emea.doubleclick.net/N4061/pfadx/com.ytpwatch.entertainment/main_563326''
                    # ends early, must end with }
                    cont_char = tmp[0]
                    cont_char = tmp[tmp.find("=") + 1:].strip()
                    cont_char = cont_char[0]
                    if cont_char in "'\"":
                        #log(f"Using {cont_char} as quotation mark")
                        tmp = tmp[tmp.find(cont_char) + 1:tmp.rfind(cont_char)]
                    else:
                        #log("No quotation mark found")
                        tmp = tmp[tmp.find("=") + 1: tmp.rfind(";")]

                    tmp = tmp.strip()
                    if len(tmp) > 0:
                        data.append(tmp)
            else:
                pass
                #log("ERROR: Don't know what to extract values from")

            #log(f"Values extracted: {repr(data)}")
            if len(data) > 0:
                lst[i] = data[0]
    if evaluate:
        for i in range(0, len(lst)):
            #log(f"Evaluating {lst[i]}")
            data = lst[i].strip()
            try:
                try:
                    lst[i] = json.loads(data)
                except:
                    #log("Couldn't json.loads, trying eval")
                    lst[i] = eval(data)
            except:
                #log(f"Couldn't eval: {repr(data)} from {repr(lst[i])}")
                pass

    #log(f"Done: {str(len(lst))}")
    return lst

'''
def log(description, level=1):
    #loglevel == -1 (NONE, nothing at all is logged to the log)
    #loglevel == 0 (NORMAL, shows LOGINFO, LOGWARNING, LOGERROR and LOGFATAL) - Default kodi behaviour
    #loglevel == 1 (DEBUG, shows all) - Behaviour if you toggle debug log in the GUI

    if (level == 'LOGINFO') or (level == 0): level = xbmc.LOGINFO
    elif level == 'LOGWARNING': level = xbmc.LOGWARNING
    elif level == 'LOGERROR': level = xbmc.LOGERROR
    elif level == 'LOGFATAL': level = xbmc.LOGFATAL
    elif level == 'LOGDEBUG': level = xbmc.LOGDEBUG

    try:
        xbmc.log(f'[{plugin}] : {description}', level)
        #print(f'[{plugin}] : {description}')
    except:
        xbmc.log(f"[{plugin}] : {repr(description)}", level)
        #print(f'[{plugin}] : {repr(description)}')
'''
# -*- coding: UTF-8 -*-
#####Python3.12
import os
import re
import sys
import xbmcaddon
import xbmcvfs
import xbmcplugin
import xbmcgui
import json
import requests
import time
from urllib.parse import parse_qs, urlencode
from ast import literal_eval
from typing import NamedTuple

# intro
my_addon = xbmcaddon.Addon()
my_addon_id = my_addon.getAddonInfo('id')
addonhandle = int(sys.argv[1])
sysaddon = sys.argv[0]
DATA_PATH = xbmcvfs.translatePath(my_addon.getAddonInfo("profile"))

MEDIA = xbmcvfs.translatePath(f'{my_addon.getAddonInfo('path')}resources/media/')
BASE_URL = 'https://open.fm/api/'
podcast_BASE_URL = f'https://open.fm/_next/data/{{}}/'

#media
musicicon = MEDIA + 'music.png'
radioicon = MEDIA + 'radio.png'
podcasticon = MEDIA + 'podcast.png'
background = MEDIA + 'background.jpg'


class ApiResponse(NamedTuple):
    #: Stations List
    stations: dict
    #: Podcasts List
    podcast: dict
    #: builtID
    builtID: str


def getJson():
    # Check for cache file existence...
    if not xbmcvfs.exists(DATA_PATH):
        xbmcvfs.mkdirs(DATA_PATH)
    cached_json = os.path.join(DATA_PATH, 'openfm.json')

    if not os.path.exists(cached_json) or time.time() - os.path.getmtime(cached_json) > 3600:

        # dane
        url = f'{BASE_URL}radio/stations'
        url_pdcst = f'https://open.fm/podcasty'

        # Download and store...
        music_stations = requests.get(url).json()
        podcast_web = requests.get(url_pdcst).text
        podcast_web = re.findall(r'"application/json">(.+?)<', podcast_web, re.DOTALL)[0]
        podcast_web = json.loads(podcast_web)
        podcast_categories = podcast_web.get('props')
        podcast_categories = podcast_categories.get('pageProps', {}).get('categories', [])
        buildID = podcast_web.get('buildId')
        openFM = {'music': music_stations, 'podcast': podcast_categories, 'buildID': buildID}
        contents = json.dumps(openFM)
        f = xbmcvfs.File(cached_json, 'w')
        f.write(contents)
        f.close()
    else:
        f = xbmcvfs.File(cached_json)
        data = f.read()
        openFM = json.loads(data)
        f.close()

    return ApiResponse(stations=openFM.get('music'),
                       podcast=openFM.get('podcast'),
                       builtID=openFM.get('buildID'))


def getStreamUrl(url: str) -> str:
    """
    Fetches the stream URL for a given input URL by making an API request with token.

    """
    TOKEN_URL = 'https://open.fm/api/user/token?fp='
    return requests.get(f'{TOKEN_URL}{url}').json().get('url')


def stacje():


    json_data = getJson().stations
    stations = [i for i in json_data.values() if i['contentType'] == params['mode']]
    playlists = requests.get('https://open.fm/api/radio/playlist').json()

    for station in stations:
        name = station['name']
        li = xbmcgui.ListItem(name)
        a_tag = li.getMusicInfoTag()
        a_tag.setTitle(name)
        a_tag.setComment(str(station['id']))
        li.setArt({
            'icon': station['logoUrl'],
            'thumb': station['logoUrl']
        })

        urlparams = {
            'mode': 'playitem',
            'url': station['streamUrl'],
            'name': name,
        }

        url  = f'{sysaddon}?{urlencode(urlparams)}'
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(addonhandle, url, li, isFolder=False)
    xbmcplugin.setContent(addonhandle, 'songs')


def kategorie():

    # Categories...

    kategorie = {
        'MUSIC': ['Muzyka', musicicon],
        'RADIO': ['Radio', radioicon],
        'PODCAST': ['Podcasty', podcasticon],
    }
    # MUSIC, RADIO, PODCAST #
    for kategoria, label in kategorie.items():
        li = xbmcgui.ListItem(label[0])
        urlparams = {'mode': kategoria,
                     'name': label[0]}

        li.setArt({
            'icon': label[1],
            'thumb': label[1],
            'poster': label[1],
            'fanars': background,
        })
        url = f'{sysaddon}?{urlencode(urlparams)}'

        xbmcplugin.addDirectoryItem(addonhandle, url, li, True)
    xbmcplugin.setContent(addonhandle, 'albums')

def podcast_categories():
    json_data = getJson().podcast
    for category in json_data:
        title = category['name']
        urlparams = {
            'mode': 'podcast_list',
            'slug': category['slug'],
            'name': title,
        }
        li.setArt({
            'icon': podcasticon,
            'thumb': podcasticon,
            'poster': podcasticon,
            'fanarst': background,
        })
        li = xbmcgui.ListItem(title)
        url = f'{sysaddon}?{urlencode(urlparams)}'
        xbmcplugin.addDirectoryItem(addonhandle, url, li, isFolder=True)
    xbmcplugin.setContent(addonhandle, 'albums')


def podcast_list():

    api_url = f'{podcast_BASE_URL.format(getJson().builtID)}podcasty/kategoria/{{}}.json'
    json_data = requests.get(api_url.format(params['slug'])).json()
    podcasts_list = json_data.get('pageProps', {}).get('fallbackData', {}).get('podcasts', {}).get('content', [])
    for podcast in podcasts_list:
        title = podcast['title']
        urlparams = {
            'mode': 'podcast_episodes',
            'slug': podcast['slug'],
            'name': title,
            'pid': podcast['id'],
        }
        image = podcast['imageUrl']
        li = xbmcgui.ListItem(title)
        a_tag = li.getMusicInfoTag()
        a_tag.setTitle(title)
        url = f'{sysaddon}?{urlencode(urlparams)}'
        li.setArt({
            'icon':  image,
            'thumb': image,
            'poster': image,
            'fanart': background,
        })
        xbmcplugin.addDirectoryItem(addonhandle, url, li, isFolder=True)
    xbmcplugin.setContent(addonhandle, 'albums')


def podcast_episodes():
    page = params.get('page', 1)
    amount = 40
    api_url = f'{BASE_URL}podcast/{{}}/episodes?page={{}}&size={amount}'
    json_data = requests.get(api_url.format(params['pid'], page)).json()
    episodes = json_data.get('content', [])

    episodes_pages = json_data.get('pagination', [])
    for episode in episodes:
        title = episode['title']
        contextmenu = []
        li = xbmcgui.ListItem(title)

        a_tag = li.getMusicInfoTag()
        a_tag.setTitle(title)
        a_tag.setComment(episode['description'])
        a_tag.setDuration(episode['duration'])
        urlparams = {
            'mode': 'playitem',
            'url': episode.get('files', {}).get('HLS'),
            'name': title,
        }
        url = f'{sysaddon}?{urlencode(urlparams)}'
        li.setArt({
            'icon': episode['cover'],
            'thumb': episode['cover'],
            'poster': episode['cover'],
            'fanart': background,
        })
        li.addContextMenuItems(contextmenu)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(addonhandle, url, li, isFolder=False)

    if len(episodes) == amount and (len(episodes * page)) <= episodes_pages.get('totalElements', 0):
        li = xbmcgui.ListItem('Następna strona')
        urlparams = {
            'mode': 'podcast_episodes',
            'page': int(page) + 1,
            'pid': params['pid'],
        }
        url = f'{sysaddon}?{urlencode(urlparams)}'

        li.setProperty('SpecialSort', 'bottom')
        xbmcplugin.addDirectoryItem(addonhandle, url, li, isFolder=True)
    xbmcplugin.setContent(addonhandle, 'songs')


def playitem():

    playurl = getStreamUrl(params['url'])
    liz = xbmcgui.ListItem(params['name'], path=playurl)
    xbmcplugin.setResolvedUrl(addonhandle, True, liz)


def get_params():
    paramstring = sys.argv[2]
    if paramstring.startswith('?'):
        paramstring = paramstring[1:]
    params = dict((k, vv[0]) for k, vv in parse_qs(paramstring).items())
    if params.get('data'):
        params['data'] = literal_eval(params['data'])
    return params


params = get_params()
mode = params.get('mode')

if mode is None:
    kategorie()
elif mode == 'MUSIC' or mode == 'RADIO':
    stacje()
elif mode == 'PODCAST':
    podcast_categories()
elif mode == 'playitem':

    playitem()
elif mode == 'podcast_list':
    podcast_list()
elif mode == 'podcast_episodes':
    podcast_episodes()

xbmcplugin.addSortMethod(handle=addonhandle, sortMethod=xbmcplugin.SORT_METHOD_NONE)
xbmcplugin.addSortMethod(handle=addonhandle, sortMethod=xbmcplugin.SORT_METHOD_TITLE)
xbmcplugin.endOfDirectory(handle=addonhandle, succeeded=True)

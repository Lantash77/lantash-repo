import requests
import re
import sys
import xbmc, xbmcaddon
my_addon = xbmcaddon.Addon()

from urllib.parse import parse_qsl, urlparse

from resources.libs import cache
from resources import libs
sess = requests.session()

Getsetting = libs.GetSetting
UA = libs.UA

def fetch(url):
    id = url.split("/")[-1]
    lib_id = url.split("/")[-2]
    base_url = re.findall('(.+?://.+?/)', url)[0]

    # main
    headers = {
        'user-agent': UA,
        'referer': 'https://www.dramaqueen.pl/',
    }

    r = sess.get(url, headers=headers)

    # activate
    activate_url = re.findall(';loadUrl\(\"(.+?)\",', r.text)[0].split(";")[-1].replace('loadUrl("', '')
    headers_activate = {
        'user-agent': UA,
        'referer': base_url
    }

    r_activate = sess.get(activate_url, headers=headers_activate)
    # src
    src_url = re.findall('e.loadSource\(\"(.+?)\"\);', r.text)[0]
    headers_src = {
        'user-agent': UA,
        'referer': url,
    }

    r_src = sess.get(src_url, headers=headers_src)
    res_list = re.findall('.*/video.drm?.*', r_src.text)

    if Getsetting('quality') == '0':
        res = res_list[-1]
    elif Getsetting('quality') == '1':
        res = [i for i in res_list if '720' in get_res(i)][0]

    elif Getsetting('quality') == '2':
        res = res_list[0]
    elif Getsetting('quality') == '3':
        import xbmcgui
        d = xbmcgui.Dialog()
        sel_list = [get_res(i) for i in res_list]
        select = d.select('Wybierz jakość', sel_list)
        if select > -1:
           res = res_list[select]
        else: exit()

    hash_data = dict(parse_qsl(urlparse(src_url).query))

    cached = {'h1': hash_data['secret'], 'h2': hash_data['contextId'],
              'ping_url': activate_url.replace('/activate', '/ping?'),
              'res': get_res(res), 'header': headers_src}
    cache.cache_insert('ping', repr(cached))

    # hls
    strmUrl = base_url + id + '/' + res

    return strmUrl, headers_src

def get_res(link):

    return re.findall('x(.+?)/', link)[0]



# -*- coding: UTF-8 -*-
#####Python3.8

import os
import time
import requests
from resources import libs
from resources.libs.helper import *
from resources.libs.addon_tools import *
from resources.libs import cache

# from resources.libs import dqscraper

DATA_PATH = libs.DATA_PATH
GetSetting = libs.GetSetting
MEDIA = libs.MEDIA
COOKIE = 'fdrama_cookie'
searchFile = os.path.join(DATA_PATH, "search.db")
LETTERS = MEDIA + 'letters/'
BASE_LINK = f'https://fajnadrama.pl/tv-shows-2/?orderby=title-asc&filter_tag={{}}&query_type_tag=or'
GENRE_URL = f'https://fajnadrama.pl/tv-shows-2/?orderby=title-asc&filter_genre={{}}'
LETTER_URL = f'https://fajnadrama.pl/tv-shows-2/?letter_filter={{}}'

SEARCH_URL = f'https://fajnadrama.pl/?s={{}}&post_type=tv_show'
sess = requests.session()

headersget = {'user-agent': libs.UA}

############################################################################################################
############################################################################################################
#                                                   MEDIA                                                  #
############################################################################################################

default_background = MEDIA + 'fajnadramabkg.jpg'
default_icon = MEDIA + 'ikonadrama.png'
search_icon = MEDIA + 'search.png'
nexticon = MEDIA + 'next.png'
iconsettings = MEDIA + 'settings.png'


############################################################################################################
############################################################################################################
#                                                   MENU                                                   #
############################################################################################################

def MainMenu():
    addDir('Dramy', BASE_LINK.format('drama'), 'ListTitles',
           fanart=default_background, thumb=default_icon)
    addDir('Filmy', BASE_LINK.format('film'), 'ListTitles',
           fanart=default_background, thumb=default_icon)
    addDir('Anime', BASE_LINK.format('anime'), 'ListTitles',
           fanart=default_background, thumb=default_icon)
    addDir('Spis Alfabetyczny', '', 'Alfabetycznie',
           fanart=default_background, thumb=default_icon)
    addDir('Gatunki', 'https://fajnadrama.pl/tv-shows-2/', 'Gatunki',
           fanart=default_background, thumb=search_icon)
    addDir("Wyszukiwanie", '', 'search',
           fanart=default_background, thumb=search_icon)
    ###Ustawienia###
    addDir('Ustawienia', '', 'settings',
           fanart=default_background, thumb=iconsettings)
    endOfDir()


############################################################################################################
# =##########################################################################################################
#                                                 FUNCTIONS                                                #
# =##########################################################################################################

def Logowanie(popup=False):
    headers = {'user-agent': libs.UA}
    data = {
        'log': GetSetting('user'),
        'pwd': GetSetting('pass'),
        'rememberme': 'forever',
        'wp-submit:': 'Zaloguj się',
        'redirect_to': 'https://fajnadrama.pl/home/',
    }

    GetLogin = sess.post('https://fajnadrama.pl/wp-login.php', headers=headers, data=data)
    response = GetLogin.status_code
    GetLogin = GetLogin.text
    kuki = sess.cookies.get_dict()
    cookie = "; ".join([f'{k}={v}' for k, v in kuki.items()])
    cache.cache_insert(COOKIE, cookie)

    ###LoginCheck - server error handling

    if response == 200:
        if len(re.findall('Witaj, ', GetLogin, re.IGNORECASE)) == 1:
            if popup == True:

                dialog = xbmcgui.Dialog()
                dialog.notification('fajnadrama.pl ', 'Zalogowano pomyślnie.', xbmcgui.NOTIFICATION_INFO, 5000,
                                    sound=False)
            else:
                pass
        else:
            dialog = xbmcgui.Dialog()
            ret = dialog.yesno('Nie jesteś zalogowany',
                               'Zarejestruj się na fajnadrama.pl. \nWprowadź dane logowania w ustawieniach wtyczki',
                               'Wyjdź', 'Ustawienia')
            if ret:
                libs.my_addon.openSettings()
                xbmc.executebuiltin('Container.Refresh')
    else:
        d = xbmcgui.Dialog()
        d.notification('fajnadrama.pl ',
                       '[COLOR red]%s[/COLOR]' % ('Problem  -  Błąd serwera -' + str(response)),
                       xbmcgui.NOTIFICATION_INFO, 5000)
        exit()


def LoginCheck(url):
    if len(re.findall('Witaj,', url, re.IGNORECASE)) == 0:
        xbmcgui.Dialog().ok('Blad logowania', 'Zaloguj się')
        exit()


def Kategorie():
    url = params['url']
    res = cache.get(fetch_page, 720, url)
    tagbox = parseDOM(res, 'div', {'id': 'masvideos .+?'})[0]
    tags = parseDOM(tagbox, 'a')
    tag_ids = [i.partition('_genre=')[2] for i in parseDOM(tagbox, 'a', ret='href')]

    d = xbmcgui.Dialog()
    select = d.multiselect('Wybór Gatunku', tags)
    if select == None:
        MainMenu()
        return
    seltags = []
    for idx in select:
        seltags.append(tag_ids[idx])
    sep = ','
    url = GENRE_URL.format(sep.join(seltags))
    ListTitles(url)


def get_cookie():
    now = int(time.time())
    exp = 1209600  # 14 days cookie valid
    cached_cookie = cache.cache_get(COOKIE)
    if cached_cookie:
        if now - cached_cookie['date'] > exp:
            Logowanie()
            return cache.cache_get(COOKIE)['value']
        return cached_cookie['value']
    else:
        Logowanie(True)
        return cache.cache_get(COOKIE)['value']


def fetch_page(url):
    headersget.update({'Cookie': get_cookie()})
    return requests.get(url, headers=headersget, timeout=10).text


def ListTitles(url=''):
    if not url:
        url = params['url']
    try:
        res = cache.get(fetch_page, 48, url)
        titlebox = parseDOM(res, 'div', {'class': 'tv-shows__inner'})[0].replace("\r", "").replace("\n", "")
        titlebox = CleanHTML(titlebox)
        titles = [f'drama|{i}' for i in
                  re.findall('tv_show_tag-drama(.+?)</div></div></div>', titlebox)]
        titles_movies = [f'movie|{i}' for i in
                         re.findall('tv_show_tag-film(.+?)</div></div></div>', titlebox)]
        titles.extend(titles_movies)
        try:
            nextpage = parseDOM(res, 'a', {'class': 'next .+?'}, ret='href')[0].replace('&#038;', '&')
        except IndexError:
            nextpage = False

        for title in titles:
            data = {'type': title.split('|')[0],
                    'link': parseDOM(title.split('|')[1], 'a', ret='href')[0],
                    'title': parseDOM(title.split('|')[1], 'h3')[0],
                    'poster': parseDOM(title.split('|')[1], 'img', ret='src')[0],
                    'genre': parseDOM(title.split('|')[1], 'a', {'rel': 'tag'}),
                    'year': re.findall(r'[1-2][0-9]{3}', title.split('|')[1])[0],
                    'plot': parseDOM(title.split('|')[1], 'p')[0].replace('<br/>', '\n'),
                    }
            if data['type'] == 'drama':
                data['tvshowtitle'] = data['title']
                addDir(data['title'], data['link'], 'ListEpisodes',
                       thumb=data['poster'], data=data)
            else:
                addLink(data['title'], data['link'], 'ListEpisodes',
                        thumb=data['poster'], data=data)

        if nextpage:
            data = {}
            data['nextpage'] = True
            addDir('[I]następna strona[/I]', nextpage, mode='ListTitles',
                   poster=nexticon, fanart=default_background, data=data)

        xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                                 label2Mask='%P')
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        endOfDir()
    except:
        endOfDir()


def Alfabet_list():
    Alfabet = list(map(chr, list(range(65, 91))))
    Alfabet.insert(0, '0-9')
    d = xbmcgui.Dialog()
    select = d.multiselect('Listowanie Alfabetyczne', Alfabet)
    if select == None:
        MainMenu()
        return
    seltags = []
    for idx in select:
        seltags.append(Alfabet[idx])
    sep = ','
    url = LETTER_URL.format(sep.join(seltags))
    ListTitles(url)


def ListEpisodes():
    url = params['url']
    name = params['name']
    data_t = params['data']
    res = cache.get(fetch_page, 48, url)
    res = CleanHTML(res)
    episodes = parseDOM(res, 'div', attrs={'class': 'post-.+? episode .+?'})

    fanart = parseDOM(res, 'img', attrs={'class': 'tv-show__poster.+?'}, ret='src')[0]
    for episode in episodes:
        data = {
            'link': parseDOM(episode, 'a', ret='href')[0],
            'title': parseDOM(episode, 'h3')[0],
            'poster': parseDOM(episode, 'img', ret='src')[0],
            'plot': data_t.get('plot'),
            'fanart': fanart
        }
        if data_t['type'] == 'drama':            
            try:
                tvshow_data = {'tvshowtitle': data_t.get('title'),
                               'season': '01',
                               'episode': re.findall('\d+$', parseDOM(episode, 'h3')[0])[0]}
            except IndexError:
                continue
            data.update(tvshow_data)
            addLink(data['title'], data['link'], 'ListLinks', fanart=fanart,
                    thumb=data['poster'], data=data)

        else:
            ListLinks(data['link'])

    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')
    endOfDir()

def ListLinks(url=''):
    if not url:
        url = params['url']
    name = params['name']
    data_t = params['data']
    res = cache.get(fetch_page, 48, url).replace('&quot;', '')

    links = parseDOM(res, 'a', {'class': 'play-source .+?'}, ret='src')
    for link in links:
        if not link.startswith('https'):
            links[links.index(link)] = f'https:{link}'
    players = [f'Player {i + 1}' for i in range(len(links))]

    SourceSelect(players, links, title=name, data=data_t)
    endOfDir()

def Szukaj():
    addDir("[B]Nowe wyszukiwanie...[/B]", '', 'SearchNew',
           fanart=default_background, thumb=search_icon)

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass

    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            url = SEARCH_URL.format(quote_plus(term))
            addDir(term, url, 'ListTitles', fanart=default_background, thumb=search_icon)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search',
               fanart=default_background, thumb=search_icon)
    endOfDir()


def Szukaj_Nowy():
    keyb = xbmc.Keyboard('', "Wyszukiwarka")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        term = keyb.getText()

    else:
        Szukaj()

    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, term))
    dbcon.commit()
    dbcur.close()

    url = SEARCH_URL.format(quote_plus(term))
    ListTitles(url)


def clear_search():
    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DROP TABLE IF EXISTS movies")
    dbcur.execute("VACUUM")
    dbcon.commit()
    dbcur.close()
    Szukaj()

############################################################################################################
# =#########################################################################################################
#                                               GET PARAMS                                                 #
# =#########################################################################################################

params = get_params()
mode = params.get('mode')
url = params.get('url')
name = params.get('name')

############################################################################################################
############################################################################################################
#                                                   MODES                                                  #
############################################################################################################

if mode is None: MainMenu()
elif mode == 'ListTitles': ListTitles()
elif mode == 'ListEpisodes': ListEpisodes()
elif mode == 'ListLinks': ListLinks()
elif mode == 'Alfabetycznie':  Alfabet_list()
elif mode == 'Gatunki':  Kategorie()
elif mode == 'search': Szukaj()
# cache cleaning
elif mode == 'clear_cache':
    from resources.libs import cache
    t = cache.cache_clear()
    if t:
        dialog = xbmcgui.Dialog()
        dialog.notification('fajnadrama.pl ',
                            'Wykonano pomyślnie.', xbmcgui.NOTIFICATION_INFO, 5000)
    pass

elif mode == 'clear_search':
    clear_search()
    execute('Container.Update')

elif mode == 'SearchNew':
    Szukaj_Nowy()
elif mode == 'settings':
    openSettings()
    execute('XBMC.Container.Refresh()')

############################################################################################################

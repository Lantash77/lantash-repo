# -*- coding: UTF-8 -*-
#####Python3.9

import os
import sys
import xbmcaddon
import xbmcvfs
import xbmcplugin
import xbmcgui
import json
import requests
import time

# intro
my_addon = xbmcaddon.Addon()
my_addon_id = my_addon.getAddonInfo('id')
DATA_PATH = xbmcvfs.translatePath(my_addon.getAddonInfo("profile"))
STREAM_URL = 'http://stream.open.fm/%s'
addonhandle = int(sys.argv[1])

# Check cached JSON data...
if not xbmcvfs.exists(DATA_PATH) :
	xbmcvfs.mkdirs(DATA_PATH)

cached_json = os.path.join(DATA_PATH, 'stations.json')

if not xbmcvfs.exists(cached_json) or time.time() - os.path.getmtime(cached_json) > 3600:
	# dane
	url = 'http://open.fm/api/static/stations/stations_new.json'

	# Download and store...

	contents = requests.get(url,).text
	f = xbmcvfs.File(cached_json, 'w')
	f.write(contents)
	f.close()


def getJson():

	cached_json   = os.path.join(DATA_PATH, 'stations.json')
	f = xbmcvfs.File(cached_json)
	data = f.read()
	f.close()
	return json.loads(data)


def stacje():

	json_data = getJson()
	ID_kat = sys.argv[2].split('=')[1]
	for kanal in json_data['channels'] :
		if kanal['group_id'] == ID_kat :
			# print kanal['logo']['url']
			li = xbmcgui.ListItem(kanal['name'])
			info = {'title': kanal['name']}
			li.setInfo('music', infoLabels=info)
			li.setArt({
				'icon': 'DefaultMusicSongs.png',
				'thumb': kanal['logo']['url'].replace('71x71','500x500')
			})
			url = STREAM_URL  % ( kanal['id'] )
			xbmcplugin.addDirectoryItem(addonhandle, url, li, isFolder=False)
			xbmcplugin.setContent(addonhandle, 'songs')


def kategorie():

	json_data = getJson()
	# Categories...
	for kategoria in json_data['groups']:
		li  = xbmcgui.ListItem( kategoria['name'])
		url = '%s?stacje=%s' % (sys.argv[0], kategoria['id'])
		xbmcplugin.addDirectoryItem(addonhandle, url, li, True)


if 'stacje' in sys.argv[2]:
	stacje()
else:
	kategorie()

xbmcplugin.addSortMethod(handle=addonhandle, sortMethod=xbmcplugin.SORT_METHOD_NONE)
xbmcplugin.endOfDirectory(handle=addonhandle, succeeded=True)

# -*- coding: utf-8 -*-
# Python 3.8
###############################################################################
###############################################################################
# STREFADB.PL
#
# 
###############################################################################
###############################################################################
### Imports ###
#import re
#import xbmcgui
import requests
from concurrent.futures import ThreadPoolExecutor
from resources import libs
from resources.libs.addon_tools import *
from resources.libs import cache
from resources.libs.helper import *


#import json

MEDIA = libs.MEDIA
Getsetting = libs.Getsetting
Setsetting = libs.Setsetting
BASE_URL = 'https://strefadb.pl/'
params = get_params()

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
DBthumb = MEDIA + 'dbposter.jpg'
DBZthumb = MEDIA + 'dbzposter.jpg'
DBKAIthumb = MEDIA + 'dbkaiposter.jpg'
DBGTthumb = MEDIA + 'dbgtposter.jpg'
DBSUPERthumb = MEDIA +  'dbsuperposter.jpg'
DBSUPERHEROthumb = MEDIA + 'dbsuperheroposter.jpg'
DBZABRIDGthumb = MEDIA + 'dbzabridgposter.jpg'
DBMOVIEthumb = MEDIA + 'dbmovieposter.jpg'
DBAllfanart = MEDIA + 'dballfanart.jpg'
DBfanart = MEDIA + 'dbfanart.jpg'

host = 'DragonBall'

#HTML HEADER
headersget = {'User-Agent': libs.UA}

### ##########################################################################
### ##########################################################################

def Logowanie():
    headers = {
        'user-agent': libs.UA,
        'referer': 'https://strefadb.pl/',
    }
    data = {
        'login': Getsetting('userdb'),
        'password': Getsetting('passdb'),
        'signin': ''
    }

    cookie = requests.post('https://strefadb.pl', headers=headers, data=data)
    kuki = cookie.cookies.get_dict()
    cookie = "; ".join([f'{k}={v}' for k, v in kuki.items()])
    cache.cache_insert('db_cookie', cookie)

def Pagedragon():

    addDir("Filmy Kinowe", BASE_URL + 'filmy-kinowe.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBMOVIEthumb, 'thumb': DBMOVIEthumb}
           )
    addDir("DragonBall", BASE_URL + 'odcinki/dragon-ball.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBthumb, 'thumb': DBthumb}
           )
    addDir("DragonBall Z", BASE_URL + 'odcinki/dragon-ball-z.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBthumb, 'thumb': DBthumb}
           )
    addDir("DragonBall KAI", BASE_URL + '/odcinki/dragon-ball-kai.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBKAIthumb, 'thumb': DBKAIthumb}
           )
    addDir("DragonBall GT", BASE_URL + '/odcinki/dragon-ball-gt.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBGTthumb, 'thumb': DBGTthumb}
           )
    addDir("DragonBall Super", BASE_URL + '/odcinki/dragon-ball-super.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBSUPERthumb, 'thumb': DBSUPERthumb}
           )
    addDir("DragonBall Super Heroes", BASE_URL + '/odcinki/dragon-ball-super-heroes.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBSUPERHEROthumb, 'thumb': DBSUPERHEROthumb}
           )
    addDir("DragonBall Z Abridged", BASE_URL + '/odcinki/dragon-ball-z-abridged.html', 'DBListTitles',
           data={'fanart': DBAllfanart, 'section': 'ListTitles',
                 'poster': DBZABRIDGthumb, 'thumb': DBZABRIDGthumb}
           )


def ListTitles():
    url = params['url']
    name = params['name']
    data = params['data']
    html = requests.get(url, timeout=10).text
    result = parseDOM(html, 'table', {'id': 'lista-odcinkow'})[0]
    results = [item for item in parseDOM(result, 'tr')]
    episodes = [parseDOM(item, 'td') for item in results if 'href' in item]

    for title, link, s, r, t in episodes:
        nazwa = parseDOM(link, 'a')[0]
        if '<span' in link:
            title = f'{title}  {nazwa} [COLOR=green]  Filler[/COLOR]'
        else:
            f'{title}  {nazwa}'
        link = BASE_URL + re.sub('^/', '', parseDOM(link, 'a', ret='href')[0])

        addLink(title, link, 'DBListLinks',
                data={'fanart': DBAllfanart, 'thumb': data['thumb'],
                      'poster': data['poster'], 'subdir': name}
                )


def ListLinks():
    Logowanie()
    
    url = params['url']
    name = params['name']
    data = params['data']
    subdir = data['subdir']
         
    cookie = cache.cache_get('db_cookie')['value']
    headersget.update({'Cookie': cookie})
    headers = headersget

    html = requests.get(url, headers=headers, timeout=10).text
    result = parseDOM(html, 'table', {'id': 'video-table'})[0]

    results = parseDOM(result, 'tr', {'title':'Kliknij' + r'.+?'})
    playerlink = [parseDOM(item, 'a', ret='data-src') if 'vip_url' in item else
                  parseDOM(item, 'a', ret='href')
                  for item in results]
    playerlink = [BASE_URL + re.sub('^/', '', i[0]) for i in playerlink]
    playername = [parseDOM(item, 'a')[0] for item in results]
    player = []

    with ThreadPoolExecutor(max_workers=10) as executor:
        playerlink = list(executor.map(GetDragonVideolink, playerlink))
    playersubs = [re.sub('<span(.+?)span>', '', parseDOM(item, 'td')[2]) for item in results]
    playeraudio = [parseDOM(item, 'td')[1] for item in results]
    playerquality = [parseDOM(item, 'td')[4] for item in results]

    for item in zip(playername, playerlink, playersubs, playeraudio, playerquality):
        if 'VIP' in item[0]:
            if item[1] == '/vip.html':
                playertitle = f'{item[0]}   [COLOR=red] brak subskrypcji VIP [/COLOR]'
            else:
                playertitle = f'{item[0]}   [COLOR=green] napisy {item[2]} - audio {item[3]} - {item[4]}[/COLOR]'
        else:
            playertitle = f'{item[0]}   [COLOR=green] napisy {item[2]} - audio {item[3]} - {item[4]}[/COLOR]'
        player.append(playertitle)


    SourceSelect(player, playerlink, name, subdir)

def GetDragonVideolink(url):

    cookie = cache.cache_get('db_cookie')['value']
    headersget.update({'Cookie': cookie})
    headers = headersget
    videolink = requests.get(url, headers=headers)
    if url != videolink.url:
        return videolink.url
    else:
        try:
            vip_link = parseDOM(videolink.text, 'source', ret='src')[0]
        except IndexError:
            vip_link = '/vip.html'
        return vip_link

def DBPass_Check():

    if (Getsetting('userdb') == '') or (Getsetting('passdb') == ''):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Konta',
                           'Włączony host StrefaDB, ale nie podano danych konta \n'
                           'Wprowadź dane konta w ustawieniach \n'
                           'lub wyłącz hosta',
                           'Wyłącz hosta', 'Ustawienia')
        if ret:
            openSettings('1.8')
        else:
            Setsetting('DB.active', 'false')
    else:
        return



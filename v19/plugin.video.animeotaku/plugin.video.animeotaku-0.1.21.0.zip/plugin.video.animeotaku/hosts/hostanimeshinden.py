# -*- coding: utf-8 -*-
###############################################################################
###############################################################################
# Anime-Shinden
###############################################################################
###############################################################################
### Imports ###

#import re
#import xbmc
#import xbmcgui
#import sys
#import xbmcplugin
import time
import requests

from resources import libs

#from urllib.parse import quote_plus
#import json

from concurrent.futures import ThreadPoolExecutor
from resources.libs.addon_tools import *
from resources.libs import cache
from resources.libs.helper import *
from resources.libs.worker import *

MEDIA = libs.MEDIA
LETTERS = libs.LETTERS
BASE_URL = 'https://shinden.pl/'
search_url = 'https://shinden.pl/series?search='
searchFile = libs.searchFile
Getsetting = libs.Getsetting
Setsetting = libs.Setsetting
COOKIE = 'shinden_cookie'

params = get_params()

#media#
default_background = MEDIA + "fanart.jpg"
custom_background = MEDIA + "sunset.jpg"
fanart = MEDIA + 'fanart.jpg'
nexticon = MEDIA + 'next.png'
searchicon = MEDIA + 'search.png'
fanartAshinden = MEDIA + 'animeshinden.jpg'
host = 'AnimeShinden'

Alfabet = libs.Alfabet
Alfabet.append('#')
Letters = [(LETTERS + item + '.png') for item in Alfabet]
Letter = dict(zip(Alfabet, Letters))

#HTML HEADER
headersget = {
        'User-Agent': libs.UA,
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    }

### ##########################################################################
### ##########################################################################

def PageAnimeShinden():

   addDir("[Anime] Alfabetycznie", BASE_URL + 'series',
                'SHAlfabetycznie', fanart=default_background, section='Alfabetycznie')
   addDir("[Anime] Wszystkie", BASE_URL + 'series',
                'SHListTitles', fanart=default_background, section='All')
   addDir("[Anime] Emitowane", BASE_URL + 'series?series_status[0]=Currently+Airing',
                'SHListTitles', fanart=default_background, section='Aired')
   addDir("Gatunki", BASE_URL + 'series?', 'SHGatunki',
                fanart=default_background, section='gatunki',
                thumb=searchicon)
   addDir("Wyszukiwarka", search_url, 'SHSearch',
                fanart=default_background, section='search',
                thumb=searchicon)

def Logowanie():

    headers = {
        'origin': 'https://shinden.pl',
        'User-Agent': libs.UA,
        'referer': 'https://shinden.pl/',
    }
    data = {
        'username': Getsetting('usershinden'),
        'password': Getsetting('passshinden'),
        'login': ''
    }

    cookie = requests.post('https://shinden.pl/main/0/login', headers=headers, data=data)
    kuki = cookie.cookies.get_dict()
    cookie = "; ".join([f'{k}={v}' for k, v in kuki.items()])
    cache.cache_insert(COOKIE, cookie)

def Alfabetyczna():

#    name = params['name']
    url = params['url']

    html = requests.get(url, timeout=15).text
    html = CleanHTML(html)
    result = parseDOM(html, 'ul', {'class': 'letter-list' + r'.+?'})[0]
    letterlink = [str(item).replace('r307=1&', '') for item in parseDOM(result, 'a', ret='href')]
    letter = parseDOM(result, 'a')

    for i in zip(letter, letterlink):
    
        addDir(str(i[0]) , url + str(i[1]), 'SHListTitles', section=str(i[0]),
                         thumb=str(Letter[str(i[0])]), fanart=custom_background)

def ListTitles(url=''):

    if url == '':
        url = params['url']

    
    html = requests.get(url, timeout=15).text
    result = str(parseDOM(html, 'section', {'class': 'anime-list box'})[0])
    results = [item for item in parseDOM(result, 'ul', {'class': 'div-row'}) if 'h3' in item]
        
    for item in results:
        link = BASE_URL + re.sub('/series/', 'series/', parseDOM(item, 'a' , ret='href')[1])
        obraz = BASE_URL + re.sub('/res/', 'res/', parseDOM(item, 'a' , ret='href')[0])
        title = parseDOM(item, 'a')[1]
        title = title.replace('<em>', '')
        title = title.replace('</em>', '')
        try:
            datasite = requests.get(link, timeout=10).text
            plotdata = parseDOM(datasite, 'div', {'id':'description'})[0]
            plot = CleanHTML(parseDOM(plotdata, 'p')[0])
        except:
            plot = '' 
        try:
            genredata = [item for item in parseDOM(datasite, 'tr') if 'Gatunki' in item][0]
            genre = ', ' .join(parseDOM(genredata, 'a'))
        except:
            genre = ''
        try:
            yeardata = parseDOM(datasite, 'section', {'class': 'title-small-info'})[0]
            year = re.findall(r'[1-2][0-9]{3}', yeardata)[0]
        except:
            year = ''

        addDir(str(title) , link, 'SHListEpisodes', section='episodes',
                     thumb=str(obraz), fanart=custom_background, subdir=str(title),
                     plot=str(plot), genre=str(genre), year=str(year))
    
    try:
        next = parseDOM(html, 'a', {'rel': 'next'}, ret='href')[0]
        if len(next) > 0:

            nextpage = BASE_URL + re.sub('/', '', next)
            nextpage = CleanHTML(nextpage)
            if '&r307=1' in nextpage:
                nextpage = str(nextpage).replace('&r307=1', '')
            elif 'r307=1' in nextpage:
                nextpage = str(nextpage).replace('r307=1', '')
            addDir('[I]następna strona[/I]', str(nextpage), 'SHListTitles',
                         section='nextpage', thumb=str(nexticon), fanart=custom_background,)               
    except:
        pass

def Search():

    addDir("[B]Nowe wyszukiwanie...[/B]", search_url, 'SHSearchnew',
                 fanart=default_background, section='search')

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass
    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            quote = quote_plus(term)
            url = search_url + quote
            addDir(term, url, "SHListTitles", fanart=default_background,
                         thumb=searchicon)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'clear_search', fanart=default_background)

def Searchnew():


    keyb = xbmc.Keyboard('', "Wyszukiwarka anime")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()

    else:
        Search()
        return
    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()
    url = search_url + quote_plus(search)
    ListTitles(url)


def ListEpisodes():

    section = params['section']
    url = params['url'] + '/all-episodes'
    
    thumb = params['img']    
    subdir = params['subdir']
    
    Logowanie()
    cookie = cache.cache_get('shinden_cookie')['value']
    headersget.update({'Cookie': cookie})
    headers = headersget    
    
    html = requests.get(url, headers=headers, timeout=15).text    
    
    result = parseDOM(html, 'tbody', {'class': 'list-episode-checkboxes'})[0]
    results = parseDOM(result, 'tr')
    epNo = [parseDOM(item, 'td')[0] for item in results]
    epTitle = [parseDOM(item, 'td', {'class': 'ep-title'})[0] for item in results]
    epstatus = [re.findall('<i class="fa fa-fw fa-(.+?)"></i>', item)[0] for item in results]
    epDate = [parseDOM(item, 'td', {'class': 'ep-date'})[0] for item in results]
    link = [BASE_URL + re.sub('^/', '', parseDOM(item, 'a', ret='href')[0]) for item in results]

    for ep in zip(epNo, epTitle, epDate, link, epstatus):
        if str(ep[4]) == 'check':
            title = str(ep[0]) + '  : ' + str(ep[1])
            code = f'[B][COLOR=blue]{str(ep[2])}[/COLOR][/B]'
            section ='online'
        elif str(ep[4]) == 'times':
            title = f'{str(ep[0])}  [COLOR=red]  offline [/COLOR]'
            code = f'[B][COLOR=blue]{str(ep[2])}[/COLOR][/B]'
        else:
            title = f'{str(ep[0])}  [COLOR=red]  offline [/COLOR]'
            section = 'offline'
            code = f'[B][COLOR=blue]{str(ep[2])}[/COLOR][/B]'
       
        addLink(title, str(ep[3]), 'SHListLinks', fanart=str(thumb), thumb=str(thumb),
                      section=section, subdir=subdir, code=code)
 
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_TITLE,
                                 label2Mask= '%P')      
                                 
def ListLinks():
            
    name = params['name']
    url = params['url']
    section = params['section']
    subdir = params['subdir']
    
    if section == 'online':
    
        Logowanie()
        cookie = cache.cache_get('shinden_cookie')['value']
        headersget.update({'Cookie': cookie})
        headers = headersget
        
        html = requests.get(url, headers=headers, timeout=15).text.replace('&quot;', '"')
        result = [item for item in parseDOM(html, 'tbody') if 'player' in item]
        results = parseDOM(result, 'tr')

        playerinfo = [re.findall('data-episode=\"(.+?)\" ', item) for item in results]

        code = re.findall("""_Storage\.basic.*=.*'(.*?)'""", html)[0]
        playerdata = [json.loads(item[0]) for item in playerinfo]
        
        playerlink = []
        player = []
        for i in playerdata:
            #title = f"{i['player']} [COLOR=green]    Audio  {i['lang_audio']} {'' if (i['lang_subs'] == '') or (i['lang_subs'] == None) else '   SUB  ' + i['lang_subs']}[/COLOR]"
            title = f'{i["player"]} [COLOR=green]    Audio  {i["lang_audio"]} {"" if (i["lang_subs"] == "") or (i["lang_subs"] == None) else "   SUB  " + i["lang_subs"]}[/COLOR]'

            player.append(title)
            ID = (i['online_id'])
            playerlink.append(f"https://api4.shinden.pl/xhr/{ID}/player_load?auth={code}")

        with ThreadPoolExecutor(max_workers=10) as executor:
            playerlink = list(executor.map(ShindenGetVideoLink, playerlink))
        SourceSelect(player, playerlink, name, subdir)
    else:
        return

def Gatunki():
    
    section = params['section']
    url = params['url']

    if section == 'gatunki':
        html = requests.get(url, timeout=10).text
        tagname = [re.sub('<i(.+?)</i>', '', item) for item in parseDOM(html, 'a', {'class': 'genre-item'})]
        tagcode = ['i' + item for item in parseDOM(html, 'a', {'class' : 'genre-item'}, ret='data-id')]
        taglink = []

        d = xbmcgui.Dialog()
        select = d.multiselect('Wybór Gatunku', tagname)
        seltags = []
        if select == None:
            PageAnimeShinden()
            return
        for idx in select:
            seltags.append(tagcode[idx])
        sep = ';'
        url = url + 'genres-type=all&genres=' + sep.join(seltags)

    elif section == 'nextpage':
        url = url
    
    ListTitles(url)

def ShindenPass_Check():

    if (Getsetting('usershinden') == '') or (Getsetting('passshinden') == ''):
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno('Błąd Konta',
                           'Włączony host Shinden, ale nie podano danych konta \n'
                           'Wprowadź dane konta w ustawieniach \n'
                           'lub wyłącz hosta',
                           'Wyłącz hosta', 'Ustawienia')
        if ret:
            openSettings('1.5')
        else:
            Setsetting('SH.active', 'false')
            xbmc.executebuiltin('Container.Refresh')
    else:
        return
   
def ShindenGetVideoLink(url):

    headers = {
            'Accept': '*/*',
            'Origin': 'https://shinden.pl',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.46 Safari/537.36',
            'DNT': '1',
        }

    if str(url).startswith("//"): url = "https://" + url
    session = requests.session()
    session.get(url, headers=headers, timeout=15)
    time.sleep(5)
    video = session.get(url.replace("player_load", "player_show") + "&width=508", timeout=5).text
    video_url = ''
    try:
        video_url = parseDOM(video, 'iframe', ret='src')[0]
    except:
        pass
    if not video_url:
        try:
            video_url = parseDOM(video, 'a', ret='href')[0]
        except:
            pass
    if not video_url:
        try:
            video_url = re.findall("src=\"(.*?)\"", video)[0]
        except:
            pass
    if str(video_url).startswith("//"): video_url = "http:" + video_url    
    return video_url

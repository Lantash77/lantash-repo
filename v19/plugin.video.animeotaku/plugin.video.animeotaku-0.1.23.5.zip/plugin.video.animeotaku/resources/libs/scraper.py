import requests
import re
from datetime import datetime

from difflib import SequenceMatcher
from typing import NamedTuple
from resources.libs.worker import *
from urllib.parse import quote_plus

class MediaLanguageDetails(NamedTuple):
    english_result: dict
    original_title: str
    title: str

tm_key = 'dd3ad4e0b1bb862c2cebbf706342da8f'
FHDR = {'api-key': 'a7ad21743fd710fccb738232f2fbdcfc',
                  'client-key': '19d567b32b8d03da1ea4ba1575216b13'}

lang = 'pl'
fanart_tv_art_link = f'http://webservice.fanart.tv/v3/{{content}}/{{id}}'
url_append_to_response = ['translations', 'credits', 'images', 'external_ids', 'alternative_titles']
tmdb_api_url = 'https://api.themoviedb.org/3/'

find_tmdb_url = f'{tmdb_api_url}search/{{}}?api_key={tm_key}&query={{}}&language=en{{}}'
tmdb_url = f'{tmdb_api_url}{{}}/{{}}?api_key={tm_key}&language={lang}&append_to_response={",".join(url_append_to_response)}&include_image_language={lang},en,null'
tmdb_show_episode_url = f'{tmdb_api_url}tv/{{}}//season/{{}}?api_key={tm_key}&language=en&append_to_response=translations,credits'#,external_ids,alternative_titles&include_image_language=en,null'

tm_img_link = f'https://image.tmdb.org/t/p/'
tm_fanart = f'{tm_img_link}w1280{{}}'
tm_poster = f'{tm_img_link}w500{{}}'
tm_icon = f'{tm_img_link}w185{{}}'
tm_still = f'{tm_img_link}w300{{}}'
tm_logo = f'{tm_img_link}w500{{}}'

date_time = datetime.now()
today_date = (date_time).strftime('%Y-%m-%d')


def jget(url, header={}):
    s = requests.get(url, headers=header)
    try:
        s = s.json()
    except Exception as e:
        print(e)
    return s


def get_all_pages(url, page='1'):

    page = f'&page={page}'
    return jget(url.format(page))


def get_type(type_in: str) -> str:

    types_tv = ['tv', 'tvshow', 'series', 'serial',
                'seriale', 'anime', 'drama']
    types_movie = ['movie', 'film', 'movies', 'filmy']
    if type_in.lower() not in types_tv + types_movie:
        return None
    if type_in.lower() in types_tv:
        return 'tv'
    else:
        return 'movie'

def compare_title(title1, title2, ratio: float) -> bool:

    compare = SequenceMatcher(a=get_title(title1),
                    b=get_title(title2))
    cond = compare.ratio()
    return cond > ratio



def get_art(json, id, content):



    # TMDB ART get:
    my_language_order = (lang, 'en', 'null', '00', '', None)
    language_order = {key: i for i, key in enumerate(my_language_order)}

    def parse_tmdb_art(img):
        if not img:
            return None
        try:
            ret_img = [(x['file_path'], x['vote_average'], x['iso_639_1'])
                       for x in img if any(value == x.get('iso_639_1')
                                           for value in my_language_order)]
            if not ret_img:
                ret_img = [(x['file_path'], x['vote_average']) for x in img]
            if not ret_img:
                return None
            if len(ret_img) > 1:
                ret_img = sorted(ret_img, key=lambda d: (language_order[d[2]], -d[1]))
            ret_img = [x[0] for x in ret_img][0]
        except:
            print('none')
            return None
        return ret_img

    tmdb_posters_list = json.get('images', {}).get('posters', None)
    tmdb_fanart_list = json.get('images', {}).get('backdrops', None)
    tmdb_logos_list = json.get('images', {}).get('logos', None)
    if poster_tmdb := parse_tmdb_art(tmdb_posters_list):
        poster_tmdb = tm_poster.format(poster_tmdb)
    else:
        None
    if fanart_tmdb := parse_tmdb_art(tmdb_fanart_list):
        fanart_tmdb = tm_fanart.format(fanart_tmdb)
    else:
        None
    if logo_tmdb := parse_tmdb_art(tmdb_logos_list):
        logo_tmdb = tm_logo.format(logo_tmdb)
    else:
        None
    # Fanart scan
    if content == 'movie':
        fanart_content = 'movies'
    else:
        fanart_content = content
    art = jget(fanart_tv_art_link.format(content=fanart_content, id=id), header=FHDR)
    def parse_fanart(img):
        if not img:
            return None
        try:
            ret_img = [(x['url'], x['likes'], x['lang'])
                       for x in img if any(value == x.get('lang')
                                           for value in my_language_order)]
            if len(ret_img) > 1:
                ret_img = sorted(ret_img, key=lambda x: (language_order[x[2]], -int(x[1])))
            if not ret_img:
                return None
            ret_img = [x[0] for x in ret_img][0]
        except Exception as e:
            print(e)
            return None
        return ret_img

    #Poster
    poster2 = art.get('movieposter', '') or art.get('tvposter', '')
    poster2 = parse_fanart(poster2)
    #fanart
    fanart2 = art.get('moviebackground', '') or art.get('showbackground', '')
    fanart2 = parse_fanart(fanart2)
    #banner
    banner2 = art.get('moviebanner', '') or art.get('tvbanner', '')
    banner2 = parse_fanart(banner2)
    #clearlogo
    if content == 'movie':
        clearlogo = art.get('hdmovielogo', '') or art.get('movielogo', '')
    else:
        clearlogo = art.get('hdtvlogo', '') or art.get('clearlogo', '')
    clearlogo = parse_fanart(clearlogo)
    #clearart
    if content == 'movie':
        clearart = art.get('hdmovieclearart', '') or art.get('movieart', '')
    else:
        clearart = art.get('hdclearart', '') or art.get('clearart', '')
    clearart = parse_fanart(clearart)
    #landscape
    if content == 'movie':
        landscape = art.get('moviethumb', '') or art.get('moviebackground', '')
    else:
        landscape = art.get('tvthumb', '') or art.get('showbackground', '')
    landscape = parse_fanart(landscape)

    # cache all season_posters and pull from seperate method call at season level
    season_posters = art.get('seasonthumb', '')

    art = {'icon': poster_tmdb,
           'thumb': poster2 or poster_tmdb,
           'poster': poster2 or poster_tmdb,
           'fanart': fanart2 or fanart_tmdb,
           'banner': banner2,
           'clearlogo': clearlogo or logo_tmdb,
           'clearart': clearart,
           'landscape': landscape,
           }
    if content == 'tv':
        art.update({'season_posters': season_posters})
    return art


def get_media_titles(title_in, json, origin_lang):

    if lang == 'en':
        english_result = None
    else:
        english_result = next(
            (x['data'] for x in json.get('translations', {}).get('translations', {}) if
             x.get('iso_639_1') == 'en'), {})
    name = json.get('title', '')
    if not name:
        name = json.get('name', '')
    original_name = json.get('original_title', '')
    if not original_name:
        original_name = json.get('original_name', '')
    en_trans_name = (english_result.get('title', '') if not lang == 'en' else None)
    if not en_trans_name:
        en_trans_name = (english_result.get('name', '') if not lang == 'en' else None)

    if lang == "en":
        original_title = title = name
    elif lang == origin_lang:
        original_title = original_name
        title = title_in
    else:
        original_title = en_trans_name or original_name
        if name == original_name and en_trans_name:
            title = en_trans_name
        else:
            title = name
    return MediaLanguageDetails(english_result, original_title, title)


def get_Episode_meta(tmdb, season, episode):
    """
    work in progress !!!!


    :param tmdb:
    :param season:
    :return:
    """

    if not tmdb and not season: return None

    result = jget(tmdb_show_episode_url.format(tmdb, season))

    meta = {}
    meta['premiered'] = result.get('air_date', '')

    episodes = []
    unaired_count = 0
    for episode in result['episodes']:
        episode_meta = {}
        episode_meta['mediatype'] = 'episode'
        episode_meta['premiered'] = episode.get('air_date', '')
        if not episode_meta['premiered']: # access to "status" not available at this level
            unaired_count += 1
            pass
        elif int(re.sub(r'[^0-9]', '', str(episode_meta['premiered']))) > int(re.sub(r'[^0-9]', '', str(today_date))):
            unaired_count += 1
        episode_meta['episode'] = episode['episode_number']
        crew = episode.get('crew')
        try: episode_meta['director'] = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
        except: episode_meta['director'] = ''
        try: episode_meta['writer'] = ', '.join([w['name'] for w in [y for y in crew if y['job'] == 'Writer']])
        except: episode_meta['writer'] = ''
        episode_meta['tmdb_epID'] = episode['id']
        episode_meta['title'] = episode['name']
        episode_meta['plot'] = episode.get('overview', '')
        episode_meta['season'] = episode['season_number']
        episode_meta['thumb'] = tm_still.format(episode['still_path']) if episode.get('still_path') else ''
        episode_meta['rating'] = episode['vote_average']

        episodes.append(episode_meta)
    # I think this should be in episodes module where it has access to "showSeasons" meta for "status"
    meta['season_isAiring'] = 'true' if unaired_count > 0 else 'false'
    #seasoncount = number of episodes for given season
    meta['seasoncount'] = len(result.get('episodes'))
    # meta['tvseasontitle'] = result['name'] # seasontitle ?
    meta['plot'] = result.get('overview', '')
    meta['tmdb'] = tmdb
    meta['poster'] = tm_poster.format(result['poster_path']) if result.get('poster_path') else ''
    meta['season_poster'] = meta['poster']
    meta['season'] = result.get('season_number')
    meta['castandart'] = []
    for person in result['credits']['cast']:
        try: meta['castandart'].append({'name': person['name'],
                                        'role': person['character'],
                                        'thumbnail': tm_icon.format(person['profile_path']) if person.get('profile_path') else ''})
        except: pass
        if len(meta['castandart']) == 150: break
    meta['episodes'] = episodes

    return meta
    print('dupa')


def find_tmdb_ID(title: str, mediatype: str, year='', country='') -> str:
    """
        :param title: tytuł - wymagany
        :param mediatype: typ tytułu - wymagany
        :param year: rok - opcjonalny
        :param country: iso_639_1 format - opcjonalny
        :return: tmdb_id

        Wyszukiwanie tmdb_id podając tytuł, typ, rok i kraj\n
        Pozwala na pominięcie roku i kraju niestety nie gwarantuje 100% skuteczności.

         - example \n
           find_TVShow_ID('Naruto','tv', '', 'ja')
         - lista jezyków https://api.themoviedb.org/3//configuration/languages?api_key={}


    """
    content = get_type(mediatype)
    title_cl = getsearch(title)
    query = quote_plus(title_cl)
    if year:
        year_q = f'&first_air_date_year={year}'
    else:
        year_q = ''
    if content == 'movie':
        year_key = 'release_date'
        title_key = 'title'
        alter_key = 'titles'
    else:
        year_key = 'first_air_date'
        title_key = 'name'
        alter_key = 'results'

    built_url = find_tmdb_url.format(content, query, year_q)
    res = jget(built_url)
    if res.get('results'):
        if res.get('total_pages') > 1:
            pages = [p for p in range(2, res.get('total_pages') + 1)]
            urls = [f'{built_url}{{}}' for p in pages]
            nxt_res = thread_it_multi(get_all_pages, 0, urls, pages)
            for nxt in nxt_res:
                result = nxt.get('results', [])
                for r in result:
                    res['results'].append(r)
    else:
        print(f'{title} ({year}) no TMDB results ! ')
        return f'error{title} ({year}) no TMDB results ! '

    results = res.get('results')
    # if more results for year provided
    if year and country:
        # reduce using country code
        results = [i for i in results if country in i.get('original_language', '')]
        # reduce using year
        results = [i for i in results
                      if re.findall('[\d+]{4}', i.get(year_key, '0000'))[0] == year]

        if not results:
            # No result - given country code
            print(f'{title} ({year}) No result on given country {country}!')
            return f'error {title} {year} No result on given country !'
        if len(results) == 1:
            tmdb_id = results[0].get('id', '')
        else:
            # Checking title similiarity
            res_list = thread_it_multi(jget, 0, [tmdb_url.format(content, i['id']) for i in results])
            match_list = [i for i in res_list if compare_title(title, i[title_key], 0.9)]
            # checking alternative titles
            if not match_list:
                print(f'{title} ({year}) No title match !  Looking in alernative titles')
                alter_match = []
                for item in res_list:
                    alter_title = [i for i in item['alternative_titles'].get(alter_key, {})]
                    for alt in alter_title:
                        if compare_title(title, alt['title'], 0.9):
                            alter_match.append(item)
                reduce_dupes = {item['id']: item for item in alter_match}
                alter_match = [i for i in reduce_dupes.values()]
                print(f'{title} ({year}) Found {len(alter_match)}  in alternative titles')
                if not alter_match:
                    print(f'{title} ({year}) No alter results on given country {country}- TMDB update require ! !')
                    return f'error - {title} ({year}) No alter results on given country {country}! !'
                elif len(alter_match) == 1:
                    tmdb_id = alter_match[0]['id']
                else:
                    print(f'{title} ({year}) {country} overflow ! alternative checked')
                    return f'error - {title} ({year}) {country} overflow ! alternative checked'
            elif len(match_list) == 1:
                tmdb_id = match_list[0]['id']
            else:
                print(f'{title} ({year}) More than one title matching result ! ')
                print(f'{title} ({year}) overflow ! Year and Country provided')
                return f'error {title} ({year}) overflow ! More than one matching result ! Year and Country provided'
                # TODO overflow handle
                # reduce ratio on alternative titles ?
                # Now picking up first from main list

    elif country and not year:
        country_filter = [i for i in results if country in i['original_language']]
        if not len(country_filter) > 1:
            try:
                tmdb_id = country_filter[0]['id']
            except IndexError:
                print(f'{title} tmdb country data missing !')
                return f'error {title} tmdb country data missing !'
        else:
            res_list = thread_it_multi(jget, 0, [tmdb_url.format(content, i['id'])
                                                 for i in country_filter])
            match_list = [i for i in res_list if compare_title(title, i[title_key], 0.9)]

            if len(match_list) == 1:
                tmdb_id = match_list[0]['id']
            # checking alternative titles
            elif not match_list:
                print(f'{title} (no year) No title match !  Looking in alernative titles')
                alter_match = []
                for item in res_list:
                    alter_title = [i for i in item.get('alternative_titles', {}).get(alter_key, {})]
                    for alt in alter_title:
                        if compare_title(title, alt['title'], 0.9):
                            alter_match.append(item)
                reduce_dupes = {item['id']: item for item in alter_match}
                alter_match = [i for i in reduce_dupes.values()]
                print(f'{title}  Found {len(alter_match)} in alternative titles')
                if len(alter_match) == 0:
                    print(f'{title} Not found in alternative titles - TMDB update require')
                if not alter_match and res_list:
                    # TODO coś konstruktywwnego :/
                    # workaround not perfect
                    # reduce ratio on alternative titles ?
                    # Now picking up first from main list
                    tmdb_id = res_list[0]['id']
                    print(f'{title} - {country} No alter results Chosen first from main list')

                elif len(alter_match) == 1:
                    tmdb_id = alter_match[0]['id']
                else:
                    print(f'{title} - {country} alter overflow ! Chosen first')
                    tmdb_id = alter_match[0]['id']
            else:
                print(f'{title} - {country}   overflow ! Chosen first')
                tmdb_id = match_list[0]['id']
                # TODO overflow handle
                # Podnosić ratio ??

    else:
        # No year or counry provided - Title compare - very possible mismatch
        title_filter = [r for r in results if compare_title(title, r[title_key], 0.9)]
        if not len(title_filter) > 1:
            try:
                tmdb_id = title_filter[0]['id']
            except IndexError:
                print(f'{title} tmdb country data missing !')
                return f'error {title} tmdb country data missing !'
        else:
            # res_list = [jget(tmdb_url.format(content, i['id'])) for i in results]

            print(f'{title} overflow ! Only title provided')
            return f'error -{title} overflow ! Only title provided'
            # TODO overflow handle
            # Hulaj dusza

    return tmdb_id


def Get_meta(tmdb_id: str, title: str, mediatype: str) -> dict:
    """
    :param tmdb_id: TMDB ID filmu/serialu
    :param title: Tytuł filmu/serialu
    :param mediatype: typ wyszukiwania: film/serial
    :return:  metadane dla danej pozycji [Dict]

    Pobiera dane dla filmu/serialu  z serwisu TMDB:\n
    Dozwolone wartości dla mediatype:
     - serial: ['tv', 'tvshow', 'series', 'serial', 'seriale', 'anime', 'drama']
     - film: ['movie', 'film', 'movies', 'filmy']

    """

    content = get_type(mediatype)
    result = jget(tmdb_url.format(content, tmdb_id))
    if result.get('success') == False:
        return None
    # build meta dictionary
    meta = {}
    if content == 'tv':
        meta['mediatype'] = 'tvshow'
    else:
        meta['mediatype'] = 'movie'
    meta['imdb'] = result.get('external_ids', {}).get('imdb_id', '0')
    meta['tmdb'] = tmdb_id
    meta['genre'] = [x.get('name') for x in result.get('genres', [])] or 'NA'
    meta['original_language'] = result.get('original_language')
    original_lang = result.get('original_language', '')
    titles = get_media_titles(title, result, original_lang)
    plot = result.get('overview', '')
    tagline = result.get('tagline', '')
    if lang != 'en':
        if not plot:
            plot = titles.english_result.get('overview', '')
        if not tagline:
            en_tagline = titles.english_result.get('tagline', '')
            if en_tagline:
                tagline = en_tagline
    meta['plot'] = plot
    meta['tagline'] = tagline
#######
    if content == 'tv':
        meta['tvdb'] = result.get('external_ids', {}).get('tvdb_id', '0')
        meta['tvshowlocaltitle'] = titles.title
        meta['tvshowtitle'] = titles.original_title
        try:
            studio = [i.get('name') for i in result.get('networks', [])]
        except: studio = ''
        meta['studio'] = studio
        meta['total_episodes'] = result.get('number_of_episodes')  # counts aired eps
        meta['total_seasons'] = result.get('number_of_seasons')
        meta['seasons'] = result.get('seasons')
        for s in meta['seasons']:
            if s.get('poster_path', None):
                s['poster_path'] = tm_poster.format(s['poster_path'])
        id = meta['tvdb']
    else:
        meta['localtitle'] = titles.title
        meta['originaltitle'] = titles.original_title
        meta['duration'] = int(result.get('runtime') * 60) if result.get('runtime') else ''
        try:
            studio = [i.get('name') for i in result.get('production_companies', [])]
        except:
            studio = ''
        meta['studio'] = studio
        id = meta['imdb']
#########
    meta['title'] = title
    meta['premiered'] = result.get('release_date', '')
    if meta['premiered']:
        meta['year'] = meta['premiered'][:4]
    else:
        meta['year'] = meta['premiered']
    meta['rating'] = result.get('vote_average', '')
    crew = result.get('credits', {}).get('crew')
    try:
        meta['director'] = ', '.join([d['name'] for d in [x for x in crew
                                                          if x['job'] == 'Director']])
    except:
        meta['director'] = ''
    try:
        meta['writer'] = ', '.join([w['name'] for w in [y for y in crew
                                                        if y['job'] == 'Writer']])
    except:
        meta['writer'] = ''
    meta['castandart'] = []
    for person in result['credits']['cast']:
        try: meta['castandart'].append({'name': person['name'],
                                        'role': person['character'],
                                        'thumbnail': tm_icon.format(person.get('profile_path'))
                                        if person.get('profile_path') else ''})
        except: pass
        if len(meta['castandart']) == 150:
            break

    art = get_art(result, id, content)
    meta.update(art)
    return meta


def getsearch(title):
    if title is None:
        return
    title = title.lower()
    title = re.sub("&#(\d+);", "", title)
    title = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", title)
    title = title.replace("&quot;", '"').replace("&amp;", "&")
    title = re.sub("\\\|/|!|\[|\]|–|:|;|\*|\?|\"|'|<|>|\|", "", title).lower()
    title = title.replace(".", " ").replace("  ", " ").replace("–", "-")
    return title


def get_title(title):

    if title is None: return
    title = re.sub(r'&#(\d+);', '', title)
    title = re.sub(r'(&#[0-9]+)([^;^0-9]+)', '\\1;\\2', title)
    title = title.replace(r'&quot;', '\"').replace(r'&amp;', '&').replace(r'–', '-').replace(r'!', '')
    title = re.sub(r'\n|([\[].+?[\]])|([\(].+?[\)])|\s(vs|v[.])\s|(:|;|-|–|"|,|\'|\_|\.|\?)|\s', '', title).lower()
    return title
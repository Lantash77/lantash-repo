import requests
import re
import xbmc

from resources.libs import cache

sess = requests.session()

UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Mobile Safari/537.36 Edg/97.0.1072.69'

def fetch(url):
    id = url.split("/")[-1]
    lib_id = url.split("/")[-2]
    base_url = re.findall('(.+?://.+?/)', url)[0]

    # main
    headers = {
        'user-agent': UA,
        'referer': 'https://www.dramaqueen.pl/',
    }

    r = sess.get(url, headers=headers)

    # activate
    activate_url = re.findall(';loadUrl\(\"(.+?)\",', r.text)[0].split(";")[-1].replace('loadUrl("', '')
    headers_activate = {
        'user-agent': UA,
        'referer': base_url
    }

    r_activate = sess.get(activate_url, headers=headers_activate)
    # src
    src_url = re.findall('e.loadSource\(\"(.+?)\"\);', r.text)[0]
    headers_src = {
        'user-agent': UA,
        'referer': url,
    }

    r_src = sess.get(src_url, headers=headers_src)
    res_list = re.findall('.*/video.drm?.*', r_src.text)
    res = res_list[-1]

    hash1 = re.findall('\{var l=\"(.+?)\";', r.text)[0]
    hash2 = re.findall(';var o=k\(l\+\"(.+?)\"', r.text)[0]
    ping_url = re.findall('loadUrl\(\"(.+?)\"', r.text)[0] + '?'
    post_url = activate_url.rpartition('.drm')[0] + '.metrics/track-session'
    cached = {'hash': hash1 + hash2, 'ping_url': ping_url,
                'res': re.findall('x(.+?)/', res)[0], 'post_url': post_url,
                'video_id': id, 'library_id': lib_id,
                'key':''}
    cache.cache_insert('ping', repr(cached))

    # hls
    strmUrl = base_url + id + '/' + res
    lice_url = activate_url.replace('/activate', '/' + res_list[-1].split("/")[0] + '.drmkey')



    return strmUrl, headers_src



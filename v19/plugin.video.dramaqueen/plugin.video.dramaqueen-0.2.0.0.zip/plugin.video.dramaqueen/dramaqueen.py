# -*- coding: UTF-8 -*-
#####Python 3.9 #######

import re
import os
import sys
import json

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


from resources import libs
from resources.libs.addon_tools import *

DATA_PATH = libs.DATA_PATH
GetSetting = libs.GetSetting
MEDIA = libs.MEDIA
searchFile = os.path.join(DATA_PATH, "search.db")
search_url = 'https://www.dramaqueen.pl/?s=%s'


############################################################################################################
############################################################################################################
#                                                   MEDIA                                                  #
############################################################################################################
korea_background = MEDIA + 'Korea.jpg'
japan_background = MEDIA + 'Japan.jpg'
china_background = MEDIA + 'China.jpg'
korea_thumb = MEDIA + 'koreathumb.png'
japan_thumb = MEDIA + 'japoniathumb.png'
inne_thumb = MEDIA + 'innethumb.png'
default_background = MEDIA + "fanart.png"
search_icon = MEDIA + 'search.png'
iconsettings = MEDIA + 'settings.png'



############################################################################################################
# =########################################################################################################=#
#                                                   MENU                                                   #
# =########################################################################################################=#

def CATEGORIES(login):
    addDir('[COLOR=yellow]Gatunki[/COLOR]', '', 'Monit',
                 fanart=korea_background)

    addDir('Drama Koreańska', '', 'Monit',
            fanart=korea_background, thumb=korea_thumb)
    addDir('Drama Japońska', '', 'Monit',
           fanart=japan_background, thumb=japan_thumb)
    addDir('Dramy Inne', '', 'Monit',
            fanart=china_background, thumb=inne_thumb)
    addDir('Film Korea', '', 'Monit',
            fanart=korea_background, thumb=korea_thumb)
    addDir('Film Japonia', '', 'Monit',
            fanart=japan_background, thumb=japan_thumb)
    addDir('Filmy Pozostałe', '', 'Monit',
            fanart=china_background, thumb=inne_thumb)
    addDir("Wyszukiwanie", '', 'Monit',
           fanart=default_background, thumb=search_icon)
    addDir('Ustawienia', '', 'Monit',
           fanart=default_background, thumb=iconsettings, isFolder=True)


############################################################################################################
# =########################################################################################################=#
#                                                 FUNCTIONS                                                #
# =########################################################################################################=#


############################################################################################################
# =########################################################################################################=#
#                                               GET PARAMS                                                 #
# =########################################################################################################=#

params = get_params()
try:
    mode = params.get('mode')
except:
    mode = None

###############################################################################################################
# =###########################################################################################################=#
#                                                   MODES                                                     #
# =###########################################################################################################=#

if mode == None:
    CATEGORIES(True)
    endOfDir()

elif mode == 'Monit':
    d = xbmcgui.Dialog()
    d.ok('Informacja DramaQueen',
                       'Wtyczka w trakcie modernizacji '
                       'do nowej wersji systemu \nWkrótce wrócimy online')


############################################################################################################

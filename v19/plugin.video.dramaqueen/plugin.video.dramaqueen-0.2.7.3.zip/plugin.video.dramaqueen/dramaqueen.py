# -*- coding: UTF-8 -*-
#####Python 3.9 #######

import re
import os
import sys
import json

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


from resources import libs
from resources.libs import cache
from resources.libs.helper import *
from resources.libs.addon_tools import *
from resources.libs.dqhelper import Logowanie
from resources.libs.adv_settings import check_advanced_settings

DATA_PATH = libs.DATA_PATH
GetSetting = libs.GetSetting
MEDIA = libs.MEDIA
searchFile = os.path.join(DATA_PATH, "search.db")
search_url = 'https://www.dramaqueen.pl/?s=%s'

############################################################################################################
############################################################################################################
#                                                   MEDIA                                                  #
############################################################################################################
korea_background = MEDIA + 'Korea.jpg'
japan_background = MEDIA + 'Japan.jpg'
china_background = MEDIA + 'China.jpg'
korea_thumb = MEDIA + 'koreathumb.png'
japan_thumb = MEDIA + 'japoniathumb.png'
inne_thumb = MEDIA + 'innethumb.png'
default_background = MEDIA + "fanart.png"
search_icon = MEDIA + 'search.png'
iconsettings = MEDIA + 'settings.png'

headersget = {'user-agent': libs.UA}

############################################################################################################
# =########################################################################################################=#
#                                                   MENU                                                   #
# =########################################################################################################=#

def CATEGORIES(login):
    addDir('[COLOR=yellow]Gatunki[/COLOR]', '', 'GenreList',
                 fanart=korea_background)

    addDir('Drama Koreańska', '', 'ListTitles',
            fanart=korea_background, thumb=korea_thumb)
    addDir('Drama Japońska', '', 'ListTitles',
           fanart=japan_background, thumb=japan_thumb)
    addDir('Dramy Inne', '', 'ListTitles',
            fanart=china_background, thumb=inne_thumb)
    addDir('Film Korea', '', 'ListTitles',
            fanart=korea_background, thumb=korea_thumb)
    addDir('Film Japonia', '', 'ListTitles',
            fanart=japan_background, thumb=japan_thumb)
    addDir('Filmy Pozostałe', '', 'ListTitles',
            fanart=china_background, thumb=inne_thumb)
    addDir("Wyszukiwanie", '', 'search',
           fanart=default_background, thumb=search_icon)
    addDir('Ustawienia', '', 'OpenSettings',
           fanart=default_background, thumb=iconsettings, isFolder=True)

    if login == True:
        Logowanie(True)

############################################################################################################
# =########################################################################################################=#
#                                                 FUNCTIONS                                                #
# =########################################################################################################=#


def get_json():
    return requests.get('https://lantash77.github.io/assets/DQ_list.json').json()


def AllTitlesDict():

    tit = cache.get(get_json, 24)
    all_titles = {}
    for i in tit.values():
        try:
            links = {r['link']: r for r in i if r is not None}
            all_titles.update(links)
        except Exception as e:
            continue
    return all_titles


def ListTitles():

    name = params['name']
    titles = cache.get(get_json, 24)[name]

    for title in titles:
        try:
            if title['type'] == 'drama':
                addDir(title['title'], title['link'], 'ListEpisodes', data=title)
                xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            else:
                addLink(title['title'], title['link'], 'ListEpisodes', data=title)
                xbmcplugin.setContent(int(sys.argv[1]), 'movie')
        except:
            continue


def ListEpisodes():

    data = params['data']
    if data['type'] == 'drama':
        for num, episode in enumerate(data['episodes']):
            exclude_list = ['tłumaczeni', 'korekta']

            if any(exclude in episode['ep_title'] for exclude in exclude_list):

                addLink(episode['ep_title'], '', 'Empty', data=data)
                xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
            else:
                links = {'ep_title': episode['ep_title'],
                         'ep_players': episode['players'],
                         'ep_links': episode['links'],
                         'episode': episode['episode'],
                         'episode_ID': episode['episode_ID'],
                         }

                data.update(links)
                addLink(episode['ep_title'], '', 'ListLinks', data=data)
                xbmcplugin.setContent(int(sys.argv[1]), 'episodes')

    else:
        for episode in data['episodes']:
            SourceSelect(episode['players'], episode['links'],
                         data['title'], data=data)

    print('wait')


def ListLinks():

    data = params['data']
    SourceSelect(data['ep_players'], data['ep_links'],
                 data['ep_title'], data=data)

def Kategorie():

    genres = cache.get(get_json, 24)['genres']

    for genre in genres:
        addDir(genre, genres[genre]['gen_link'], mode='GenreTitles',
               code=f'[B][COLOR green]{genres[genre]["gen_link"]} pozycji[/COLOR][/B]')

    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                                 label2Mask='%P')


def KategorieLista():

    titles = AllTitlesDict()
    url = params['url']

    Logowanie(False)
    cookie = cache.cache_get('dramaqueen_cookie')['value']
    headersget.update({'Cookie': cookie})

    res = requests.get(url, headers=headersget, timeout=15).text
    res = CleanHTML(res)

    result = parseDOM(res, 'div', attrs={'class': 'avia-content-slider-inner'})[0]
    links = [parseDOM(i, 'a', ret='href')[0] for i in parseDOM(result, 'h3')]
    gen_results = []
    for link in links:
        try:
            gen_results.append(titles[link])
        except KeyError:
            log(f'missing {link} in json list', 0)
            #print(f'missing {link} in json list')
            continue

    for title in gen_results:
        if title['type'] == 'drama':
            addDir(title['title'], title['link'], 'ListEpisodes', data=title)
            xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

        elif title['type'] == 'movie':
            addLink(title['title'], title['link'], 'ListEpisodes', data=title)
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')


def Szukaj():

    addDir("[B]Nowe wyszukiwanie...[/B]", '', 'NewSearch',
                 fanart=default_background, thumb=search_icon)

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    try:
        dbcur.executescript(
            "CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);"
        )
    except:
        pass

    dbcur.execute("SELECT * FROM movies ORDER BY ID DESC")
    lst = []

    delete_option = False
    for (id, term) in dbcur.fetchall():
        if term not in str(lst):
            delete_option = True
            url = search_url % quote_plus(term)
            addDir(term, url, 'SearchResult',
                    fanart=default_background, thumb=search_icon)
            lst += [(term)]
    dbcur.close()

    if delete_option:
        addDir("[I]Wyczyść listę wyszukiwania[/I]", '', 'ClearSearch',
                     fanart=default_background, thumb=search_icon) #"Naciśnij aby wyczyścić historię"#32605


def Szukaj_Nowy():

    keyb = xbmc.Keyboard('', "Wyszukiwarka")
    keyb.doModal()

    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0:
        search = keyb.getText()
    else: CATEGORIES(False)

    from sqlite3 import dbapi2 as database

    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("INSERT INTO movies VALUES (?,?)", (None, search))
    dbcon.commit()
    dbcur.close()

    search = quote_plus(search)
    url = search_url % search
    WynikiSzukania(url)

def WynikiSzukania(url):


    titles = AllTitlesDict()
    Logowanie(False)
    cookie = cache.cache_get('dramaqueen_cookie')['value']
    headersget.update({'Cookie': cookie})

    html = requests.get(url, headers=headersget, timeout=15).text
    result = parseDOM(html, 'main', {'role': 'main'})[0]
    results = [CleanHTML(item) for item in parseDOM(result, 'h2')]
    links = [parseDOM(item, 'a', ret='href')[0] for item in results]

    gen_results = []
    for link in links:
        try:
            gen_results.append(titles[link])
        except KeyError:
            continue

    for title in gen_results:
        if title['type'] == 'drama':

            addDir(title['title'], title['link'], 'ListEpisodes', data=title)
            xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

        elif title['type'] == 'movie':
            addLink(title['title'], title['link'], 'ListEpisodes', data=title)
            xbmcplugin.setContent(int(sys.argv[1]), 'movie')

    xbmcplugin.addSortMethod(int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_TITLE,
                             label2Mask='%P')
    print('wait')

def clear_search():

    from sqlite3 import dbapi2 as database
    dbcon = database.connect(searchFile)
    dbcur = dbcon.cursor()
    dbcur.execute("DROP TABLE IF EXISTS movies")
    dbcur.execute("VACUUM")
    dbcon.commit()
    dbcur.close()
    Szukaj()


############################################################################################################
# =########################################################################################################=#
#                                               GET PARAMS                                                 #
# =########################################################################################################=#


params = get_params()
xbmc.executebuiltin("action(reloadkeymaps)")
check_advanced_settings()


try:
    mode = params.get('mode')
except:
    mode = None

###############################################################################################################
# =###########################################################################################################=#
#                                                   MODES                                                     #
# =###########################################################################################################=#

if mode == None:
    CATEGORIES(True)
    endOfDir()
elif mode == 'ListTitles':
    ListTitles()
    endOfDir()
elif mode == 'ListEpisodes':
    ListEpisodes()
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    endOfDir()
elif mode == 'ListLinks':
    ListLinks()
    endOfDir()
elif mode == 'GenreList':
    Kategorie()
    endOfDir()
elif mode == 'GenreTitles':
    KategorieLista()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    endOfDir()
elif mode == 'search':
    Szukaj()
    endOfDir()
elif mode == 'SearchResult':
    url = params.get('url')
    WynikiSzukania(url)
    endOfDir()
elif mode == 'ClearSearch':
    clear_search()
    execute('Container.Refresh')
    endOfDir()
elif mode == 'NewSearch':
    Szukaj_Nowy()
    endOfDir()
elif mode == 'ClearCache':
    t = cache.cache_clear()
    if t:
        dialog = xbmcgui.Dialog()
        dialog.notification('dramaqueen.pl ', '[COLOR=gold]Wyczyszczono cache.[/COLOR]',
                            xbmcgui.NOTIFICATION_INFO, 5000)
    #    execute('Container.Refresh')
    endOfDir()
elif mode == 'OpenSettings':
    libs.my_addon.openSettings()

    execute('Container.Refresh')
#Brak linku - monit
elif mode == 'Empty':
    dialog = xbmcgui.Dialog()
    dialog.notification('dramaqueen.pl ', '[COLOR=red]Brak odcinka.[/COLOR]',
                         xbmcgui.NOTIFICATION_INFO, 5000)

############################################################################################################

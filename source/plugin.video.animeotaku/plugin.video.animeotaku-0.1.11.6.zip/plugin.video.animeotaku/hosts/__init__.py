import os
import xbmcvfs
import xbmcaddon

my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')
MEDIA = xbmcvfs.translatePath(PATH + "resources/media/")
DATA_PATH = xbmcvfs.translatePath(my_addon.getAddonInfo("profile"))
LETTERS = xbmcvfs.translatePath(MEDIA + 'letters/')
Getsetting = my_addon.getSetting
searchFile = os.path.join(DATA_PATH, "search.db")
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.75 Safari/537.36'

